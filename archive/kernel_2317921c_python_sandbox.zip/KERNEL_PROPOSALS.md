# KERNEL PROPOSALS

Requests for kernel changes, for the human to decide. The research loop appends
here; it never edits the kernel. Format per entry: date, problem, evidence,
proposed change, expected effect on pass rates, status.

## 2026-11-18 (build session) KP-001 Liquidation check on mark price, not last-trade wicks

- Problem: the v1 genesis liquidation check used last-trade bar high/low. The
  ETHUSDT perp printed a high of 323.00 against an open of 95.73 on 2020-03-13
  02:00 UTC (spot high 120.20, mark high 119.47); any ETH short of about
  0.42 x equity held through that hour failed integrity.
- Change made: `mark_klines` dataset admitted (Binance bulk markPriceKlines,
  checksums verified, REST backfill from 2019-12-23 and top-up); the liquidation
  check uses mark high/low relative to the mark open of the same bar, falling back
  to last-price extremes where a bar has no mark data; 2.5% maintenance rule kept.
  DEV+VAL mark coverage 99.54% to 99.90% per symbol. Regression test: a 0.5 x
  equity ETH short held through 2020-03-13 02:00 does not liquidate.
- Status: CLOSED 2026-11-18 (approved by the coordinator; part of the
  pre-genesis re-key, zero trials evaluated).

## 2026-11-18 (build session) KP-002 Model the exchange-side protective stop

- Problem: CONSTITUTION section 11 requires a reduce-only protective stop on
  every live position; the v1 engine does not model it.
- Proposed change: kernel v2 engine option for a stop at a fixed distance, with
  fills at the stop level or the bar open if gapped through.
- Status: open (required before any live use).

## 2026-11-18 (build session) KP-003 Confirm the denominator of the null pass rate

- Problem: the G6 threshold rule says "null pass rate <= 3.0%". With the activity
  check counting decisions, 25-29% of DEV-overfit null pairs fail integrity
  (mostly funding carry and slow SMA-cross draws). Final hardened pipeline
  (`ledger/calibration_43099ad9550d2be7.json`): per COUNTED pair null A is 4/373,
  12/373, 14/373 and null B 1/355, 5/355, 11/355 at 0.025 / 0.05 / 0.10, so only
  0.025 qualifies; per ALL 500 pairs the rates are 0.8%, 2.4%, 2.8% (A) and 0.2%,
  1.0%, 2.2% (B) and 0.10 would qualify.
- Applied: the counted-pair reading (an integrity failure is not a trial and is a
  free retry for the researcher, so the per-counted-trial rate is the false
  positive rate that matters; it is also the stricter reading).
- Effect of the alternative: G6 0.10 would raise slow-oracle power at Sharpe 1.5
  from 0.62 to 0.76 (null A) and from 0.79 to 0.84 (null B), at a null pass rate
  per counted trial of 3.75% (A) and 3.10% (B).
- Status: open - human to confirm or switch (switching is a constant change and a
  re-key; the stored per-pair results allow `python -m omr.calibrate --reread`).

## 2026-11-18 (build session) KP-004 Mark-bar quality and maintenance tiers

- Problem: about 3,000 mark bars per symbol have fewer than 3,600 sampled seconds
  (partial sampling), and Binance applies tiered maintenance margins by position
  size; v1 uses a flat 2.5% and treats partial mark bars as complete.
- Proposed change: record partial bars in the coverage report as a separate
  class, and model the maintenance tier for the deploy-scale position size before
  any live use.
- Status: open (low priority at gross <= 1).

## 2026-11-18 (build session) KP-006 Position-encoded calendars

- Problem: the time-shift invariance relabels timestamps but keeps bar positions.
  The data start is fixed (BTC 2019-09-08 17:00, ETH 2019-11-27 07:00), so a bar's
  POSITION is a date; a strategy can still encode remembered history through
  `len(bars)` or cumulative counters. The truncation test cannot see it (positions
  are consistent in truncated runs).
- Proposed change: a "start-offset" invariance check: drop the first N whole weeks
  of warm-up data (N random per run) and require identical outputs on the common
  rows after a convergence window, or randomise the data start per child run.
- Status: open (residual hole after the review hardening; forward results remain
  the last line of defence).

## 2026-11-18 (build session) KP-007 Attribute allowlist is name-based

- Problem: attribute names are allowed regardless of the object. `values` plus
  `astype` extract epoch nanoseconds from the index; such use is caught later by
  the time-shift invariance, not by the parser. Similarly `np.roll` wraps future
  rows to the start (caught by the lookahead test).
- Proposed change: none urgent; keep the dynamic checks as the line of defence and
  grow the allowlist deliberately.
- Status: open (documentation).

## 2026-11-18 (build session) KP-008 Outdated docstring in omr/strategy_api.py

- Problem: the module docstring (kernel file, written before the hardening) still
  shows `from omr import indicators as ind` (now rejected by the allowlist) and
  describes the portfolio panel as a dict {symbol: bars} (it is now an ordered
  list). CONSTITUTION, RESEARCH_PLAYBOOK and README are correct. A file written
  from the docstring is rejected statically (uncounted, with the rule named).
- Proposed change: update the docstring at the next human-approved re-key (the
  build was limited to one re-key).
- Status: open (documentation only).

## 2026-11-18 (build session) KP-005 Calibrate G8

- Problem: synthetic worlds carry only the core symbols, so G8 (extended-universe
  veto) is never exercised in calibration; null pass rates are upper bounds and
  G8's own false-veto rate on real edges is unknown.
- Proposed change: extend null A/B worlds to the extended perps (same day blocks
  and coins) and report the G8 pass rate of the oracles.
- Status: open.
