"""Strategy execution. Kernel module.

ChildRunner (used by the evaluator, the sandbox and the census): every job runs strategy code in
a fresh child process (python -I -B, cwd = a fresh temp dir, scrubbed environment, stdout/stderr
discarded, timeout). The child receives the exact source TEXT the parent hashed and checked,
explicit params, and only the frames for that job. It returns numeric arrays plus a status from
a fixed enumeration. The parent validates shapes; all comparisons, metrics and gates stay in the
parent. The child's `omr` package is a private copy of strategy_api.py and indicators.py only.

InProcessRunner: same interface, runs a TRUSTED strategy object in this process. Used only by
omr.calibrate for its built-in families.

A job = (frames, runs). frames: ordered list of DataFrames (kind "single": one frame per symbol,
each on its own index; kind "portfolio": a positional panel on one common index). runs: list of
{"params": dict, "cut": ns or None, "from": ns or None}; each run truncates every frame to rows
<= cut and returns, per output column, the rows >= from.
"""
from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import tempfile
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np
import pandas as pd

from omr import constants as C
from omr.paths import ROOT

CHILD_SCRIPT = ROOT / "omr" / "runner_child.py"
CHILD_PACKAGE_FILES = ("strategy_api.py", "indicators.py")
STATUS_CODES = ("ok", "load_error", "no_strategy_class", "exception", "bad_output", "timeout", "crash")


@dataclass
class Job:
    frames: list
    runs: list


@dataclass
class JobResult:
    status: str
    outputs: list = field(default_factory=list)   # per run: list of float64 arrays (one per output column)


def _child_env(tmp: str) -> dict:
    env = {"TEMP": tmp, "TMP": tmp}
    for k in ("SYSTEMROOT", "SystemRoot", "WINDIR"):
        if k in os.environ:
            env[k] = os.environ[k]
    return env


def _write_job(tmp: Path, source: str, kind: str, job: Job):
    pkg = tmp / "omr"
    pkg.mkdir()
    (pkg / "__init__.py").write_text('"""child copy: strategy_api and indicators only"""\n', encoding="ascii")
    for f in CHILD_PACKAGE_FILES:
        shutil.copyfile(ROOT / "omr" / f, pkg / f)
    arrays, specs = {}, []
    for i, f in enumerate(job.frames):
        arrays[f"f{i}_index"] = np.asarray(pd.DatetimeIndex(f.index).as_unit("ns").asi8, dtype=np.int64)
        cols = list(f.columns)
        for j, c in enumerate(cols):
            v = f[c].to_numpy()
            arrays[f"f{i}_c{j}"] = v if v.dtype == bool else np.asarray(v, dtype=np.float64)
        specs.append({"columns": cols})
    np.savez(tmp / "frames.npz", **arrays)
    runs = [{"params": {k: (float(v) if not isinstance(v, int) else int(v)) for k, v in r["params"].items()},
             "cut": None if r.get("cut") is None else int(r["cut"]),
             "from": None if r.get("from") is None else int(r["from"])} for r in job.runs]
    (tmp / "job.json").write_text(json.dumps({"source": source, "kind": kind, "frames": specs, "runs": runs}),
                                  encoding="ascii")


class ChildRunner:
    def __init__(self, source: str, kind: str, timeout: float = C.CHILD_TIMEOUT_S, workers: int | None = None):
        self.source = source
        self.kind = kind
        self.timeout = timeout
        self.workers = workers or max(1, min(C.CHILD_WORKERS, (os.cpu_count() or 2) - 1))
        self.n_children = 0

    def _one(self, job: Job) -> JobResult:
        tmp = Path(tempfile.mkdtemp(prefix="omr_child_"))
        try:
            _write_job(tmp, self.source, self.kind, job)
            try:
                subprocess.run([sys.executable, "-I", "-B", str(CHILD_SCRIPT)], cwd=str(tmp), env=_child_env(str(tmp)),
                               stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                               timeout=self.timeout, check=False)
            except subprocess.TimeoutExpired:
                return JobResult("timeout")
            st = tmp / "status.json"
            if not st.exists():
                return JobResult("crash")
            try:
                status = json.loads(st.read_text(encoding="ascii")).get("status")
            except Exception:
                return JobResult("crash")
            if status not in STATUS_CODES:
                return JobResult("crash")
            if status != "ok":
                return JobResult(status)
            z = np.load(tmp / "result.npz", allow_pickle=False)
            n_cols = len(job.frames)
            outs = []
            for r in range(len(job.runs)):
                cols = []
                for j in range(n_cols):
                    key = f"r{r}_c{j}"
                    if key not in z.files:
                        return JobResult("bad_output")
                    a = np.asarray(z[key], dtype=np.float64)
                    if a.ndim != 1:
                        return JobResult("bad_output")
                    cols.append(a)
                outs.append(cols)
            return JobResult("ok", outs)
        finally:
            shutil.rmtree(tmp, ignore_errors=True)

    def run(self, jobs: list) -> list:
        self.n_children += len(jobs)
        if len(jobs) == 1:
            return [self._one(jobs[0])]
        with ThreadPoolExecutor(max_workers=self.workers) as ex:
            return list(ex.map(self._one, jobs))


class InProcessRunner:
    """TRUSTED strategies only (calibration families). Same semantics as ChildRunner."""

    def __init__(self, obj, kind: str):
        self.obj = obj
        self.kind = kind
        self.n_children = 0

    def _one(self, job: Job) -> JobResult:
        outs = []
        try:
            for run in job.runs:
                cut, frm = run.get("cut"), run.get("from")
                if cut is None:
                    tf = list(job.frames)
                else:
                    ct = pd.Timestamp(int(cut), unit="ns", tz="UTC")
                    tf = [f.iloc[: int(f.index.searchsorted(ct, side="right"))] for f in job.frames]
                cols, idxs = [], []
                if self.kind == "single":
                    for f in tf:
                        s = self.obj.signal(f.copy(), dict(run["params"]))
                        if not isinstance(s, pd.Series) or not s.index.equals(f.index):
                            return JobResult("bad_output")
                        cols.append(s.to_numpy(dtype=np.float64, na_value=np.nan))
                        idxs.append(f.index)
                else:
                    w = self.obj.weights([f.copy() for f in tf], dict(run["params"]))
                    if not isinstance(w, pd.DataFrame) or w.shape != (len(tf[0]), len(tf)) or not w.index.equals(tf[0].index):
                        return JobResult("bad_output")
                    for j in range(w.shape[1]):
                        cols.append(w.iloc[:, j].to_numpy(dtype=np.float64, na_value=np.nan))
                        idxs.append(tf[0].index)
                if frm is not None:
                    cols = [c[np.asarray(ix.as_unit("ns").asi8) >= int(frm)] for c, ix in zip(cols, idxs)]
                outs.append(cols)
        except Exception:
            return JobResult("exception")
        return JobResult("ok", outs)

    def run(self, jobs: list) -> list:
        return [self._one(j) for j in jobs]
