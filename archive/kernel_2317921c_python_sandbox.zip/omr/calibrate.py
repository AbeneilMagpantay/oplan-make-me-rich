"""Instrument calibration (kernel v1, protocol v2):

    python -m omr.calibrate [--worlds 100] [--oracle-scale-worlds 60] [--oracle-worlds 100] [--workers 6]

Synthetic worlds are built from the real core data (BTCUSDT, ETHUSDT) over the real 1h
calendar, carrying klines, mark-price klines and funding together.

NULL A (bootstrap): whole UTC days are drawn iid with replacement from DEV+VAL, the same
  source day for both core symbols. Each day keeps its intraday bars (open gap to the previous
  close, high/low/close relative to the open), its mark bars and its funding settlements.
  Keeps drift, intraday shape and within-day volatility; destroys multi-day predictability
  and multi-day volatility clustering.
NULL B (sign-flip): the REAL day order is kept. For each UTC day one fair coin (shared by both
  core symbols) decides whether that day's DEMEANED hourly log-return path is mirrored:
  r' = -(r - m) + m, m = the symbol's mean hourly log return over DEV+VAL. A mirrored bar's
  high and low excursions swap roles. Mark bars get the same construction with their own m;
  funding stays as it was. Keeps the real volatility dynamics; destroys directional
  predictability across days.

DEV-overfit protocol (false-positive rate): for each (family, world) draw 20 parameter sets
  uniformly from the declared ranges, keep the best DEV Sharpe, send only that through the
  Tier-1 pipeline. Per-pair results (null, family, world, chosen params, every gate outcome,
  the G6 p-value) are stored, so any G6 threshold can be re-read without re-running.

NOISY-ORACLE power test: synthetic strategies with a known true edge, on fresh null worlds.
  Per asset, signal = sign(rho * z_future + sqrt(1 - rho^2) * eps), z_future = standardised
  future k-day open-to-open log return, eps independent N(0,1); re-decided every k days
  (decided at the 23:00 bar, executed at the next 00:00 open); weight = signal / K.
  Speeds: fast k = 1 day, slow k = 20 days. rho is calibrated per (null, speed) on a separate
  set of worlds so the mean net VAL Sharpe is ~1.0 and ~1.5. The oracles bypass integrity by
  construction (they read the future); G5 and G9 pass by definition; G8 is not run. This
  code lives only here and is never reachable from omr.evaluate.

G6 threshold: chosen mechanically from the pre-declared grid (0.025, 0.05, 0.10): the LARGEST
  value whose DEV-overfit null pass rate is <= 3.0% under BOTH nulls, the rate measured per
  COUNTED pair (pairs that pass integrity; integrity failures are not trials). None -> STOP.
Stop rule v2 (after the threshold): oracle power at true Sharpe 1.5 must be >= 50% for BOTH
  speeds (applied under both nulls). Otherwise STOP.

Reduced pipeline (stated in the output): G8 not run (no extended universe in synthetic worlds;
G8 can only veto, so null pass rates are upper bounds); determinism and lookahead checks skipped
for the families (code properties, independent of the world). Weight validity, liquidation
(mark price), activity (decisions), G1-G7 and G9 run as in the evaluator with the full 200
permutation shifts and 12 jitter perturbations.

Results: ledger/calibration_<kernel_hash16>.json. The calibration never changes a gate or
constant by itself; the G6 threshold it selects is written into the kernel by a human-approved
re-key.
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
import math
import multiprocessing as mp
import time
from pathlib import Path

import numpy as np
import pandas as pd

from omr import access
from omr import constants as C
from omr import data
from omr import datasets as D
from omr import integrity as I
from omr import kernel_lock
from omr import ledger
from omr import paths as P
from omr import pipeline
from omr import stats as S
from omr.runner import InProcessRunner

DEFAULT_FAMILIES = ["gen000_sma_cross_ls", "gen000_donchian_ls", "gen000_rsi_meanrev_ls",
                    "gen000_voltarget_trend_ls", "gen000_funding_carry"]
N_DRAWS = 20
P_GRID = (0.025, 0.05, 0.10)
NULL_MAX = 0.03
POWER_MIN = 0.50
SPEEDS = {"fast": 1, "slow": 20}
LEVELS = (1.0, 1.5)
RHO_GRID = np.round(np.concatenate([np.linspace(0.0, 0.2, 41), np.linspace(0.22, 1.0, 40)]), 6)
HOUR_NS = 3_600_000_000_000
DAY_NS = 24 * HOUR_NS
OTHER = ["volume", "quote_volume", "trades", "taker_buy_volume", "taker_buy_quote_volume"]
GATES = ["G1", "G2", "G3", "G4", "G5", "G6", "G7", "G9"]
SEEDS = {"A": 1000, "B": 4000, "oracle_scale_A": 5000, "oracle_scale_B": 6000, "oracle_A": 7000, "oracle_B": 8000}


def T(s) -> pd.Timestamp:
    return pd.Timestamp(s, tz="UTC").as_unit("ns")


# ---------------------------------------------------------------- source days

class Source:
    """Real core data as whole UTC days, each bar stored as open-relative ratios.

    Per symbol, over its calendar from its first full day to VAL end:
      g  = open / previous close, hr = high / open, lr = low / open, cr = close / open
      mark: gm = mark open / previous mark close (NaN if unknown), hm, lm, cm (NaN if no mark bar)
    m (mean hourly close-to-close log return over DEV+VAL) for last price and for mark.
    """

    def __init__(self, handle):
        a, b = T(C.DEV_START), T(C.VAL_END)
        self.sym = {}
        for s in C.CORE:
            kl = D.load_raw("klines", s, upto="val_end", handle=handle)
            fu = D.load_raw("funding", s, upto="val_end", handle=handle)
            mk = D.load_raw("mark_klines", s, upto="val_end", handle=handle)
            first_full = (kl.index[0] + pd.Timedelta(hours=23)).normalize()
            seg = kl.loc[first_full:b]
            nd = len(seg) // 24
            if len(seg) != nd * 24:
                raise RuntimeError(f"{s}: not a whole number of days")
            o = seg["open"].to_numpy(dtype=np.float64)
            h = seg["high"].to_numpy(dtype=np.float64)
            lo = seg["low"].to_numpy(dtype=np.float64)
            c = seg["close"].to_numpy(dtype=np.float64)
            pc = np.r_[kl.loc[:first_full - pd.Timedelta(hours=1), "close"].iloc[-1], c[:-1]]
            m = mk.reindex(seg.index)
            mo, mh, ml, mc = (m[k].to_numpy(dtype=np.float64) for k in ("open", "high", "low", "close"))
            mpc = np.r_[np.nan, mc[:-1]]
            has = np.isfinite(mo) & np.isfinite(mh) & np.isfinite(ml) & np.isfinite(mc) & (mo > 0) & (ml > 0)
            with np.errstate(divide="ignore", invalid="ignore"):
                gm = np.where(has & np.isfinite(mpc) & (mpc > 0), mo / mpc, np.nan)
                hm, lm, cm = (np.where(has, x / mo, np.nan) for x in (mh, ml, mc))
            dv = (seg.index >= a) & (seg.index <= b)
            lr_close = np.log(c / pc)
            m_last = float(np.mean(lr_close[dv]))
            with np.errstate(divide="ignore", invalid="ignore"):
                mlr = np.log(mc / mpc)
            ok = dv & np.isfinite(mlr)
            m_mark = float(np.mean(mlr[ok])) if ok.any() else m_last
            f = fu.loc[first_full:b]
            ft = data.ns_int(f.index)
            fday = ((ft - data.ns_int(seg.index[:1])[0]) // DAY_NS).astype(np.int64)
            order = np.argsort(fday, kind="mergesort")
            fday = fday[order]
            self.sym[s] = {
                "days": pd.DatetimeIndex(seg.index[::24]), "nd": nd,
                "g": (o / pc).reshape(nd, 24), "hr": (h / o).reshape(nd, 24), "lr": (lo / o).reshape(nd, 24),
                "cr": (c / o).reshape(nd, 24),
                "gm": gm.reshape(nd, 24), "hm": hm.reshape(nd, 24), "lm": lm.reshape(nd, 24), "cm": cm.reshape(nd, 24),
                "has": has.reshape(nd, 24),
                "other": seg[OTHER].to_numpy(dtype=np.float64).reshape(nd, 24, len(OTHER)),
                "gap": seg["is_gap"].to_numpy().reshape(nd, 24),
                "fhour": ((ft[order] % DAY_NS) // HOUR_NS).astype(np.int64),
                "frate": f["rate"].to_numpy()[order], "fint": f["interval_hours"].to_numpy()[order],
                "offs": np.searchsorted(fday, np.arange(nd + 1)),
                "p0": float(pc[0]), "mp0": float(mk["close"].loc[:first_full - pd.Timedelta(hours=1)].iloc[-1])
                if len(mk.loc[:first_full - pd.Timedelta(hours=1)]) else float(pc[0]),
                "m": m_last, "m_mark": m_mark,
            }
        # DEV+VAL calendar dates shared by all core symbols: the null-A sampling pool
        self.pool = pd.date_range(a, b.normalize(), freq="D").as_unit("ns")


def _synth_symbol(v: dict, src_days: np.ndarray, flip: np.ndarray, extra: tuple):
    """Build klines / mark / funding tables for one symbol from source day indices (into v's
    calendar) and per-day mirror flags. Returns (frame, liq)."""
    nd = len(src_days)
    g, hr, lr, cr = (v[k][src_days].copy() for k in ("g", "hr", "lr", "cr"))
    gm, hm, lm, cm = (v[k][src_days].copy() for k in ("gm", "hm", "lm", "cm"))
    has = v["has"][src_days].copy()
    F = flip[:, None]
    # mirror the demeaned path: log g' = 2m - log g ; hr' = 1/lr ; lr' = 1/hr ; cr' = 1/cr
    g = np.where(F, np.exp(2 * v["m"]) / g, g)
    hr, lr = np.where(F, 1.0 / lr, hr), np.where(F, 1.0 / hr, lr)
    cr = np.where(F, 1.0 / cr, cr)
    gm = np.where(F, np.exp(2 * v["m_mark"]) / gm, gm)
    hm, lm = np.where(F, 1.0 / lm, hm), np.where(F, 1.0 / hm, lm)
    cm = np.where(F, 1.0 / cm, cm)
    g, hr, lr, cr = (x.reshape(-1) for x in (g, hr, lr, cr))
    gm, hm, lm, cm, has = (x.reshape(-1) for x in (gm, hm, lm, cm, has))
    step = g * cr
    prev_c = v["p0"] * np.r_[1.0, np.cumprod(step)[:-1]]
    o = prev_c * g
    start = v["days"][0]
    idx = pd.date_range(start, periods=nd * 24, freq="h").as_unit("ns")
    idx.name = "open_time"
    kl = pd.DataFrame({"open": o, "high": o * hr, "low": o * lr, "close": o * cr}, index=idx)
    oth = v["other"][src_days].reshape(nd * 24, len(OTHER))
    for j, c in enumerate(OTHER):
        kl[c] = oth[:, j]
    kl["is_gap"] = v["gap"][src_days].reshape(-1)
    # mark: chain on mark returns where known, last-price returns where not; rows only where has
    gm_eff = np.where(np.isfinite(gm), gm, g)
    cm_eff = np.where(has, cm, cr)
    mstep = gm_eff * cm_eff
    mprev = v["mp0"] * np.r_[1.0, np.cumprod(mstep)[:-1]]
    mo = mprev * gm_eff
    mark = pd.DataFrame({"open": mo, "high": mo * hm, "low": mo * lm, "close": mo * cm,
                         "samples": 3600.0}, index=idx)[has]
    # funding: the source day's settlements at the same hours of the synthetic day
    sel = np.concatenate([np.arange(v["offs"][p], v["offs"][p + 1]) for p in src_days])
    day_of = np.concatenate([np.full(v["offs"][p + 1] - v["offs"][p], i) for i, p in enumerate(src_days)])
    ft = data.ns_int(idx[:1])[0] + day_of * DAY_NS + v["fhour"][sel] * HOUR_NS
    fu = pd.DataFrame({"rate": v["frate"][sel], "interval_hours": v["fint"][sel], "offset_ms": 0.0},
                      index=pd.DatetimeIndex(pd.to_datetime(ft, unit="ns", utc=True)).as_unit("ns"))
    fu.index.name = "settle_time"
    raw = {"klines": kl, "funding": fu, "mark_klines": mark}
    frame = D.assemble_frame(raw, tuple(extra))
    liq = D.liquidation_ratios(kl, mark)
    return frame, liq


def build_world(src: Source, null: str, seed: int, extra=()) -> pipeline.World:
    """null 'A': iid day bootstrap from DEV+VAL; null 'B': real day order with daily mirror coins."""
    rng = np.random.default_rng([seed, 11 if null == "A" else 12])
    syms = list(src.sym)
    start = min(src.sym[s]["days"][0] for s in syms)
    cal = pd.date_range(start, T(C.VAL_END).normalize(), freq="D").as_unit("ns")
    ncal = len(cal)
    if null == "A":
        pick_date = src.pool[rng.integers(0, len(src.pool), ncal)]
        flips = np.zeros(ncal, dtype=bool)
    elif null == "B":
        pick_date = cal
        flips = rng.uniform(size=ncal) < 0.5
    else:
        raise ValueError(null)
    frames, liqs = {}, {}
    for s in syms:
        v = src.sym[s]
        d0 = int((v["days"][0] - cal[0]) / pd.Timedelta(days=1))
        src_days = ((pick_date[d0:] - v["days"][0]) // pd.Timedelta(days=1)).astype(np.int64)
        src_days = np.asarray(src_days)
        frames[s], liqs[s] = _synth_symbol(v, src_days, flips[d0:], extra)
    return pipeline.World(core=frames, symbols=C.CORE, liq=liqs)


# ---------------------------------------------------------------- noisy oracle

def oracle_weights(world: pipeline.World, k_days: int, rhos, eps_seed) -> dict:
    """{rho: decision-weight DataFrame on the core grid} for a noisy oracle of speed k_days.
    The same eps draws are used for every rho (smooth calibration curves)."""
    grid = pipeline.core_grid(world.core, world.symbols)
    mk = pipeline.Market(world, grid)
    K = len(world.symbols)
    step = 24 * k_days
    starts = np.arange(mk.dev_s, mk.val_e, step)
    ends = np.minimum(starts + step, mk.val_e)
    rng = np.random.default_rng(eps_seed)
    zs, eps = [], []
    for j in range(K):
        o = mk.op[:, j]
        R = np.log(o[ends] / o[starts])
        sd = R.std(ddof=1)
        zs.append((R - R.mean()) / sd if sd > 0 else np.zeros_like(R))
        eps.append(rng.standard_normal(len(R)))
    out = {}
    for rho in rhos:
        Wn = np.zeros((len(grid), K))
        for j in range(K):
            x = rho * zs[j] + math.sqrt(max(0.0, 1.0 - rho * rho)) * eps[j]
            sgn = np.where(x >= 0, 1.0, -1.0) / K
            for b in range(len(starts)):
                Wn[starts[b] - 1: ends[b] - 1, j] = sgn[b]
            Wn[ends[-1] - 1:, j] = sgn[-1]
        out[float(rho)] = pd.DataFrame(Wn, index=grid, columns=list(world.symbols))
    return out


def oracle_val_sharpe(world, W: pd.DataFrame) -> float:
    mk = pipeline.Market(world, W.index)
    r = mk.run(W.to_numpy(), mk.dev_s, mk.val_e)
    return pipeline.val_sharpe_of(r)


# ---------------------------------------------------------------- workers

_W = {}
OPTS = pipeline.Opts(full_integrity=False, include_g8=False, keep_detail=False)


def _init(paths, handle):
    _W["handle"] = handle
    _W["src"] = Source(handle)
    _W["strats"] = {Path(p).stem: I.load_trusted(p) for p in paths}


def _seed(*parts) -> int:
    return int(ledger.sha256_text("|".join(str(x) for x in parts))[:15], 16)


def _spec(ld) -> pipeline.Spec:
    return pipeline.Spec(kind=ld.meta["kind"], datasets=tuple(ld.meta.get("datasets", ())), params=ld.meta["params"])


def draw_params(ld, rng) -> dict:
    out = {}
    for k, p in ld.meta["params"].items():
        out[k] = int(rng.integers(int(p["low"]), int(p["high"]) + 1)) if p["kind"] == "int" \
            else float(rng.uniform(p["low"], p["high"]))
    return out


def trusted_weights(ld, world, params) -> pd.DataFrame:
    """Weights of a TRUSTED built-in family, in-process (calibration only)."""
    spec = _spec(ld)
    grid = pipeline.core_grid(world.core, world.symbols)
    fl = pipeline.job_frames(spec.kind, world.core, world.symbols, grid)
    outs = pipeline.full_outs(InProcessRunner(ld.obj, spec.kind), spec, params, fl)
    return pd.DataFrame(pipeline.to_grid(spec.kind, fl, outs, grid, 0, len(grid) - 1, from_start=True), index=grid)


def dev_sharpe(ld, world, params) -> float:
    try:
        W = trusted_weights(ld, world, params)
    except Exception:
        return float("-inf")
    mk = pipeline.Market(world, W.index)
    r = mk.run(np.nan_to_num(W.to_numpy(), nan=0.0), mk.dev_s, mk.dev_e)
    if r.liquidated:
        return float("-inf")
    return S.sharpe(r.daily_returns())


def _summ(res, extra) -> dict:
    out = dict(extra)
    out["status"] = "evaluated" if res["status"] == "evaluated" else "integrity_fail"
    if res["status"] != "evaluated":
        out["integrity_reason"] = res["integrity"]["reason"]
        out["tier1_at_run"] = False
    else:
        out["tier1_at_run"] = res["tier"] == "tier1"
        out["gates"] = {k: v["pass"] for k, v in res["gates"].items() if not v.get("not_run")}
        out["perm_p"] = res["gates"]["G6"]["value"]
        out["val_sharpe"] = res["metrics"]["val"]["sharpe"]
        out["dev_sharpe"] = res["metrics"]["dev"]["sharpe"]
        out["psr0"] = res["metrics"]["val"]["psr0"]
        out["decisions"] = res["metrics"]["decisions"]
        out["decisions_val"] = res["metrics"]["decisions_val"]
        out["rebalances"] = res["metrics"]["rebalances"]
        if "liquidated" in res["integrity"]["checks"]:
            out["liquidated"] = bool(res["integrity"]["checks"]["liquidated"])
    return out


def task_null(args) -> list:
    null, world_seed = args
    src, strats = _W["src"], _W["strats"]
    out, worlds = [], {}
    for fam, ld in strats.items():
        extra = tuple(ld.meta.get("datasets", ()))
        if extra not in worlds:
            worlds[extra] = build_world(src, null, world_seed, extra)
        world = worlds[extra]
        rng = np.random.default_rng(_seed("draws", null, fam, world_seed))
        best, best_sh = None, float("-inf")
        for _ in range(N_DRAWS):
            q = draw_params(ld, rng)
            sh = dev_sharpe(ld, world, q)
            if best is None or sh > best_sh:
                best, best_sh = q, sh
        res = pipeline.evaluate_world(InProcessRunner(ld.obj, ld.meta["kind"]), _spec(ld), best, world,
                                      _seed("null", null, fam, world_seed), OPTS, _W["handle"])
        out.append(_summ(res, {"null": null, "family": fam, "world_seed": world_seed, "params": best,
                               "best_dev_sharpe_of_20": best_sh}))
    return out


def task_oracle_curve(args) -> dict:
    null, world_seed, speed = args
    world = build_world(_W["src"], null, world_seed, ())
    ws = oracle_weights(world, SPEEDS[speed], RHO_GRID, _seed("eps", null, world_seed, speed))
    return {"world_seed": world_seed, "sharpes": [oracle_val_sharpe(world, ws[float(r)]) for r in RHO_GRID]}


def task_oracle_check(args) -> float:
    null, world_seed, speed, rho = args
    world = build_world(_W["src"], null, world_seed, ())
    W = oracle_weights(world, SPEEDS[speed], [rho], _seed("eps", null, world_seed, speed))[float(rho)]
    return oracle_val_sharpe(world, W)


def task_oracle_power(args) -> list:
    null, world_seed, rhos = args      # rhos: {(speed, level): rho}
    world = build_world(_W["src"], null, world_seed, ())
    out = []
    for speed in SPEEDS:
        lv = {lvl: rhos[f"{speed}|{lvl}"] for lvl in LEVELS}
        ws = oracle_weights(world, SPEEDS[speed], list(lv.values()), _seed("eps", null, world_seed, speed))
        for lvl, rho in lv.items():
            res = pipeline.evaluate_weights(ws[float(rho)], world, _seed("oracle", null, world_seed, speed, lvl), OPTS,
                                            _W["handle"])
            out.append(_summ(res, {"null": null, "speed": speed, "level": lvl, "rho": rho, "world_seed": world_seed}))
    return out


# ---------------------------------------------------------------- summaries

def tier_at(row: dict, p_max: float) -> bool:
    """Tier 1 re-read at G6 threshold p_max from stored gate outcomes and the p-value."""
    if row["status"] != "evaluated":
        return False
    return all(v for k, v in row["gates"].items() if k != "G6") and row["perm_p"] <= p_max + 1e-12


def gate_rates(rows: list, p_max: float) -> dict:
    ev = [r for r in rows if r["status"] == "evaluated"]
    out = {}
    for g in GATES:
        if not ev:
            out[g] = None
        elif g == "G6":
            out[g] = sum(r["perm_p"] <= p_max + 1e-12 for r in ev) / len(ev)
        else:
            out[g] = sum(r["gates"][g] for r in ev) / len(ev)
    return out


def null_summary(rows: list, families: list) -> dict:
    out = {"n_pairs": len(rows), "n_evaluated": sum(r["status"] == "evaluated" for r in rows),
           "integrity_fail": {}, "by_threshold": {}}
    for r in rows:
        if r["status"] == "integrity_fail":
            out["integrity_fail"][r["integrity_reason"]] = out["integrity_fail"].get(r["integrity_reason"], 0) + 1
    n_counted = out["n_evaluated"]
    for t in P_GRID:
        passers = [r for r in rows if tier_at(r, t)]
        out["by_threshold"][str(t)] = {
            "tier1": len(passers),
            # per COUNTED trial (integrity failures are not trials): the rate the selection rule uses
            "pass_rate": len(passers) / n_counted if n_counted else None,
            # per pair including integrity failures (reported for comparison)
            "pass_rate_all_pairs": len(passers) / len(rows) if rows else None,
            "passer_families": {f: sum(1 for r in passers if r["family"] == f) for f in families},
            "passers": [{"family": r["family"], "world_seed": r["world_seed"], "params": r["params"],
                         "perm_p": r["perm_p"], "val_sharpe": r["val_sharpe"]} for r in passers],
            "gate_pass_rate": gate_rates(rows, t),
        }
    out["per_family_integrity_fail"] = {f: {} for f in families}
    for r in rows:
        if r["status"] == "integrity_fail":
            d = out["per_family_integrity_fail"][r["family"]]
            d[r["integrity_reason"]] = d.get(r["integrity_reason"], 0) + 1
    return out


def oracle_summary(rows: list) -> dict:
    out = {}
    for speed in SPEEDS:
        for lvl in LEVELS:
            rr = [r for r in rows if r["speed"] == speed and r["level"] == lvl]
            key = f"{speed}|{lvl}"
            fin = [r["val_sharpe"] for r in rr if np.isfinite(r["val_sharpe"])]
            out[key] = {"n": len(rr), "mean_val_sharpe": float(np.mean(fin)) if fin else None,
                        "liquidated": int(sum(1 for r in rr if r.get("liquidated"))),
                        "by_threshold": {str(t): {"power": (sum(tier_at(r, t) for r in rr) / len(rr)) if rr else None,
                                                  "tier1": int(sum(tier_at(r, t) for r in rr)),
                                                  "gate_pass_rate": gate_rates(rr, t)} for t in P_GRID}}
    return out


def calibrate_rho(pool, null: str, speed: str, n_worlds: int, log) -> dict:
    seeds = [SEEDS[f"oracle_scale_{null}"] + i for i in range(n_worlds)]
    curves = pool.map(task_oracle_curve, [(null, s, speed) for s in seeds])
    mat = np.array([c["sharpes"] for c in curves], dtype=np.float64)
    mat = np.where(np.isfinite(mat), mat, np.nan)
    mean = np.nanmean(mat, axis=0)
    out = {"mean_curve": {f"{r:.4f}": float(m) for r, m in zip(RHO_GRID, mean)}}
    for lvl in LEVELS:
        idx = np.nonzero(mean >= lvl)[0]
        if len(idx) == 0:
            rho = float(RHO_GRID[-1])
        elif idx[0] == 0:
            rho = float(RHO_GRID[0])
        else:
            i = idx[0]
            r0, r1, m0, m1 = RHO_GRID[i - 1], RHO_GRID[i], mean[i - 1], mean[i]
            rho = float(r0 + (lvl - m0) * (r1 - r0) / (m1 - m0)) if m1 != m0 else float(r1)
        chk = np.array(pool.map(task_oracle_check, [(null, s, speed, rho) for s in seeds]))
        out[str(lvl)] = {"rho": rho, "achieved_mean_val_sharpe": float(np.nanmean(chk[np.isfinite(chk)]))}
        log(f"    null {null} {speed:4s} target {lvl}: rho {rho:.4f} -> mean VAL Sharpe "
            f"{out[str(lvl)]['achieved_mean_val_sharpe']:.3f} on {n_worlds} scaling worlds")
    out["mean_val_sharpe_at_rho0"] = float(mean[0])
    return out


def decide(nulls: dict, oracle: dict) -> dict:
    """Mechanical G6 threshold choice and stop rule v2.

    Null pass rate = Tier-1 passes / COUNTED pairs (pairs that passed integrity): an integrity
    failure is not a trial and costs the researcher nothing, so the false-positive rate that
    matters is per counted trial. (The rate per all pairs is reported alongside.) Choose the
    LARGEST grid value whose null pass rate is <= NULL_MAX under BOTH nulls; none -> STOP.
    Then oracle power at true Sharpe 1.5 must be >= POWER_MIN for both speeds under both nulls.
    """
    rate = lambda n, t, k="pass_rate": nulls[n]["summary"]["by_threshold"][str(t)][k]
    qualifying = [t for t in P_GRID if all(rate(n, t) <= NULL_MAX + 1e-12 for n in ("A", "B"))]
    qualifying_all_pairs = [t for t in P_GRID if all(rate(n, t, "pass_rate_all_pairs") <= NULL_MAX + 1e-12
                                                     for n in ("A", "B"))]
    chosen = max(qualifying) if qualifying else None
    verdict = {"grid": list(P_GRID), "null_max": NULL_MAX, "denominator": "counted pairs (passed integrity)",
               "null_pass_rate": {n: {str(t): rate(n, t) for t in P_GRID} for n in ("A", "B")},
               "null_pass_rate_all_pairs": {n: {str(t): rate(n, t, "pass_rate_all_pairs") for t in P_GRID}
                                            for n in ("A", "B")},
               "qualifying": qualifying, "chosen_threshold": chosen,
               "for_comparison_all_pairs_reading": {"qualifying": qualifying_all_pairs,
                                                    "chosen": max(qualifying_all_pairs) if qualifying_all_pairs else None}}
    if chosen is None:
        verdict["STOP"] = True
        verdict["reason"] = "no G6 threshold in the grid keeps the null pass rate <= 3% under both nulls"
        return verdict
    power15 = {n: {s: oracle[n]["summary"][f"{s}|1.5"]["by_threshold"][str(chosen)]["power"] for s in SPEEDS}
               for n in ("A", "B")}
    verdict["power_at_1_5_chosen"] = power15
    below = [f"{n}/{s}" for n in power15 for s in power15[n] if power15[n][s] < POWER_MIN]
    verdict["below_power_min"] = below
    verdict["STOP"] = bool(below)
    verdict["rule_v2"] = "at the chosen threshold, oracle power at true Sharpe 1.5 >= 50% for BOTH speeds (under both nulls)"
    return verdict


def reread(path: Path, log=print) -> dict:
    """Recompute summaries and the verdict from the stored per-pair rows (no re-run)."""
    c = json.loads(Path(path).read_text(encoding="ascii"))
    fams = list(c["families"])
    for n in ("A", "B"):
        c["nulls"][n]["summary"] = null_summary(c["nulls"][n]["rows"], fams)
        c["oracle"][n]["summary"] = oracle_summary(c["oracle"][n]["rows"])
    if "verdict_at_run" not in c:
        c["verdict_at_run"] = c["verdict"]
    c["verdict"] = decide(c["nulls"], c["oracle"])
    c["reread_at"] = dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    c["reread_by_kernel_hash"] = kernel_lock.kernel_hash()
    Path(path).write_text(json.dumps(ledger.clean(c), indent=1, sort_keys=True), encoding="ascii")
    log(json.dumps(ledger.clean(c["verdict"]), indent=1))
    return c


def main(argv=None):
    ap = argparse.ArgumentParser(prog="python -m omr.calibrate")
    ap.add_argument("--reread", default=None, help="recompute the verdict from a stored calibration file")
    ap.add_argument("--worlds", type=int, default=100, help="null worlds per null (x 5 families = pairs)")
    ap.add_argument("--oracle-scale-worlds", type=int, default=60)
    ap.add_argument("--oracle-worlds", type=int, default=100)
    ap.add_argument("--workers", type=int, default=6)
    ap.add_argument("--families", nargs="*", default=None)
    a = ap.parse_args(argv)
    t0 = time.time()
    log = lambda s: print(s, flush=True)
    if a.reread:
        reread(Path(a.reread), log)
        return
    kh = kernel_lock.kernel_hash()
    lock_ok = not kernel_lock.verify()
    manifest = data.load_manifest()
    paths = a.families or [str(P.STRATEGIES_DIR / f"{f}.py") for f in DEFAULT_FAMILIES]
    fams = [Path(p).stem for p in paths]
    log(f"calibration v2: kernel {kh[:16]} (lock {'OK' if lock_ok else 'not verified'}), "
        f"research_hash {manifest['research_hash'][:16]}, G6 at run time {C.PERM_P_MAX}")
    handle = access.for_calibration(f"calibration protocol v2, kernel {kh[:16]}: synthetic worlds built from "
                                    "DEV+VAL bars; no real-strategy VAL result is computed")
    ctx = mp.get_context("spawn")
    nulls, oracle = {}, {}
    with ctx.Pool(a.workers, initializer=_init, initargs=(paths, handle)) as pool:
        for null in ("A", "B"):
            log(f"[null {null}] {a.worlds} worlds x {len(fams)} families, best-of-{N_DRAWS} DEV selection")
            rows = []
            for i, rr in enumerate(pool.imap_unordered(task_null, [(null, SEEDS[null] + i) for i in range(a.worlds)])):
                rows.extend(rr)
                if (i + 1) % 20 == 0:
                    log(f"    {i + 1}/{a.worlds} worlds")
            rows.sort(key=lambda r: (r["world_seed"], r["family"]))
            nulls[null] = {"rows": rows, "summary": null_summary(rows, fams)}
            for t in P_GRID:
                b = nulls[null]["summary"]["by_threshold"][str(t)]
                n_c = nulls[null]["summary"]["n_evaluated"]
                rate = "n/a" if b["pass_rate"] is None else f"{b['pass_rate']:.4f}"
                log(f"    null {null} p<={t}: {b['tier1']}/{n_c} counted = {rate} ({len(rows)} pairs)  "
                    f"passers {b['passer_families']}  integrity_fail {nulls[null]['summary']['integrity_fail']}")
        for null in ("A", "B"):
            log(f"[oracle {null}] calibrating rho on {a.oracle_scale_worlds} separate worlds")
            rhos, scal = {}, {}
            for speed in SPEEDS:
                scal[speed] = calibrate_rho(pool, null, speed, a.oracle_scale_worlds, log)
                for lvl in LEVELS:
                    rhos[f"{speed}|{lvl}"] = scal[speed][str(lvl)]["rho"]
            log(f"[oracle {null}] power on {a.oracle_worlds} fresh worlds")
            rows = []
            for rr in pool.imap_unordered(task_oracle_power,
                                          [(null, SEEDS[f"oracle_{null}"] + i, rhos) for i in range(a.oracle_worlds)]):
                rows.extend(rr)
            rows.sort(key=lambda r: (r["world_seed"], r["speed"], r["level"]))
            oracle[null] = {"rhos": rhos, "scaling": scal, "rows": rows, "summary": oracle_summary(rows)}
            for key, sm in oracle[null]["summary"].items():
                log(f"    null {null} {key}: mean VAL SR {sm['mean_val_sharpe']:.3f}  power " +
                    "  ".join(f"p<={t}: {sm['by_threshold'][str(t)]['tier1']}/{sm['n']}" for t in P_GRID))

    verdict = decide(nulls, oracle)
    out = {"protocol_version": 2, "kernel_hash": kh, "kernel_lock_verified": lock_ok,
           "research_hash": manifest["research_hash"], "perm_p_max_at_run": C.PERM_P_MAX,
           "created_at": dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
           "families": {f: ledger.sha256_file(Path(p)) for f, p in zip(fams, paths)},
           "protocol": {"worlds_per_null": a.worlds, "draws_per_pair": N_DRAWS,
                        "oracle_scale_worlds": a.oracle_scale_worlds, "oracle_worlds": a.oracle_worlds,
                        "speeds_days": SPEEDS, "levels": list(LEVELS), "seeds": SEEDS,
                        "reduced_pipeline": "G8 not run (upper bound); determinism/lookahead skipped for families; "
                                            "oracles bypass integrity, G5/G9 pass by definition"},
           "nulls": nulls, "oracle": oracle, "verdict": verdict, "wall_seconds": round(time.time() - t0, 1)}
    P.LEDGER_DIR.mkdir(parents=True, exist_ok=True)
    path = P.LEDGER_DIR / f"calibration_{kh[:16]}.json"
    path.write_text(json.dumps(ledger.clean(out), indent=1, sort_keys=True), encoding="ascii")
    log(f"saved {path}")
    log(json.dumps(ledger.clean(verdict), indent=1))
    log(f"wall time {out['wall_seconds']} s")


if __name__ == "__main__":
    main()
