"""omr: kernel of the crypto trading research system (kernel v1).

Everything in this package is KERNEL: the research loop may not edit it.
Changes happen only through a human-approved re-key (python -m omr.kernel_lock rekey).
"""

KERNEL_VERSION = "1"
