"""Evaluator: python -m omr.evaluate <strategy_file> --generation N

Order (count before exposure):
1. Kernel lock, ledger HEAD and data checks.
2. Static parse of the source (AST allowlist, metadata and params from literals, param rules).
   Failure -> one `integrity_fail` row with a fixed reason code, not counted.
3. Stage 1 on DEV-only frames in child processes (base run, validity, determinism, lookahead on DEV
   cuts, invariance). Failure -> one `integrity_fail` row, not counted. No VAL bar has reached
   strategy code.
4. A COUNTED `pending` row is appended and flushed; it issues the trial's ValHandle.
5. Stage 2 on DEV+VAL frames (counted whatever happens). Result files are written, then the final
   row: `evaluated` (with tier) or `integrity_fail_val` (fixed reason code, no metric).
Trial identity = sha256(normalised source + params + kernel hash + research_hash)[:16].
No strategy-produced text reaches the ledger or the screen.
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
import os
import secrets
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd

from omr import constants as C
from omr import data
from omr import datasets as D
from omr import integrity as I
from omr import kernel_lock
from omr import ledger
from omr import paths as P
from omr import pipeline
from omr import stats as S
from omr.runner import ChildRunner

LOCK = P.LEDGER_DIR / ".evaluate.lock"


def trial_id_for(source: str, params, kernel_hash: str, research_hash: str) -> str:
    body = I.normalise_source(source) + "\n" + ledger.canonical(params) + "\n" + kernel_hash + "\n" + research_hash
    return ledger.sha256_text(body)[:16]


class DiskProvider:
    """Real data from data/. DEV frames need no handle; VAL frames need the trial's handle."""

    def check(self) -> str:
        manifest = data.load_manifest()
        rh = data.research_hash_from_disk(manifest)
        if rh != manifest["research_hash"]:
            raise SystemExit("DATA MISMATCH: stored data does not match data/manifest.json research_hash. Refusing.")
        return rh

    def dev_frames(self, extra: tuple) -> dict:
        return D.load_frames(C.CORE, extra, upto="dev_end")

    def val_world(self, extra: tuple, handle) -> pipeline.World:
        core = D.load_frames(C.CORE, extra, upto="val_end", handle=handle)
        ext = D.load_frames(C.EXTENDED, extra, upto="val_end", handle=handle)
        liq = D.load_liqs(C.ALL_SYMBOLS, upto="val_end", handle=handle)
        return pipeline.World(core=core, extended=ext, symbols=C.CORE, liq=liq)


def dsr_for(trial_id: str, daily: pd.Series) -> dict:
    """DSR of this trial's VAL returns. M = every counted trial (pending rows, this one included,
    with or without stored returns); V and rho only from counted trials with stored returns."""
    mat = ledger.counted_val_matrix(extra={trial_id: daily})
    val = ledger.val_slice(daily)
    sh = [S.sharpe_daily(mat[c]) for c in mat.columns]
    rho = S.mean_pairwise_corr(mat)
    M = max(len(ledger.counted_ids()), mat.shape[1])
    return S.dsr(val.to_numpy(), sh, rho, M)


def _fmt(x, nd=3):
    if isinstance(x, (int, np.integer)):
        return str(int(x))
    if isinstance(x, (float, np.floating)):
        return f"{x:.{nd}f}"
    return str(x)


def print_result(row: dict):
    print(f"trial {row['trial_id']}  {row.get('strategy_name')}  gen {row.get('generation')}  status {row['status']}")
    if row["status"] != "evaluated":
        print(f"  reason: {row.get('reason')}")
        print("  counted: " + ("YES (VAL was exposed)" if row["status"] in ("integrity_fail_val", "pending") else "no"))
        return
    print(f"  tier: {row['tier']}")
    print(f"  DEV Sharpe {_fmt(row['dev_sharpe'])}  VAL Sharpe {_fmt(row['val_sharpe'])}  PSR(0) {_fmt(row['psr0'])}  "
          f"DSR {_fmt(row['dsr'])} (M={row['M']} N={_fmt(row['N'], 2)} rho={_fmt(row['rho'], 2)})")
    print(f"  VAL maxDD {_fmt(row['val_max_drawdown'])}  DEV+VAL maxDD {_fmt(row['dev_val_max_drawdown'])}  "
          f"deploy_scale {_fmt(row['deploy_scale'])}  decisions {row['decisions']} (VAL {row['decisions_val']})  "
          f"rebalances {row['rebalances']}")
    print(f"  benchmark (info): VAL Sharpe {_fmt(row['benchmark_val_sharpe'])}  VAL maxDD {_fmt(row['benchmark_val_max_drawdown'])}")
    for g, ok in row["gates"].items():
        print(f"  {g} {'PASS' if ok else 'FAIL'}  {row['gate_values'].get(g)}")


def evaluate_file(path: str, generation: int, provider=None, opts: pipeline.Opts | None = None,
                  runner_cls=ChildRunner, quiet: bool = False, require_lock: bool = True) -> dict:
    kh = kernel_lock.require_kernel() if require_lock else kernel_lock.kernel_hash()
    probs = ledger.verify_chain(P.TRIALS_JSONL) if P.TRIALS_JSONL.exists() else []
    if probs:
        print("LEDGER CHAIN/HEAD PROBLEM - refusing to run:")
        for p in probs[:10]:
            print("  " + p)
        sys.exit(6)
    provider = provider or DiskProvider()
    opts = opts or pipeline.Opts()
    rh = provider.check()
    p = Path(path).resolve()
    raw = p.read_bytes()
    try:
        source = raw.decode("ascii")
    except UnicodeDecodeError:
        source = raw.decode("utf-8", "replace")
    parsed = I.parse_source(source)
    violations = list(parsed.violations)
    if parsed.ok:
        violations += I.param_rule_violations(parsed.meta["params"])
    params = I.default_params(parsed.meta["params"]) if parsed.ok else "AST_REJECTED"
    tid = trial_id_for(source, params, kh, rh)
    existing = ledger.find_trial(tid)
    if existing:
        if not quiet:
            print(f"identical trial already in the ledger (not counted again): {tid}")
            print_result(existing)
        return existing
    P.LEDGER_DIR.mkdir(parents=True, exist_ok=True)
    try:
        fd = os.open(str(LOCK), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        os.close(fd)
    except FileExistsError:
        print(f"another evaluation holds {LOCK}; if none is running, delete it and retry")
        sys.exit(5)
    try:
        return _evaluate_locked(p, raw, source, parsed, violations, params, tid, kh, rh, generation,
                                provider, opts, runner_cls, quiet)
    finally:
        try:
            LOCK.unlink()
        except FileNotFoundError:
            pass


def _evaluate_locked(p, raw, source, parsed, violations, params, tid, kh, rh, generation,
                     provider, opts, runner_cls, quiet):
    t0 = time.time()
    born = dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    try:
        rel = p.relative_to(P.ROOT).as_posix()
    except ValueError:
        rel = p.name
    meta = parsed.meta or {}
    row = {"trial_id": tid, "generation": int(generation), "born_at": born, "file": rel,
           "kernel_hash": kh, "research_hash": rh, "params": params,
           "strategy_name": meta.get("name"), "family": meta.get("family"), "kind": meta.get("kind"),
           "hypothesis": meta.get("hypothesis"), "datasets": list(meta.get("datasets", ()))}
    P.TRIAL_SOURCE_DIR.mkdir(parents=True, exist_ok=True)
    src_path = P.TRIAL_SOURCE_DIR / f"{tid}.py"
    src_path.write_bytes(raw)
    row["source_sha256"] = ledger.sha256_file(src_path)

    def stage1_fail(code):
        r = dict(row, status="integrity_fail", stage=1, reason=code, eval_seconds=round(time.time() - t0, 1))
        written = ledger.append(P.TRIALS_JSONL, r)
        if not quiet:
            print_result(written)
        return written

    if violations:
        if not quiet:
            for code, msg in violations[:20]:
                print(f"  {code}: {msg}")
        return stage1_fail(violations[0][0])
    spec = pipeline.Spec(kind=meta["kind"], datasets=tuple(meta.get("datasets", ())), params=meta["params"])
    for d in spec.datasets:
        if d not in D.REGISTRY:
            return stage1_fail("unknown_dataset")
    runner = runner_cls(source, spec.kind)
    seed = secrets.randbits(63)                       # fresh OS entropy; stored after the fact
    rng = np.random.default_rng(seed)
    frames_dev = provider.dev_frames(spec.datasets)
    s1 = pipeline.stage1(runner, spec, params, frames_dev, C.CORE, opts, rng)
    if not s1["ok"]:
        return stage1_fail(s1["code"])

    # ---- COUNTED from here on: the pending row is on disk before any VAL bar reaches strategy code
    pending, handle = ledger.append_pending(dict(row, stage1_cuts=s1["cuts"]))
    world = provider.val_world(spec.datasets, handle)
    res = pipeline.stage2(runner, spec, params, world, s1["W"], opts, rng, handle, seed)
    final = dict(row, pending_hash=pending["row_hash"], children=getattr(runner, "n_children", 0))
    if res["status"] != "evaluated":
        final.update({"status": "integrity_fail_val", "reason": res["integrity"]["reason"],
                      "eval_seconds": round(time.time() - t0, 1)})
        written = ledger.append(P.TRIALS_JSONL, final)
        if not quiet:
            print_result(written)
        return written
    daily = res["daily_returns"]
    final["returns_sha256"] = ledger.save_returns(tid, daily)
    d = dsr_for(tid, daily)
    m, g, info = res["metrics"], res["gates"], res["info"]
    final.update({
        "status": "evaluated", "tier": res["tier"],
        "gates": {k: v["pass"] for k, v in g.items()},
        "gate_values": {k: v["value"] for k, v in g.items()},
        "dev_sharpe": m["dev"]["sharpe"], "val_sharpe": m["val"]["sharpe"], "psr0": m["val"]["psr0"],
        "dsr": d["dsr"], "M": d["M"], "N": d["N"], "rho": d["rho"], "dsr_V": d["V"], "dsr_sr0_daily": d["sr0_daily"],
        "val_sharpe_daily": m["val_sharpe_daily"], "val_max_drawdown": m["val"]["max_drawdown"],
        "dev_val_max_drawdown": m["dev_val_max_drawdown"], "deploy_scale": m["deploy_scale"],
        "rebalances": m["rebalances"], "rebalances_val": m["rebalances_val"],
        "decisions": m["decisions"], "decisions_val": m["decisions_val"],
        "turnover_per_year": m["turnover_per_year"], "avg_gross_exposure": m["avg_gross_exposure"],
        "benchmark_val_sharpe": info["benchmark_val_sharpe"],
        "benchmark_val_max_drawdown": info["benchmark_val_max_drawdown"],
        "vs_benchmark_beta": info["vs_benchmark_beta"], "vs_benchmark_alpha_ann": info["vs_benchmark_alpha_ann"],
        "vs_benchmark_resid_psr0": info["vs_benchmark_resid_psr0"],
    })
    detail = {"trial_id": tid, "integrity": res["integrity"], "metrics": m, "gates": g, "info": info, "dsr": d,
              "lookahead": {"seed": str(seed), "stage1_cuts": s1["cuts"],
                            "stage2_cuts": res["integrity"]["checks"].get("lookahead_cuts_val")},
              **res.get("detail", {})}
    P.TRIAL_DETAIL_DIR.mkdir(parents=True, exist_ok=True)
    det_path = P.TRIAL_DETAIL_DIR / f"{tid}.json"
    det_path.write_text(json.dumps(ledger.clean(detail), indent=1, sort_keys=True), encoding="ascii")
    final["detail_sha256"] = ledger.sha256_file(det_path)
    final["eval_seconds"] = round(time.time() - t0, 1)
    written = ledger.append(P.TRIALS_JSONL, final)
    if not quiet:
        print_result(written)
        print(f"  evaluation wall time {final['eval_seconds']} s  (child processes {final['children']})")
    return written


def main(argv=None):
    ap = argparse.ArgumentParser(prog="python -m omr.evaluate")
    ap.add_argument("strategy_file")
    ap.add_argument("--generation", type=int, required=True)
    a = ap.parse_args(argv)
    evaluate_file(a.strategy_file, a.generation)


if __name__ == "__main__":
    main()
