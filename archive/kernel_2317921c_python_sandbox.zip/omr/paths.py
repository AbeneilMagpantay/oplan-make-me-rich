"""Filesystem locations. Kernel module."""
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = ROOT / "data"
RAW_DIR = DATA_DIR / "raw"
MANIFEST = DATA_DIR / "manifest.json"

LEDGER_DIR = ROOT / "ledger"
TRIALS_JSONL = LEDGER_DIR / "trials.jsonl"
TRIAL_DETAIL_DIR = LEDGER_DIR / "trials"
TRIAL_SOURCE_DIR = LEDGER_DIR / "sources"
RETURNS_DIR = LEDGER_DIR / "returns"
FORWARD_DIR = LEDGER_DIR / "forward"
KERNEL_HISTORY = LEDGER_DIR / "kernel_history.jsonl"
SANDBOX_LOG = LEDGER_DIR / "sandbox_log.jsonl"
POOL_LOG = LEDGER_DIR / "pool_log.jsonl"
CENSUS_LOG = LEDGER_DIR / "census_log.jsonl"
VAL_ACCESS_LOG = LEDGER_DIR / "val_access_log.jsonl"

KERNEL_LOCK = ROOT / "kernel.lock"
STRATEGIES_DIR = ROOT / "strategies"
GENERATIONS_DIR = ROOT / "generations"
