"""Strategy API (what a genome strategy file implements). Kernel module.

A strategy file defines exactly ONE subclass of `Strategy`:

    from omr.strategy_api import Strategy, Param
    from omr import indicators as ind

    class MyIdea(Strategy):
        name = "gen001_my_idea"          # unique, used in reports
        family = "trend"                 # trend / meanrev / carry / ...
        hypothesis = "pre-registered rationale ..."
        kind = "single"                  # "single" or "portfolio"
        datasets = ()                    # extra datasets beyond klines, e.g. ("funding",)
        params = {"fast": Param(20, 5, 60, "int")}

        def signal(self, bars, p):       # kind "single"
            ...return a pandas Series on bars.index with values in [-1, 1] (NaN = flat)

        def weights(self, panel, p):     # kind "portfolio"
            ...return a DataFrame on the common index, one column per core symbol,
               each in [-1, 1], gross sum(|w|) <= 1 (NaN = flat)

Inputs
- `bars`: one symbol on the 1h grid (index = bar OPEN time, UTC). Columns: open, high,
  low, close, volume, quote_volume, trades, taker_buy_volume, taker_buy_quote_volume,
  is_gap, funding_rate (rate settled at that bar's open, else 0). Declared datasets add
  '<name>.<field>' as-of columns plus '<name>.new' (True where a new row became visible).
- `panel`: dict {symbol: bars} for the core symbols, all on the same index.
- `p`: dict {param name: value}.
- The output at bar t may use information up to and including the CLOSE of bar t.
  The kernel executes it at the OPEN of bar t+1.
- single: the kernel uses weight = signal / number of core symbols for each core symbol.

Rules: at most 6 numeric params, each with default, low, high and kind int/float.
Imports allowed in a strategy file: numpy, pandas, math, omr.strategy_api, omr.indicators.
"""
from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class Param:
    default: float
    low: float
    high: float
    kind: str = "float"   # "int" or "float"


class Strategy:
    name: str = ""
    family: str = ""
    hypothesis: str = ""
    kind: str = "single"
    datasets: tuple = ()
    params: dict = {}

    def signal(self, bars, p):  # pragma: no cover - interface
        raise NotImplementedError

    def weights(self, panel, p):  # pragma: no cover - interface
        raise NotImplementedError


def default_params(strategy) -> dict:
    return {k: (int(v.default) if v.kind == "int" else float(v.default)) for k, v in strategy.params.items()}
