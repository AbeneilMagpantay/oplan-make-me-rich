"""DEV sandbox: python -m omr.sandbox <strategy_file> [--set name=value ...] [--quick]

Free, uncounted exploration on the DEV region only. Data is loaded with the dev_end ceiling, so
nothing after 2022-06-30 23:00 is visible. Strategy code runs in child processes. By default the
full stage-1 integrity checks run (what the evaluator will run before counting a trial); --quick
skips them. Not a trial. Each run appends one line to ledger/sandbox_log.jsonl.
"""
from __future__ import annotations

import argparse
import datetime as dt
import secrets
import sys
from pathlib import Path

import numpy as np

from omr import constants as C
from omr import datasets as D
from omr import integrity as I
from omr import kernel_lock
from omr import ledger
from omr import paths as P
from omr import pipeline
from omr import stats as S
from omr.runner import ChildRunner


def parse_sets(items, params_meta: dict) -> dict:
    p = I.default_params(params_meta)
    for it in items or []:
        k, _, v = it.partition("=")
        if k not in params_meta:
            raise SystemExit(f"unknown param {k}")
        spec = params_meta[k]
        val = float(v)
        if spec["kind"] == "int":
            if not val.is_integer():
                raise SystemExit(f"param {k} is int")
            val = int(val)
        if not (spec["low"] <= val <= spec["high"]):
            raise SystemExit(f"param {k}={val} outside declared [{spec['low']}, {spec['high']}]")
        p[k] = val
    return p


def main(argv=None):
    ap = argparse.ArgumentParser(prog="python -m omr.sandbox")
    ap.add_argument("strategy_file")
    ap.add_argument("--set", action="append", default=[], help="param override name=value (within declared bounds)")
    ap.add_argument("--quick", action="store_true", help="skip the stage-1 integrity checks")
    a = ap.parse_args(argv)
    kh = kernel_lock.require_kernel()
    raw = Path(a.strategy_file).read_bytes()
    source = raw.decode("ascii", "replace")
    parsed = I.parse_source(source)
    viol = list(parsed.violations) + (I.param_rule_violations(parsed.meta["params"]) if parsed.ok else [])
    if viol:
        print("INTEGRITY (static):")
        for code, msg in viol[:20]:
            print(f"  {code}: {msg}")
        sys.exit(1)
    meta = parsed.meta
    params = parse_sets(a.set, meta["params"])
    spec = pipeline.Spec(kind=meta["kind"], datasets=tuple(meta.get("datasets", ())), params=meta["params"])
    core = D.load_frames(C.CORE, spec.datasets, upto="dev_end")
    world = pipeline.World(core=core, symbols=C.CORE, liq=D.load_liqs(C.CORE, upto="dev_end"))
    runner = ChildRunner(source, spec.kind)
    opts = pipeline.Opts(full_integrity=not a.quick)
    s1 = pipeline.stage1(runner, spec, params, core, C.CORE, opts, np.random.default_rng(secrets.randbits(63)))
    if not s1["ok"]:
        print(f"INTEGRITY (stage 1): {s1['code']}")
        sys.exit(1)
    W = s1["W"]
    mk = pipeline.Market(world, W.index)
    Wn = np.nan_to_num(W.to_numpy(), nan=0.0)
    run = mk.run(Wn, mk.dev_s, mk.dev_e)
    daily = run.daily_returns()
    bench = mk.run(np.full_like(Wn, 1.0 / len(C.CORE)), mk.dev_s, mk.dev_e).daily_returns()
    sm = S.summary(daily)
    chg = pipeline.decision_changes(Wn)
    print(f"SANDBOX (DEV only, {C.DEV_START} .. {C.DEV_END}) - not a trial")
    print(f"strategy {meta['name']}  params {params}")
    print("stage-1 checks: " + ("skipped (--quick)" if a.quick else f"OK ({s1['cuts']} lookahead cuts, determinism, invariance)"))
    print(f"DEV Sharpe {sm['sharpe']:.3f}  PSR(0) {sm['psr0']:.3f}  total {sm['total_return']:.3f}  CAGR {sm['cagr']:.3f}  "
          f"maxDD {sm['max_drawdown']:.3f}  Calmar {sm['calmar']:.3f}")
    print(f"decisions (DEV) {int(chg[mk.dev_s - 1: mk.dev_e].sum())}  rebalances {run.n_rebalances}  "
          f"avg gross {run.gross.mean():.3f}  avg net {run.net.mean():.3f}  funding paid {run.funding_paid:.4f}  "
          f"costs {run.ev_cost.sum():.4f}  liquidated {run.liquidated}")
    print(f"benchmark (long 1/K each) DEV Sharpe {S.sharpe(bench):.3f}  maxDD {S.max_drawdown(bench):.3f}")
    print("year   days   return   sharpe   maxDD")
    for r in S.per_year(daily):
        print(f"{r['year']}  {r['n_days']:5d}  {r['return']:7.3f}  {r['sharpe']:7.3f}  {r['max_drawdown']:6.3f}")
    try:
        rel = Path(a.strategy_file).resolve().relative_to(P.ROOT).as_posix()
    except ValueError:
        rel = Path(a.strategy_file).name
    ledger.append(P.SANDBOX_LOG, {"at": dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
                                  "file": rel, "source_sha256": ledger.sha256_text(source),
                                  "strategy_name": meta["name"], "params": params, "kernel_hash": kh,
                                  "dev_sharpe": sm["sharpe"], "rebalances": run.n_rebalances,
                                  "stage1": "skipped" if a.quick else "ok"})


if __name__ == "__main__":
    main()
