"""Forward census of the paper pool: python -m omr.census [--no-update]

1. Updates the data (append only; the research_hash must not change).
2. For each pool member, loads the strategy from the ledger's frozen source copy
   (hash-checked), computes its weights on all data (the "latest" ceiling), and runs the
   engine flat from birth on post-birth bars only. Birth = the later of the trial's
   born_at and its pool admission, rounded up to the next bar open, and never before the
   bar after VAULT_END (vault performance is never computed).
3. Stores forward daily returns (complete UTC days only) raw and at deploy_scale in
   ledger/forward/<trial_id>.parquet, prints days forward / forward return / current
   target weights, and appends a census row only when something changed (idempotent).

This module and omr/data.py are the only kernel modules allowed to use the "latest" ceiling.
"""
from __future__ import annotations

import argparse
import datetime as dt

import numpy as np
import pandas as pd

from omr import constants as C
from omr import data
from omr import datasets as D
from omr import engine as E
from omr import integrity as I
from omr import kernel_lock
from omr import ledger
from omr import paths as P
from omr import access
from omr import pipeline
from omr import pool
from omr import stats as S
from omr.runner import ChildRunner


def T(s) -> pd.Timestamp:
    t = pd.Timestamp(s)
    t = t.tz_localize("UTC") if t.tzinfo is None else t.tz_convert("UTC")
    return t.as_unit("ns")


def forward_start(trial_row: dict, pool_row: dict) -> pd.Timestamp:
    birth = max(T(trial_row["born_at"]), T(pool_row["at"]))
    start = birth.ceil("h")
    return max(start, T(C.VAULT_END) + pd.Timedelta(hours=1))


def run_member(trial_row: dict, pool_row: dict, handle=None, runner_cls=ChildRunner) -> dict:
    tid = trial_row["trial_id"]
    src_path = P.TRIAL_SOURCE_DIR / f"{tid}.py"
    if ledger.sha256_file(src_path) != trial_row["source_sha256"]:
        raise RuntimeError(f"frozen source of {tid} does not match its ledger hash")
    source = src_path.read_bytes().decode("ascii")
    parsed = I.parse_source(source)
    if not parsed.ok:
        raise RuntimeError(f"frozen source of {tid} fails the current allowlist ({parsed.code})")
    spec = pipeline.Spec(kind=parsed.meta["kind"], datasets=tuple(parsed.meta.get("datasets", ())),
                         params=parsed.meta["params"])
    params = trial_row["params"]
    handle = handle if handle is not None else access.for_census(f"census of pool member {tid}")
    frames = D.load_frames(C.CORE, spec.datasets, upto="latest", handle=handle)
    grid = pipeline.core_grid(frames, C.CORE)
    fl = pipeline.job_frames(spec.kind, frames, C.CORE, grid)
    runner = runner_cls(source, spec.kind)
    try:
        W = pipeline.to_grid(spec.kind, fl, pipeline.full_outs(runner, spec, params, fl), grid, 0, len(grid) - 1,
                             from_start=True)
    except pipeline.Fail as e:
        raise RuntimeError(f"pool member {tid} failed to run on current data ({e.code})")
    Wn = np.nan_to_num(W, nan=0.0)
    start = forward_start(trial_row, pool_row)
    scale = float(trial_row.get("deploy_scale") or 1.0)
    out = {"trial_id": tid, "strategy_name": parsed.meta.get("name"), "forward_start": str(start),
           "deploy_scale": scale, "current_target_weights": {s: float(w) for s, w in zip(C.CORE, Wn[-1])},
           "data_end": str(grid[-1])}
    if start not in grid or start > grid[-1]:
        out.update({"days_forward": 0, "forward_return_raw": 0.0, "forward_return_scaled": 0.0,
                    "forward_sharpe_raw": None})
        return out
    s = int(grid.get_loc(start))
    sl = slice(s, len(grid))
    arr = lambda c: np.column_stack([frames[x][c].reindex(grid).to_numpy(dtype=np.float64)[sl] for x in C.CORE])
    op, fr = arr("open"), arr("funding_rate")
    liqs = D.load_liqs(C.CORE, upto="latest", handle=handle)
    ratios = [pipeline.liq_ratios(frames[x], liqs.get(x), grid) for x in C.CORE]
    dn = np.column_stack([r[0][sl] for r in ratios])
    up = np.column_stack([r[1][sl] for r in ratios])
    tgt = Wn[s - 1:len(grid) - 1]
    raw = E.run(grid[sl], op, dn, up, fr, tgt)
    scaled = E.run(grid[sl], op, dn, up, fr, tgt * scale)
    idx = grid[sl]
    keep = E.daily_complete_mask(idx)            # daily intervals that end at a 00:00 bar
    dr = raw.daily_returns()[keep]
    ds = scaled.daily_returns()[keep]
    P.FORWARD_DIR.mkdir(parents=True, exist_ok=True)
    pd.DataFrame({"ret_raw": dr, "ret_scaled": ds}).to_parquet(P.FORWARD_DIR / f"{tid}.parquet")
    out.update({"days_forward": int(len(dr)), "forward_return_raw": S.total_return(dr),
                "forward_return_scaled": S.total_return(ds),
                "forward_sharpe_raw": S.sharpe(dr) if len(dr) > 1 else None,
                "liquidated_raw": bool(raw.liquidated)})
    return out


def main(argv=None):
    ap = argparse.ArgumentParser(prog="python -m omr.census")
    ap.add_argument("--no-update", action="store_true", help="skip the data update (offline)")
    a = ap.parse_args(argv)
    kernel_lock.require_kernel()
    if not a.no_update:
        try:
            data.snapshot("update", log=lambda s: print("  data: " + s, flush=True))
        except Exception as e:
            print(f"  data update FAILED, using stored data: {type(e).__name__}: {str(e)[:300]}")
    manifest = data.load_manifest()
    mem = pool.members()
    results = []
    for tid, prow in mem.items():
        trow = ledger.find_trial(tid)
        results.append(run_member(trow, prow))
    print(f"census at data end {manifest['snapshot_end']} - pool {len(mem)} member(s)")
    for r in results:
        w = ", ".join(f"{k} {v:+.3f}" for k, v in r["current_target_weights"].items())
        print(f"  {r['trial_id']}  {r['strategy_name']}  forward from {r['forward_start']}  days {r['days_forward']}  "
              f"return raw {r['forward_return_raw']:+.4f}  at deploy_scale {r['deploy_scale']:.3f}: "
              f"{r['forward_return_scaled']:+.4f}  target weights now: {w}")
    body = {"snapshot_end": manifest["snapshot_end"], "members": results}
    prev = ledger.read_rows(P.CENSUS_LOG)
    last = prev[-1] if prev else None
    if last is None or ledger.canonical({k: last[k] for k in ("snapshot_end", "members")}) != ledger.canonical(body):
        ledger.append(P.CENSUS_LOG, {"at": dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"), **body})
        print("  census row appended")
    else:
        print("  nothing changed since the last census (no row appended)")


if __name__ == "__main__":
    main()
