"""Child-process entry point for running ONE strategy job. Kernel module.

Started by omr.runner as:  python -I -B <this file>   with cwd = a fresh temp directory that holds
job.json, frames.npz and a private copy of the `omr` package containing ONLY __init__.py,
strategy_api.py and indicators.py. Stdout and stderr are discarded by the parent.

Writes status.json ({"status": <code>, "run": <index>}) and, on success, result.npz with one
float64 array per (run, output column). Status codes come from a fixed enumeration; no
strategy-produced text is ever written. Any BaseException raised by strategy code (including
SystemExit and KeyboardInterrupt) becomes a fixed code.
"""
import json
import os
import sys

STATUS_CODES = ("ok", "load_error", "no_strategy_class", "exception", "bad_output")


class _Bad(Exception):
    pass


def _write_status(code, run):
    with open("status.json", "w", encoding="ascii") as f:
        json.dump({"status": code, "run": run}, f)


def main():
    here = os.getcwd()
    sys.path.insert(0, here)
    state = {"status": "load_error", "run": -1}
    outputs = {}
    try:
        import numpy as np
        import pandas as pd
        with open("job.json", encoding="ascii") as f:
            job = json.load(f)
        z = np.load("frames.npz", allow_pickle=False)
        frames = []
        for i, spec in enumerate(job["frames"]):
            idx = pd.DatetimeIndex(pd.to_datetime(z[f"f{i}_index"], unit="ns", utc=True)).as_unit("ns")
            idx.name = "open_time"
            frames.append(pd.DataFrame({c: z[f"f{i}_c{j}"] for j, c in enumerate(spec["columns"])}, index=idx))
        from omr.strategy_api import Strategy
        mod = {"__name__": "strategy"}
        exec(compile(job["source"], "strategy.py", "exec"), mod)
        classes = [v for v in mod.values() if isinstance(v, type) and issubclass(v, Strategy) and v is not Strategy]
        if len(classes) != 1:
            state["status"] = "no_strategy_class"
            raise _Bad()
        obj = classes[0]()
        single = job["kind"] == "single"
        for r, run in enumerate(job["runs"]):
            state["run"] = r
            state["status"] = "exception"
            cut = run["cut"]
            frm = run["from"]
            if cut is None:
                tf = list(frames)
            else:
                ct = pd.Timestamp(int(cut), unit="ns", tz="UTC")
                tf = [f.iloc[: int(f.index.searchsorted(ct, side="right"))] for f in frames]
            params = dict(run["params"])
            arrs, idxs = [], []
            if single:
                for f in tf:
                    out = obj.signal(f.copy(), dict(params))
                    if not isinstance(out, pd.Series) or len(out) != len(f) or not out.index.equals(f.index):
                        state["status"] = "bad_output"
                        raise _Bad()
                    if not (pd.api.types.is_numeric_dtype(out.dtype) or pd.api.types.is_bool_dtype(out.dtype)):
                        state["status"] = "bad_output"
                        raise _Bad()
                    arrs.append(out.to_numpy(dtype=np.float64, na_value=np.nan))
                    idxs.append(f.index)
            else:
                out = obj.weights([f.copy() for f in tf], dict(params))
                base = tf[0].index
                if not isinstance(out, pd.DataFrame) or out.shape != (len(base), len(tf)) or not out.index.equals(base):
                    state["status"] = "bad_output"
                    raise _Bad()
                for j in range(out.shape[1]):
                    col = out.iloc[:, j]
                    if not (pd.api.types.is_numeric_dtype(col.dtype) or pd.api.types.is_bool_dtype(col.dtype)):
                        state["status"] = "bad_output"
                        raise _Bad()
                    arrs.append(col.to_numpy(dtype=np.float64, na_value=np.nan))
                    idxs.append(base)
            for j, (a, ix) in enumerate(zip(arrs, idxs)):
                if frm is not None:
                    a = a[np.asarray(ix.as_unit("ns").asi8) >= int(frm)]
                outputs[f"r{r}_c{j}"] = np.ascontiguousarray(a, dtype=np.float64)
        np.savez("result.npz", **outputs)
        state["status"] = "ok"
        state["run"] = -1
    except _Bad:
        pass
    except BaseException:  # noqa: BLE001 - strategy code may raise anything, incl. SystemExit
        pass
    try:
        _write_status(state["status"] if state["status"] in STATUS_CODES else "exception", state["run"])
    except BaseException:  # noqa: BLE001
        pass
    os._exit(0)


if __name__ == "__main__":
    main()
