"""Evaluation pipeline (kernel v1, hardened). Kernel module.

Strategy code runs only through a runner (omr.runner): ChildRunner for every user strategy,
InProcessRunner for the calibration's trusted families. All comparisons, metrics and gates are
computed here, in the parent.

Two stages (count before exposure):
- stage1(...) on DEV-only frames (warm-up + DEV), uncounted: base run, weight validity,
  determinism, lookahead on DEV cuts, invariance. No VAL bar reaches strategy code.
- stage2(...) on DEV+VAL frames, counted, needs a ledger-issued ValHandle: base run in a fresh
  process whose DEV rows must equal stage 1, validity, lookahead on VAL cuts, invariance,
  liquidation (mark price), activity (decisions); then metrics and gates G1-G9.
Failure codes come from a fixed set; no strategy-produced text is kept.

evaluate_world(...) runs both stages back to back (calibration and tests; it needs a handle).
evaluate_weights(...) is a calibration-only entry for synthetic weight matrices (oracles).
"""
from __future__ import annotations

import math
import time
from dataclasses import dataclass, field

import numpy as np
import pandas as pd

from omr import access
from omr import constants as C
from omr import engine as E
from omr import integrity as I
from omr import stats as S
from omr.runner import Job

PRICE_COLS = ("open", "high", "low", "close", "mark_klines.open", "mark_klines.high", "mark_klines.low",
              "mark_klines.close", "quote_volume", "taker_buy_quote_volume")
VOLUME_COLS = ("volume", "taker_buy_volume", "quote_volume", "taker_buy_quote_volume")


def T(s: str) -> pd.Timestamp:
    return pd.Timestamp(s, tz="UTC").as_unit("ns")


@dataclass
class World:
    """Frames for one evaluation: core symbols (and optionally extended).
    liq: {symbol: DataFrame(dn, up, has_mark)} intrabar ratios for the liquidation check
    (mark price, last-price fallback). A symbol missing from liq uses last-price ratios."""
    core: dict
    extended: dict = field(default_factory=dict)
    symbols: tuple = C.CORE
    liq: dict = field(default_factory=dict)


@dataclass
class Spec:
    """What the parent knows about a strategy, from STATIC parsing (never from running it)."""
    kind: str
    datasets: tuple = ()
    params: dict = field(default_factory=dict)     # {name: {default, low, high, kind}}


@dataclass
class Opts:
    full_integrity: bool = True      # determinism, lookahead, invariance
    perm_n: int = C.PERM_N
    jitter_n: int = C.JITTER_N
    include_g8: bool = True
    keep_detail: bool = True
    n_transition: int = C.LOOKAHEAD_MAX_TRANSITION_CUTS
    n_uniform: int = C.LOOKAHEAD_UNIFORM_CUTS
    batch: int = C.LOOKAHEAD_BATCH
    jitter_cuts: int = C.JITTER_LOOKAHEAD_CUTS


class Fail(Exception):
    def __init__(self, code: str):
        super().__init__(code)
        self.code = code


# ---------------------------------------------------------------- market

def liq_ratios(frame: pd.DataFrame, liq, grid: pd.DatetimeIndex):
    """(dn, up) on grid: mark ratios from liq where available, else last-price low/open, high/open."""
    f = frame.reindex(grid)
    o = f["open"].to_numpy(dtype=np.float64)
    dn = f["low"].to_numpy(dtype=np.float64) / o
    up = f["high"].to_numpy(dtype=np.float64) / o
    if liq is not None:
        lq = liq.reindex(grid)
        has = lq["dn"].notna().to_numpy() & lq["up"].notna().to_numpy()
        dn = np.where(has, lq["dn"].to_numpy(dtype=np.float64), dn)
        up = np.where(has, lq["up"].to_numpy(dtype=np.float64), up)
    return dn, up


class Market:
    """Aligned price arrays on a grid plus region positions."""

    def __init__(self, world: World, grid: pd.DatetimeIndex, symbols=None, frames=None):
        syms = list(symbols or world.symbols)
        frames = frames if frames is not None else world.core
        self.grid = grid
        self.op = np.column_stack([frames[s]["open"].reindex(grid).to_numpy(dtype=np.float64) for s in syms])
        ratios = [liq_ratios(frames[s], world.liq.get(s), grid) for s in syms]
        self.dn = np.column_stack([r[0] for r in ratios])
        self.up = np.column_stack([r[1] for r in ratios])
        self.fr = np.column_stack([frames[s]["funding_rate"].reindex(grid).to_numpy(dtype=np.float64) for s in syms])

        def pos(s):
            t = T(s)
            return int(grid.get_loc(t)) if t in grid else None
        self.dev_s = pos(C.DEV_START)
        self.dev_e = pos(C.DEV_END)
        self.val_s = pos(C.VAL_START)
        self.val_e = pos(C.VAL_END)
        if self.dev_s is None or self.dev_s < 1:
            raise ValueError("need DEV start on the grid and at least one warm-up bar before it")

    def run(self, Wn: np.ndarray, s: int, e: int, cost_mult=1.0, pay=1.0, recv=1.0, scale=1.0, tgt=None) -> E.Run:
        """Run over grid positions s..e. Target at position j = decision at j-1 (Wn has NaN zeroed)."""
        if tgt is None:
            tgt = Wn[s - 1:e] * scale
        return E.run(self.grid[s:e + 1], self.op[s:e + 1], self.dn[s:e + 1], self.up[s:e + 1],
                     self.fr[s:e + 1], tgt, cost_rate=C.COST_RATE * cost_mult, pay_mult=pay, recv_mult=recv)


def core_grid(frames: dict, symbols) -> pd.DatetimeIndex:
    idx = None
    for s in symbols:
        i = pd.DatetimeIndex(frames[s].index)
        idx = i if idx is None else idx.intersection(i)
    return idx


def decision_changes(Wn: np.ndarray, tol: float = C.DECISION_TOL) -> np.ndarray:
    """chg[t] = True when the TARGET weight vector decided at bar t differs from the one decided
    at bar t-1 by more than tol in any asset (bar 0 is compared with flat). Drift-triggered
    rebalances are not decisions."""
    Wn = np.asarray(Wn, dtype=np.float64)
    prev = np.vstack([np.zeros((1, Wn.shape[1])), Wn[:-1]])
    return np.any(np.abs(Wn - prev) > tol, axis=1)


def count_decisions(Wn: np.ndarray, mk: Market) -> tuple:
    """(decisions executed in DEV+VAL, decisions executed in VAL). A decision at bar t executes at t+1."""
    chg = decision_changes(Wn)
    return int(chg[mk.dev_s - 1: mk.val_e].sum()), int(chg[mk.val_s - 1: mk.val_e].sum())


def split_daily(daily: pd.Series):
    dev = daily[(daily.index >= T(C.DEV_START)) & (daily.index <= T(C.DEV_END))]
    val = daily[(daily.index >= T(C.VAL_START)) & (daily.index <= T(C.VAL_END))]
    return dev, val


def val_sharpe_of(run: E.Run) -> float:
    if run.liquidated:
        return float("-inf")
    _, val = split_daily(run.daily_returns())
    return S.sharpe(val)


# ---------------------------------------------------------------- strategy outputs -> weights

def job_frames(kind: str, frames: dict, symbols, grid: pd.DatetimeIndex) -> list:
    """single: each symbol's own frame (up to the grid end); portfolio: positional panel on the grid."""
    end = grid[-1]
    if kind == "single":
        return [frames[s].loc[:end] for s in symbols]
    return [frames[s].reindex(grid) for s in symbols]


def truncate(frames_list: list, upto: pd.Timestamp) -> list:
    return [f.iloc[: int(f.index.searchsorted(upto, side="right"))] for f in frames_list]


def to_grid(kind: str, frames_list: list, outs: list, grid: pd.DatetimeIndex, from_pos: int, cut_pos: int,
            from_start: bool = False) -> np.ndarray:
    """Child output columns -> decision-weight rows grid[from_pos..cut_pos] (NaN kept). Raises Fail.

    from_start=True: each output column covers its frame from the frame's FIRST row up to the cut
    (a run with from=None); otherwise it covers exactly the rows in [grid[from_pos], grid[cut_pos]].
    For kind single each symbol keeps its own index (symbols may start at different times)."""
    rows = grid[from_pos:cut_pos + 1]
    K = len(frames_list)
    if len(outs) != K:
        raise Fail("bad_output")
    W = np.empty((len(rows), K))
    for j, (f, a) in enumerate(zip(frames_list, outs)):
        if kind == "single":
            fi = f.index
            m = (fi <= rows[-1]) if from_start else ((fi >= rows[0]) & (fi <= rows[-1]))
            if len(a) != int(m.sum()):
                raise Fail("bad_output")
            fin = a[~np.isnan(a)]
            if not np.all(np.isfinite(fin)):
                raise Fail("non_finite")
            if len(fin) and (fin.min() < -1.0 or fin.max() > 1.0):
                raise Fail("weights_out_of_range")
            W[:, j] = pd.Series(a, index=fi[m]).reindex(rows).to_numpy() / K
        else:
            if from_start:
                if len(a) != cut_pos + 1:
                    raise Fail("bad_output")
                a = a[from_pos:]
            if len(a) != len(rows):
                raise Fail("bad_output")
            W[:, j] = a
    probs = I.check_weights(W)
    if probs:
        raise Fail(probs[0][0])
    return W


def _run1(runner, spec, params, frames_list, grid, cut_pos=None, from_pos=0) -> np.ndarray:
    run = {"params": params, "cut": None if cut_pos is None else grid[cut_pos].value, "from": grid[from_pos].value}
    res = runner.run([Job(frames=frames_list if cut_pos is None else truncate(frames_list, grid[cut_pos]), runs=[run])])[0]
    if res.status != "ok":
        raise Fail(res.status)
    return to_grid(spec.kind, frames_list, res.outputs[0], grid, from_pos, len(grid) - 1 if cut_pos is None else cut_pos)


def select_cuts(Wn: np.ndarray, lo: int, hi: int, mandatory, rng, n_trans: int, n_unif: int) -> list:
    rows = np.arange(lo, hi + 1)
    chg = decision_changes(Wn)
    trans = rows[chg[rows]]
    if len(trans) > n_trans:
        trans = rng.choice(trans, size=n_trans, replace=False)
    rest = np.setdiff1d(rows, trans)
    unif = rng.choice(rest, size=min(n_unif, len(rest)), replace=False) if len(rest) else np.array([], dtype=int)
    cuts = set(int(x) for x in trans) | set(int(x) for x in unif) | {int(m) for m in mandatory if lo <= m <= hi}
    return sorted(cuts)


def lookahead_jobs(spec, params, frames_list, grid, cuts, from_pos, batch) -> tuple:
    chunks = [cuts[i:i + batch] for i in range(0, len(cuts), batch)]
    jobs = []
    for ch in chunks:
        upto = grid[ch[-1]]
        runs = [{"params": params, "cut": grid[c].value, "from": grid[from_pos].value} for c in ch]
        jobs.append(Job(frames=truncate(frames_list, upto), runs=runs))
    return jobs, chunks


def lookahead_check(spec, frames_list, Wref_n, grid, chunks, results, from_pos) -> str | None:
    """Compare ALL rows grid[from_pos..cut] of every truncated run with the reference (NaN = 0)."""
    for ch, res in zip(chunks, results):
        if res.status != "ok":
            return res.status if res.status in ("timeout", "crash") else "exception"
        for i, c in enumerate(ch):
            try:
                Wt = to_grid(spec.kind, frames_list, res.outputs[i], grid, from_pos, c)
            except Fail:
                return "lookahead"
            d = np.abs(np.nan_to_num(Wt, nan=0.0) - Wref_n[from_pos:c + 1])
            if d.size and not float(d.max()) <= C.LOOKAHEAD_TOL:
                return "lookahead"
    return None


def _transform(frames_list: list, how: str, arg) -> list:
    out = []
    for f in frames_list:
        g = f.copy()
        if how == "time":
            g.index = pd.DatetimeIndex(g.index) + pd.Timedelta(weeks=arg)
        else:
            cols = PRICE_COLS if how == "price" else VOLUME_COLS
            for c in cols:
                if c in g.columns:
                    g[c] = g[c].to_numpy(dtype=np.float64) * arg
        out.append(g)
    return out


INVARIANCE = [("time", w) for w in C.TIME_SHIFTS_WEEKS] + [("price", k) for k in C.PRICE_SCALES] + [("volume", C.VOLUME_SCALE)]


def invariance_jobs(params, frames_list) -> list:
    return [Job(frames=_transform(frames_list, how, arg), runs=[{"params": params, "cut": None, "from": None}])
            for how, arg in INVARIANCE]


def invariance_check(base_outs: list, results: list) -> str | None:
    for (how, arg), res in zip(INVARIANCE, results):
        if res.status != "ok":
            return res.status if res.status in ("timeout", "crash") else "exception"
        outs = res.outputs[0]
        if len(outs) != len(base_outs) or any(len(a) != len(b) for a, b in zip(outs, base_outs)):
            return "calendar_dependent" if how == "time" else "scale_dependent"
        A = [np.nan_to_num(a, nan=0.0) for a in outs]
        B = [np.nan_to_num(b, nan=0.0) for b in base_outs]
        if how == "time":
            if not all(np.array_equal(a, b) for a, b in zip(A, B)):
                return "calendar_dependent"
        else:
            n = max(len(b) for b in B)
            bad_rows = 0
            for a, b in zip(A, B):
                bad_rows = max(bad_rows, int(np.sum(np.abs(a - b) > C.SCALE_TOL)))
            if n and bad_rows / n > C.SCALE_MAX_ROW_FRAC:
                return "scale_dependent"
    return None


def full_outs(runner, spec, params, frames_list) -> list:
    res = runner.run([Job(frames=frames_list, runs=[{"params": params, "cut": None, "from": None}])])[0]
    if res.status != "ok":
        raise Fail(res.status)
    return res.outputs[0]


# ---------------------------------------------------------------- stage 1

def stage1(runner, spec: Spec, params: dict, frames_dev: dict, symbols, opts: Opts, rng) -> dict:
    """DEV-only frames, uncounted. Returns {"ok", "code", "W" (DataFrame), "cuts", "children"}."""
    out = {"ok": False, "code": None, "cuts": 0}
    try:
        grid = core_grid(frames_dev, symbols)
        if grid[-1] != T(C.DEV_END):
            raise ValueError("stage 1 frames must end at DEV end")
        fl = job_frames(spec.kind, frames_dev, symbols, grid)
        dev_s = int(grid.get_loc(T(C.DEV_START)))
        dev_e = len(grid) - 1
        base = full_outs(runner, spec, params, fl)
        W = to_grid(spec.kind, fl, base, grid, 0, dev_e, from_start=True)
        Wn = np.nan_to_num(W, nan=0.0)
        if opts.full_integrity:
            cuts = select_cuts(Wn, dev_s - 1, dev_e, (dev_s - 1, dev_e), rng, opts.n_transition, opts.n_uniform)
            lj, chunks = lookahead_jobs(spec, params, fl, grid, cuts, dev_s - 1, opts.batch)
            det_job = Job(frames=fl, runs=[{"params": params, "cut": None, "from": None}])
            inv = invariance_jobs(params, fl)
            results = runner.run([det_job] + lj + inv)
            det, lres, ires = results[0], results[1:1 + len(lj)], results[1 + len(lj):]
            if det.status != "ok" or len(det.outputs[0]) != len(base) or not all(
                    np.array_equal(a, b, equal_nan=True) for a, b in zip(det.outputs[0], base)):
                raise Fail("nondeterministic" if det.status == "ok" else det.status)
            code = lookahead_check(spec, fl, Wn, grid, chunks, lres, dev_s - 1)
            if code:
                raise Fail(code)
            code = invariance_check(base, ires)
            if code:
                raise Fail(code)
            out["cuts"] = len(cuts)
            out["n_transition_rows"] = int(decision_changes(Wn)[dev_s - 1: dev_e + 1].sum())
        out.update({"ok": True, "W": pd.DataFrame(W, index=grid, columns=list(symbols))})
    except Fail as e:
        out["code"] = e.code
    out["children"] = getattr(runner, "n_children", 0)
    return out


# ---------------------------------------------------------------- stage 2

def jitter_params(spec: Spec, base: dict, rng: np.random.Generator, n: int) -> list:
    """Every param x U(0.8, 1.2); ints rounded and, if rounding leaves the value unchanged, moved
    by 1 with a random sign; clipped to the declared bounds."""
    out = []
    for _ in range(n):
        q = {}
        for k, p in spec.params.items():
            d = base[k]
            v = d * rng.uniform(C.JITTER_LO, C.JITTER_HI)
            if p["kind"] == "int":
                v = int(math.floor(v + 0.5))
                if v == d:
                    v = d + (1 if rng.uniform() < 0.5 else -1)
            v = min(max(v, p["low"]), p["high"])
            q[k] = int(v) if p["kind"] == "int" else float(v)
        out.append(q)
    return out


def perm_offsets(L: int, rng: np.random.Generator, n: int) -> np.ndarray:
    lo = C.PERM_MIN_OFFSET_DAYS * 24
    hi = L - C.PERM_MIN_OFFSET_DAYS * 24
    if hi < lo:
        raise ValueError("VAL too short for the permutation test")
    return rng.integers(lo, hi + 1, size=n)


def g8_tuples(extended, K: int) -> list:
    ext = list(extended)
    return [tuple(ext[i:i + K]) for i in range(0, len(ext) - K + 1, K)]


def stage2(runner, spec: Spec, params: dict, world: World, W_dev, opts: Opts, rng, handle, seed: int) -> dict:
    """DEV+VAL frames, COUNTED. W_dev: the stage-1 weights (DataFrame) or None when stage 1 was
    skipped (calibration with full_integrity off)."""
    access.require(handle, "pipeline.stage2")
    t0 = time.time()
    syms = list(world.symbols)
    res = {"status": None, "integrity": {"checks": {}}, "params": params}
    chk = res["integrity"]["checks"]

    def fail(code):
        res["status"] = "integrity_fail_val"
        res["integrity"]["ok"] = False
        res["integrity"]["reason"] = code
        res["seconds"] = round(time.time() - t0, 2)
        return res

    try:
        grid = core_grid(world.core, syms)
        fl = job_frames(spec.kind, world.core, syms, grid)
        mk = Market(world, grid)
        base = full_outs(runner, spec, params, fl)
        W = to_grid(spec.kind, fl, base, grid, 0, len(grid) - 1, from_start=True)
        Wn = np.nan_to_num(W, nan=0.0)
        if W_dev is not None:
            n = len(W_dev)
            if not (W_dev.index.equals(grid[:n])):
                raise Fail("dev_rows_changed")
            d = np.abs(np.nan_to_num(W_dev.to_numpy(), nan=0.0) - Wn[:n])
            if d.size and not float(d.max()) <= C.LOOKAHEAD_TOL:
                raise Fail("dev_rows_changed")
        # launch every remaining child at once: integrity jobs, jitter variants, G8 runs
        jobs, tags = [], []
        chunks = []
        if opts.full_integrity:
            cuts = select_cuts(Wn, mk.val_s - 1, mk.val_e - 1, (mk.val_s - 1, mk.val_e - 1), rng,
                               opts.n_transition, opts.n_uniform)
            lj, chunks = lookahead_jobs(spec, params, fl, grid, cuts, mk.dev_s - 1, opts.batch)
            jobs += lj
            tags += ["look"] * len(lj)
            inv = invariance_jobs(params, fl)
            jobs += inv
            tags += ["inv"] * len(inv)
            chk["lookahead_cuts_val"] = len(cuts)
        variants = jitter_params(spec, params, rng, opts.jitter_n) if spec.params else []
        jcuts = []
        if variants and opts.full_integrity:
            dec = np.nonzero(decision_changes(Wn)[mk.dev_s - 1: mk.val_e])[0] + mk.dev_s - 1
            half = opts.jitter_cuts // 2
            pick = set(rng.choice(dec, size=min(half, len(dec)), replace=False).tolist()) if len(dec) else set()
            pool = np.setdiff1d(np.arange(mk.dev_s - 1, mk.val_e), list(pick))
            pick |= set(rng.choice(pool, size=min(opts.jitter_cuts - len(pick), len(pool)), replace=False).tolist())
            jcuts = sorted(int(x) for x in pick)
        for q in variants:
            runs = [{"params": q, "cut": grid[c].value, "from": grid[mk.dev_s - 1].value} for c in jcuts]
            runs.append({"params": q, "cut": None, "from": None})
            jobs.append(Job(frames=fl, runs=runs))
            tags.append("jit")
        g8_plan = []
        if opts.include_g8 and world.extended:
            if spec.kind == "single":
                ext = list(world.extended)
                g8_plan.append(("single", ext))
                jobs.append(Job(frames=[world.extended[s] for s in ext], runs=[{"params": params, "cut": None, "from": None}]))
                tags.append("g8")
            else:
                for tup in g8_tuples(world.extended, len(syms)):
                    tg = core_grid(world.extended, tup)
                    g8_plan.append(("portfolio", tup))
                    jobs.append(Job(frames=job_frames("portfolio", world.extended, tup, tg),
                                    runs=[{"params": params, "cut": None, "from": None}]))
                    tags.append("g8")
        results = runner.run(jobs) if jobs else []
        by = {t: [r for r, tt in zip(results, tags) if tt == t] for t in ("look", "inv", "jit", "g8")}
        if opts.full_integrity:
            code = lookahead_check(spec, fl, Wn, grid, chunks, by["look"], mk.dev_s - 1)
            if code:
                raise Fail(code)
            code = invariance_check(base, by["inv"])
            if code:
                raise Fail(code)
        # jitter variants: weights, and the light lookahead check on each
        jit_W = []
        for q, r in zip(variants, by["jit"]):
            if r.status != "ok":
                jit_W.append(None)
                continue
            try:
                Wv = to_grid(spec.kind, fl, r.outputs[-1], grid, 0, len(grid) - 1, from_start=True)
            except Fail:
                jit_W.append(None)
                continue
            Wvn = np.nan_to_num(Wv, nan=0.0)
            for i, c in enumerate(jcuts):
                try:
                    Wt = to_grid(spec.kind, fl, r.outputs[i], grid, mk.dev_s - 1, c)
                except Fail:
                    raise Fail("lookahead_jitter")
                if not float(np.max(np.abs(np.nan_to_num(Wt, nan=0.0) - Wvn[mk.dev_s - 1:c + 1]))) <= C.LOOKAHEAD_TOL:
                    raise Fail("lookahead_jitter")
            jit_W.append(Wvn)
        base_run = mk.run(Wn, mk.dev_s, mk.val_e)
        if base_run.liquidated:
            raise Fail("liquidation")
        n_all, n_val = count_decisions(Wn, mk)
        chk["decisions_dev_val"] = n_all
        chk["decisions_val"] = n_val
        if n_all < C.MIN_DECISIONS_ALL or n_val < C.MIN_DECISIONS_VAL:
            raise Fail("activity")
    except Fail as e:
        return fail(e.code)
    res["integrity"]["ok"] = True
    chk["children"] = getattr(runner, "n_children", 0)
    g8_out = _g8_sharpes(spec, params, world, g8_plan, by.get("g8", []))
    return _gates(res, W, Wn, world, mk, base_run, np.random.default_rng([seed, 3]), opts,
                  jitter=(variants, jit_W) if variants else None, g8=g8_out, n_params=len(spec.params),
                  kind=spec.kind, t0=t0)


def _g8_sharpes(spec, params, world, plan, results) -> list | None:
    if not plan:
        return None
    rows = []
    for (kind, syms), res in zip(plan, results):
        units = [(s,) for s in syms] if kind == "single" else [tuple(syms)]
        for ui, unit in enumerate(units):
            name = "+".join(unit)
            try:
                g = core_grid(world.extended, unit)
                start_ts = max(T(C.DEV_START), g[1])
                years = (T(C.VAL_END) - start_ts) / pd.Timedelta(days=365)
                if years < C.G8_MIN_YEARS:
                    rows.append({"unit": name, "skipped": "history < 2 years"})
                    continue
                if res.status != "ok":
                    rows.append({"unit": name, "sharpe": float("-inf")})
                    continue
                if kind == "single":
                    f = world.extended[unit[0]]
                    W = to_grid("single", [f], [res.outputs[0][ui]], g, 0, len(g) - 1, from_start=True)
                else:
                    W = to_grid("portfolio", job_frames("portfolio", world.extended, unit, g), res.outputs[0], g, 0,
                                len(g) - 1, from_start=True)
                Wn = np.nan_to_num(W, nan=0.0)
                mk = Market(world, g, symbols=unit, frames=world.extended)
                si = int(g.get_loc(start_ts))
                ei = int(g.get_loc(T(C.VAL_END)))
                rx = mk.run(Wn, si, ei)
                rows.append({"unit": name, "sharpe": float("-inf") if rx.liquidated else S.sharpe(rx.daily_returns())})
            except Exception:
                rows.append({"unit": name, "sharpe": float("-inf")})
    return rows


# ---------------------------------------------------------------- gates (pure rules + assembly)

def g5_rule(base_val: float, variant_sharpes) -> dict:
    shs = np.asarray(variant_sharpes, dtype=np.float64)
    med = float(np.median(shs))
    frac = float(np.mean(shs > 0))
    return {"pass": bool(med >= C.JITTER_MEDIAN_FRAC * base_val and frac >= C.JITTER_POSITIVE_FRAC),
            "median": med, "frac_positive": frac}


def g6_rule(actual: float, shifted) -> dict:
    shifted = np.asarray(shifted, dtype=np.float64)
    count = int(np.sum(shifted >= actual))
    p = (1 + count) / (len(shifted) + 1)
    return {"pass": bool(p <= C.PERM_P_MAX), "p": p, "count_ge": count}


def g7_rule(bucket_returns) -> dict:
    lr = [math.log1p(R) if R > -1 else float("-inf") for R in bucket_returns]
    n_pos = sum(1 for R in bucket_returns if R > 0)
    pos_sum = sum(x for x in lr if x > 0)
    largest = max(lr) if lr else float("-inf")
    share = largest / pos_sum if pos_sum > 0 else float("inf")
    ok = bool(n_pos >= C.G7_MIN_POSITIVE and pos_sum > 0 and largest <= C.G7_MAX_SHARE * pos_sum)
    return {"pass": ok, "n_positive": n_pos, "largest_share": share}


def g8_rule(sharpes) -> dict:
    shs = np.asarray(sharpes, dtype=np.float64)
    if len(shs) == 0:
        return {"pass": True, "median": None, "frac_positive": None, "n": 0}
    med = float(np.median(shs))
    frac = float(np.mean(shs > 0))
    return {"pass": bool(med > 0 and frac >= 0.5), "median": med, "frac_positive": frac, "n": int(len(shs))}


def _gates(res, W, Wn, world, mk, base, rng_perm, opts, jitter, g8, n_params, kind, t0,
           g5_by_definition=False) -> dict:
    syms = list(world.symbols)
    K = len(syms)
    grid = mk.grid
    res["status"] = "evaluated"
    daily = base.daily_returns()
    dev, val = split_daily(daily)
    m = {"dev": S.summary(dev), "val": S.summary(val)}
    m["dev_val_max_drawdown"] = S.max_drawdown(daily)
    m["deploy_scale"] = min(1.0, C.DEPLOY_RISK_BUDGET / m["dev_val_max_drawdown"]) if m["dev_val_max_drawdown"] > 0 else 1.0
    n_years = len(daily) / C.PERIODS_PER_YEAR
    m["turnover_per_year"] = float(base.ev_turn.sum() / n_years) if n_years > 0 else 0.0
    m["avg_gross_exposure"] = float(base.gross.mean())
    m["avg_net_exposure"] = float(base.net.mean())
    ev_t = base.index[base.ev_idx]
    m["rebalances"] = int(len(ev_t))
    m["rebalances_val"] = int((ev_t >= T(C.VAL_START)).sum())
    m["decisions"], m["decisions_val"] = count_decisions(Wn, mk)
    m["funding_paid_total"] = float(base.funding_paid)
    m["costs_total"] = float(base.ev_cost.sum())
    m["val_sharpe_daily"] = S.sharpe_daily(val)
    gates = {}
    gates["G1"] = {"pass": m["val"]["psr0"] >= C.G1_PSR_MIN, "value": m["val"]["psr0"], "threshold": C.G1_PSR_MIN,
                   "name": "VAL PSR(0) >= 0.90"}
    fs = mk.run(Wn, mk.dev_s, mk.val_e, pay=C.FUNDING_STRESS_PAY, recv=C.FUNDING_STRESS_RECV)
    fs_sh = val_sharpe_of(fs)
    gates["G2"] = {"pass": bool(fs_sh > 0), "value": fs_sh, "threshold": 0.0,
                   "name": "VAL Sharpe > 0 with funding paid x1.5, received x0.5"}
    gates["G3"] = {"pass": bool(m["dev"]["sharpe"] > 0), "value": m["dev"]["sharpe"], "threshold": 0.0,
                   "name": "DEV Sharpe > 0"}
    cs = mk.run(Wn, mk.dev_s, mk.val_e, cost_mult=C.COST_STRESS_MULT)
    cs_sh = val_sharpe_of(cs)
    gates["G4"] = {"pass": bool(cs_sh > 0), "value": cs_sh, "threshold": 0.0, "name": "VAL Sharpe at 2x costs > 0"}

    base_val = m["val"]["sharpe"]
    jit_summary = None
    if g5_by_definition:
        gates["G5"] = {"pass": True, "value": "pass by definition (calibration oracle)", "threshold": None, "name": "jitter"}
    elif jitter is not None:
        variants, Ws = jitter
        shs = []
        for Wv in Ws:
            if Wv is None:
                shs.append(float("-inf"))
            else:
                shs.append(val_sharpe_of(mk.run(Wv, mk.dev_s, mk.val_e)))
        g5 = g5_rule(base_val, shs)
        jit_summary = {"n": len(shs), "median": g5["median"], "frac_positive": g5["frac_positive"]}
        gates["G5"] = {"pass": g5["pass"], "value": jit_summary,
                       "threshold": {"median_vs_base": C.JITTER_MEDIAN_FRAC, "frac_positive": C.JITTER_POSITIVE_FRAC},
                       "name": "jitter: median >= 0.5 x base and >= 75% positive"}
    else:
        gates["G5"] = {"pass": True, "value": "no params", "threshold": None, "name": "jitter (no params = pass)"}

    # G6 timing permutation on VAL (restart flat at VAL start; funding stays on the price timeline)
    L = mk.val_e - mk.val_s + 1
    Wv = Wn[mk.val_s - 1: mk.val_e].copy()
    vgrid = grid[mk.val_s: mk.val_e + 1]
    sl = slice(mk.val_s, mk.val_e + 1)
    args = (mk.op[sl], mk.dn[sl], mk.up[sl], mk.fr[sl])

    def vrun(tgt):
        out = E.run_arrays(*args, tgt)
        if out[7] >= 0:
            return float("-inf")
        return S.sharpe(E.daily_returns(out[8], out[0], vgrid).to_numpy())

    actual = vrun(Wv)
    offs = perm_offsets(L, rng_perm, opts.perm_n)
    shifted = np.array([vrun(np.roll(Wv, int(k), axis=0)) for k in offs])
    g6 = g6_rule(actual, shifted)
    gates["G6"] = {"pass": g6["pass"], "value": g6["p"], "threshold": C.PERM_P_MAX,
                   "name": f"timing permutation p <= {C.PERM_P_MAX} ({len(offs)} circular shifts)"}
    fin = shifted[np.isfinite(shifted)]
    perm_summary = {"actual_val_sharpe_restarted": actual, "n": int(len(offs)), "count_ge": g6["count_ge"], "p": g6["p"],
                    "shifted_mean": float(np.mean(fin)) if len(fin) else None,
                    "shifted_p95": float(np.percentile(fin, 95)) if len(fin) else None}

    buckets = []
    for name, a, b in C.G7_BUCKETS:
        r = daily[(daily.index >= T(a).normalize()) & (daily.index <= T(b))]
        buckets.append({"bucket": name, "n_days": int(len(r)), "return": S.total_return(r)})
    g7 = g7_rule([x["return"] for x in buckets])
    gates["G7"] = {"pass": g7["pass"], "value": {"n_positive": g7["n_positive"], "largest_share": g7["largest_share"]},
                   "threshold": {"min_positive": C.G7_MIN_POSITIVE, "max_share": C.G7_MAX_SHARE},
                   "name": "sub-periods: >= 4 of 6 positive, largest <= 50% of positive log sum"}

    if g8 is None:
        gates["G8"] = {"pass": True, "value": "not run", "threshold": None, "name": "extended-universe veto (not run)",
                       "not_run": True}
    else:
        shs = [r["sharpe"] for r in g8 if "sharpe" in r]
        g8r = g8_rule(shs)
        gates["G8"] = {"pass": g8r["pass"], "value": {"median": g8r["median"], "frac_positive": g8r["frac_positive"],
                                                      "n": g8r["n"]},
                       "threshold": {"median": 0.0, "frac_positive": 0.5},
                       "name": "extended-universe veto" + (" (substitute tuples)" if kind == "portfolio" else "")}
    gates["G9"] = {"pass": n_params <= C.MAX_PARAMS, "value": n_params, "threshold": C.MAX_PARAMS,
                   "name": "at most 6 numeric params (enforced at load)"}
    for g in gates.values():
        g["pass"] = bool(g["pass"])
    tier1 = all(g["pass"] for g in gates.values())

    Wb = np.full_like(Wn, 1.0 / K)
    bench = mk.run(Wb, mk.dev_s, mk.val_e)
    bdaily = bench.daily_returns()
    bdev, bval = split_daily(bdaily)
    info = {"benchmark_val_sharpe": S.sharpe(bval), "benchmark_val_max_drawdown": S.max_drawdown(bval),
            "benchmark_dev_sharpe": S.sharpe(bdev)}
    info.update({f"vs_benchmark_{k}": v for k, v in S.beta_alpha(val.to_numpy(), bval.reindex(val.index).to_numpy()).items()})
    res.update({"metrics": m, "gates": gates, "tier": "tier1" if tier1 else "none", "info": info,
                "daily_returns": daily, "W": pd.DataFrame(W, index=grid, columns=syms)})
    if opts.keep_detail:
        res["detail"] = {"jitter": jit_summary, "permutation": perm_summary, "per_year": S.per_year(daily),
                         "buckets": buckets, "extended": g8,
                         "stress": {"funding_stress_val_sharpe": fs_sh, "cost2x_val_sharpe": cs_sh}}
    res["seconds"] = round(time.time() - t0, 2)
    return res


# ---------------------------------------------------------------- both stages (calibration / tests)

def dev_frames(world: World) -> dict:
    end = T(C.DEV_END)
    return {s: f.loc[:end] for s, f in world.core.items()}


def evaluate_world(runner, spec: Spec, params: dict, world: World, seed: int, opts: Opts, handle, rng=None) -> dict:
    """Stage 1 then stage 2 with no ledger in between (calibration and tests only)."""
    access.require(handle, "pipeline.evaluate_world")
    rng = rng if rng is not None else np.random.default_rng([seed, 1])
    W_dev = None
    if opts.full_integrity:
        s1 = stage1(runner, spec, params, dev_frames(world), world.symbols, opts, rng)
        if not s1["ok"]:
            return {"status": "integrity_fail", "integrity": {"ok": False, "reason": s1["code"], "checks": {}}}
        W_dev = s1["W"]
    res = stage2(runner, spec, params, world, W_dev, opts, rng, handle, seed)
    if opts.full_integrity and res["status"] == "evaluated":
        res["integrity"]["checks"]["lookahead_cuts_dev"] = s1["cuts"]
    return res


def evaluate_weights(W: pd.DataFrame, world: World, seed: int, opts: Opts, handle) -> dict:
    """CALIBRATION ONLY: gates for a synthetic weight matrix (decision rows on the core grid).
    No integrity checks (the noisy oracles use future data by construction); G5 and G9 pass by
    definition; G8 is not run. Never called by omr.evaluate."""
    access.require(handle, "pipeline.evaluate_weights")
    t0 = time.time()
    res = {"status": "evaluated", "integrity": {"ok": None, "checks": {"bypassed": "calibration oracle"}}}
    Wn = np.nan_to_num(W.to_numpy(dtype=np.float64), nan=0.0)
    mk = Market(world, W.index)
    base = mk.run(Wn, mk.dev_s, mk.val_e)
    res["integrity"]["checks"]["liquidated"] = bool(base.liquidated)
    return _gates(res, W.to_numpy(dtype=np.float64), Wn, world, mk, base, np.random.default_rng([seed, 3]), opts,
                  jitter=None, g8=None, n_params=0, kind="oracle", t0=t0, g5_by_definition=True)
