"""Kernel lock: sha256 of every kernel file plus a combined hash. Kernel module.

Kernel files: omr/**, tests/** (excluding caches), CONSTITUTION.md, requirements.txt.

CLI:
    python -m omr.kernel_lock verify
    python -m omr.kernel_lock rekey --reason "..." --approved-by "<human name>"

rekey rewrites kernel.lock and appends a hash-chained row to ledger/kernel_history.jsonl.
verify also checks that kernel.lock matches the latest kernel_history row, so editing a
kernel file and kernel.lock together without a history row is detected. This is a
tripwire: only the human may approve a re-key.
"""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import sys
from pathlib import Path

from omr import ledger
from omr import paths as P

KERNEL_DIRS = ("omr", "tests")
KERNEL_FILES = ("CONSTITUTION.md", "requirements.txt")
SKIP_PARTS = {"__pycache__", ".pytest_cache"}
SKIP_SUFFIX = {".pyc", ".pyo", ".nbi", ".nbc"}


def kernel_files(root: Path) -> list:
    root = Path(root)
    out = []
    for d in KERNEL_DIRS:
        base = root / d
        if base.exists():
            for p in base.rglob("*"):
                if p.is_file() and not (set(p.relative_to(root).parts) & SKIP_PARTS) and p.suffix not in SKIP_SUFFIX:
                    out.append(p.relative_to(root).as_posix())
    for f in KERNEL_FILES:
        if (root / f).exists():
            out.append(f)
    return sorted(out)


def compute(root: Path = P.ROOT) -> dict:
    files = {}
    for rel in kernel_files(root):
        files[rel] = hashlib.sha256((Path(root) / rel).read_bytes()).hexdigest()
    combined = hashlib.sha256("".join(f"{k}:{v}\n" for k, v in sorted(files.items())).encode("ascii")).hexdigest()
    return {"files": files, "combined": combined}


def kernel_hash(root: Path = P.ROOT) -> str:
    return compute(root)["combined"]


def read_lock(lock_path: Path = P.KERNEL_LOCK):
    if not Path(lock_path).exists():
        return None
    return json.loads(Path(lock_path).read_text(encoding="ascii"))


def verify(root: Path = P.ROOT, lock_path: Path = P.KERNEL_LOCK, history_path: Path = P.KERNEL_HISTORY) -> list:
    """Return problems (empty = kernel matches its lock and history)."""
    lock = read_lock(lock_path)
    if lock is None:
        return ["kernel.lock missing (run rekey once, with human approval)"]
    cur = compute(root)
    problems = []
    for f in sorted(set(lock["files"]) | set(cur["files"])):
        if f not in cur["files"]:
            problems.append(f"kernel file removed: {f}")
        elif f not in lock["files"]:
            problems.append(f"new file in kernel area: {f}")
        elif lock["files"][f] != cur["files"][f]:
            problems.append(f"kernel file changed: {f}")
    if lock.get("combined") != cur["combined"] and not problems:
        problems.append("combined hash mismatch")
    hist = ledger.read_rows(history_path)
    if not hist:
        problems.append("kernel_history.jsonl missing or empty")
    else:
        if hist[-1].get("new_combined") != lock.get("combined"):
            problems.append("kernel.lock does not match the latest kernel_history row")
        problems.extend(ledger.verify_chain(history_path))
    return problems


def rekey(reason: str, approved_by: str, root: Path = P.ROOT, lock_path: Path = P.KERNEL_LOCK,
          history_path: Path = P.KERNEL_HISTORY) -> dict:
    if not reason or not reason.strip():
        raise ValueError("--reason is required")
    if not approved_by or not approved_by.strip():
        raise ValueError("--approved-by is required (the human approving the kernel change)")
    old = read_lock(lock_path)
    cur = compute(root)
    changed = []
    if old:
        for f in sorted(set(old["files"]) | set(cur["files"])):
            if old["files"].get(f) != cur["files"].get(f):
                changed.append(f)
    now = dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    lock = {"created_at": now, "reason": reason, "approved_by": approved_by, **cur}
    Path(lock_path).write_text(json.dumps(lock, indent=1, sort_keys=True), encoding="ascii")
    ledger.append(history_path, {"at": now, "reason": reason, "approved_by": approved_by,
                                 "old_combined": old["combined"] if old else None,
                                 "new_combined": cur["combined"], "changed_files": changed})
    return lock


def require_kernel(log=print):
    """Exit with an error if the kernel does not match its lock."""
    problems = verify()
    if problems:
        log("KERNEL LOCK MISMATCH - refusing to run:")
        for p in problems[:20]:
            log("  " + p)
        sys.exit(3)
    return read_lock()["combined"]


def main(argv=None):
    ap = argparse.ArgumentParser(prog="python -m omr.kernel_lock")
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("verify")
    sub.add_parser("hash")
    rk = sub.add_parser("rekey")
    rk.add_argument("--reason", required=True)
    rk.add_argument("--approved-by", required=True)
    a = ap.parse_args(argv)
    if a.cmd == "verify":
        pr = verify()
        if pr:
            print("KERNEL LOCK: FAIL")
            for p in pr:
                print("  " + p)
            sys.exit(1)
        print(f"KERNEL LOCK: OK  {read_lock()['combined']}")
    elif a.cmd == "hash":
        print(kernel_hash())
    else:
        lock = rekey(a.reason, a.approved_by)
        print(f"re-keyed: {lock['combined']}  ({len(lock['files'])} files)")


if __name__ == "__main__":
    main()
