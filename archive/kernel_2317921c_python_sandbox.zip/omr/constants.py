"""CONSTITUTION v1 constants (perps, amendment A1). Kernel module.

Every number the evaluator uses lives here. Changing any of them is a kernel
change and needs a human-approved re-key.
"""

# ---------------------------------------------------------------- universe
# USDT-margined linear perpetuals (Binance USD-M). Engine and evaluator read
# these lists; neither hardcodes a symbol or a universe size.
CORE = ("BTCUSDT", "ETHUSDT")
EXTENDED = ("SOLUSDT", "BNBUSDT", "XRPUSDT", "ADAUSDT",
            "DOGEUSDT", "LTCUSDT", "LINKUSDT", "AVAXUSDT")
ALL_SYMBOLS = CORE + EXTENDED

# ---------------------------------------------------------------- regions
# Bar OPEN times, UTC, inclusive. Bars before DEV_START are warm-up input only.
DEV_START = "2020-01-01 00:00"
DEV_END = "2022-06-30 23:00"
VAL_START = "2022-07-01 00:00"
VAL_END = "2025-06-30 23:00"
VAULT_START = "2025-07-01 00:00"
# VAULT_END = last complete hour of the build snapshot (fixed at build time).
VAULT_END = "2026-11-18 09:00"

BAR = "1h"

# ---------------------------------------------------------------- engine
FEE_PER_SIDE = 0.00055        # 5.5 bps taker
SLIPPAGE_PER_SIDE = 0.0002    # 2 bps
COST_RATE = FEE_PER_SIDE + SLIPPAGE_PER_SIDE   # 7.5 bps per side on traded notional
COST_STRESS_MULT = 2.0
REBALANCE_BAND = 0.01         # rebalance ALL when any |target - drifted| > band
MAX_GROSS = 1.0               # sum(|w|) <= 1, each w in [-1, 1]
GROSS_TOL = 1e-12             # float tolerance on the gross sum only
LIQUIDATION_FRAC = 0.025      # worst intrabar equity <= 2.5% of gross notional -> liquidation
FUNDING_STRESS_PAY = 1.5      # G2: funding paid x1.5
FUNDING_STRESS_RECV = 0.5     # G2: funding received x0.5
DEPLOY_RISK_BUDGET = 0.20     # deploy_scale = min(1, 0.20 / maxDD(DEV+VAL))

# ---------------------------------------------------------------- statistics
PERIODS_PER_YEAR = 365        # daily returns, calendar days
EULER_GAMMA = 0.5772156649

# ---------------------------------------------------------------- integrity
LOOKAHEAD_CUTS = 25           # uniform random cut bars (spec)
LOOKAHEAD_TRANSITION_CUTS = 25  # extra cuts at signal-transition bars (stricter addition)
LOOKAHEAD_TOL = 1e-9
# Lookahead rework (H5): compare ALL rows from the bar before DEV start up to each cut.
LOOKAHEAD_MAX_TRANSITION_CUTS = 300   # every decision-change row if <= 300, else a random 300
LOOKAHEAD_UNIFORM_CUTS = 200
LOOKAHEAD_MIN_TRANSITION_CUTS = 100   # floor if the sample must be reduced for time
LOOKAHEAD_MIN_UNIFORM_CUTS = 100
LOOKAHEAD_BATCH = 100                 # cuts per child process
JITTER_LOOKAHEAD_CUTS = 20            # light check per jitter variant
# Invariance (H4)
TIME_SHIFTS_WEEKS = (52, -104)
PRICE_SCALES = (0.25, 8.0)
VOLUME_SCALE = 4.0
SCALE_TOL = 1e-9
SCALE_MAX_ROW_FRAC = 0.0002           # at most 0.02% of rows may differ (floating-point ties)
# Child processes (H1)
CHILD_TIMEOUT_S = 900
CHILD_WORKERS = 6
# Activity counts DECISIONS: bars where the strategy's TARGET weight vector changes by more
# than DECISION_TOL in any asset (drift-triggered rebalances are not decisions).
DECISION_TOL = 0.01
MIN_DECISIONS_ALL = 40        # executed in DEV+VAL
MIN_DECISIONS_VAL = 10        # executed in VAL

# ---------------------------------------------------------------- gates
G1_PSR_MIN = 0.90
JITTER_N = 12
JITTER_LO = 0.8
JITTER_HI = 1.2
JITTER_MEDIAN_FRAC = 0.5
JITTER_POSITIVE_FRAC = 0.75
PERM_N = 200
PERM_MIN_OFFSET_DAYS = 30
# G6 threshold set by calibration (protocol v2 on the final hardened pipeline,
# ledger/calibration_43099ad9550d2be7.json): the largest value in the pre-declared grid
# (0.025, 0.05, 0.10) whose DEV-overfit null pass rate per counted trial is <= 3.0% under BOTH
# nulls. Null A: 4/373, 12/373, 14/373; null B: 1/355, 5/355, 11/355 -> only 0.025 qualifies.
# Oracle power at Sharpe 1.5 at 0.025: A fast 0.80, A slow 0.62, B fast 0.84, B slow 0.79
# (stop rule v2 passed).
PERM_P_MAX = 0.025
G7_BUCKETS = (
    ("2020", "2020-01-01 00:00", "2020-12-31 23:00"),
    ("2021", "2021-01-01 00:00", "2021-12-31 23:00"),
    ("2022", "2022-01-01 00:00", "2022-12-31 23:00"),
    ("2023", "2023-01-01 00:00", "2023-12-31 23:00"),
    ("2024", "2024-01-01 00:00", "2024-12-31 23:00"),
    ("2025H1", "2025-01-01 00:00", "2025-06-30 23:00"),
)
G7_MIN_POSITIVE = 4
G7_MAX_SHARE = 0.5
G8_MIN_YEARS = 2.0
MAX_PARAMS = 6

# ---------------------------------------------------------------- pool
POOL_MAX = 5
