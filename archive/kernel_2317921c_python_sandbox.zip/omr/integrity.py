"""Static integrity of strategy files. Kernel module.

Threat model: the strategy author is the system's own LLM researcher. These checks catch honest
mistakes and make gaming require deliberate, visible effort. They are NOT a security sandbox
against someone with write access to the folder.

- parse_source: AST ALLOWLIST (imports, builtins, attribute names, statement kinds, module and
  class structure, no date literals) plus STATIC extraction of the strategy's metadata and
  params from literals. No strategy code is executed to learn its params.
- param_rule_violations: declared ranges must contain the whole jitter range; no zero default;
  ints need default +/- 1 inside the range; at most MAX_PARAMS.
- normalise_source: token stream used for trial identity.
- check_weights: each weight in [-1, 1], gross <= 1, finite (NaN = flat).
- load_trusted: in-process loading, for the calibration's built-in families ONLY.
"""
from __future__ import annotations

import ast
import builtins
import io
import math
import re
import tokenize
import types
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np

from omr import constants as C
from omr import indicators as _ind

# ---------------------------------------------------------------- allowlists

ALLOWED_IMPORTS = {("numpy", "np"), ("pandas", "pd"), ("math", None)}
ALLOWED_FROM = {"omr.strategy_api": {"Strategy", "Param"}, "omr.indicators": set(_ind.__all__)}
BUILTIN_ALLOW = {"abs", "min", "max", "len", "range", "float", "int", "bool", "round", "sum", "zip",
                 "enumerate", "sorted", "list", "dict", "tuple", "set", "True", "False", "None"}
CLASS_ATTRS = {"name", "family", "hypothesis", "kind", "datasets", "params"}
# Attribute names a strategy may use (numeric numpy / pandas vocabulary). Grow deliberately.
ATTR_ALLOW = {
    # numpy
    "where", "nan", "inf", "pi", "e", "isnan", "isfinite", "isinf", "absolute", "sign", "log", "log1p",
    "log2", "log10", "exp", "expm1", "sqrt", "square", "power", "maximum", "minimum", "fmax", "fmin",
    "clip", "mean", "std", "var", "sum", "prod", "cumsum", "cumprod", "diff", "full", "full_like", "zeros",
    "zeros_like", "ones", "ones_like", "empty", "arange", "linspace", "asarray", "array", "float64",
    "int64", "bool_", "nanmean", "nanstd", "nanmedian", "nanmax", "nanmin", "nansum", "percentile",
    "quantile", "median", "floor", "ceil", "trunc", "tanh", "concatenate", "vstack", "hstack",
    "column_stack", "stack", "all", "any", "argmax", "argmin", "argsort", "sort", "searchsorted",
    "nan_to_num", "logical_and", "logical_or", "logical_not", "logical_xor", "roll", "corrcoef", "cov",
    "max", "min", "isin", "unique", "count_nonzero", "nonzero", "flatnonzero", "interp", "tile", "repeat",
    "reshape", "ravel", "shape", "size", "ndim", "dtype", "astype", "copy", "T", "dot", "outer", "mod",
    "fmod", "floor_divide", "accumulate", "abs", "round",
    # pandas objects and methods
    "Series", "DataFrame", "Timedelta", "isna", "notna", "isnull", "notnull", "concat", "rolling",
    "expanding", "ewm", "count", "shift", "pct_change", "cummax", "cummin", "where", "mask", "fillna",
    "ffill", "to_numpy", "values", "index", "columns", "iloc", "loc", "iat", "at", "reindex", "resample",
    "last", "first", "agg", "apply", "rank", "corr", "dropna", "align", "groupby", "transform", "hour",
    "dayofweek", "day_of_week", "weekday", "idxmax", "idxmin", "nlargest", "nsmallest", "sort_values", "sort_index",
    "nunique", "value_counts", "between", "eq", "ne", "lt", "le", "gt", "ge", "add", "sub", "mul", "div",
    "truediv", "pow", "empty",
    # containers
    "append", "extend", "items", "keys", "get",
}
FORBIDDEN_NODES = (ast.Global, ast.Nonlocal, ast.Try, ast.Raise, ast.With, ast.AsyncWith,
                   ast.AsyncFunctionDef, ast.AsyncFor, ast.Await, ast.Yield, ast.YieldFrom,
                   ast.Import, ast.ImportFrom, ast.ClassDef, ast.AnnAssign, ast.Match, ast.Assert)
if hasattr(ast, "TryStar"):
    FORBIDDEN_NODES = FORBIDDEN_NODES + (ast.TryStar,)
BUILTIN_NAMES = set(dir(builtins))
NAME_RE = re.compile(r"^[A-Za-z0-9_]{1,80}$")
_MON = r"(jan|feb|mar|apr|may|jun|jul|aug|sep|sept|oct|nov|dec)[a-z]*"
DATE_RES = [re.compile(p, re.IGNORECASE) for p in (
    r"(?<!\d)(19|20)\d{2}\s*[-/._]\s*(0?[1-9]|1[0-2])(?!\d)",                       # 2022-11, 2022/11/08
    r"(?<!\d)(0?[1-9]|[12]\d|3[01])\s*[-/._]\s*(0?[1-9]|1[0-2])\s*[-/._]\s*(19|20)\d{2}(?!\d)",  # 08/11/2022
    r"(?<!\d)(19|20)\d{2}(0[1-9]|1[0-2])(0[1-9]|[12]\d|3[01])(?!\d)",              # 20221108
    r"\b" + _MON + r"\.?\s+(\d{1,2},?\s+)?(19|20)\d{2}\b",                          # Nov 2022, Nov 8, 2022
    r"\b\d{1,2}\s+" + _MON + r"\.?\s+(19|20)\d{2}\b",                               # 8 Nov 2022
)]


@dataclass
class Parsed:
    violations: list = field(default_factory=list)   # [(code, message)]
    meta: dict = field(default_factory=dict)

    @property
    def ok(self):
        return not self.violations

    @property
    def code(self):
        return self.violations[0][0] if self.violations else None


def _num(node):
    """Numeric literal (int/float, optionally negated) -> float, else None."""
    if isinstance(node, ast.Constant) and isinstance(node.value, (int, float)) and not isinstance(node.value, bool):
        return float(node.value)
    if isinstance(node, ast.UnaryOp) and isinstance(node.op, (ast.USub, ast.UAdd)):
        v = _num(node.operand)
        return None if v is None else (-v if isinstance(node.op, ast.USub) else v)
    return None


def _is_dunder(name: str) -> bool:
    return name.startswith("__")


def parse_source(source: str) -> Parsed:
    out = Parsed()
    V = out.violations

    def bad(code, node, msg):
        V.append((code, f"line {getattr(node, 'lineno', '?')}: {msg}"))

    try:
        source.encode("ascii")
    except UnicodeEncodeError:
        V.append(("ast_not_ascii", "source is not ASCII"))
        return out
    try:
        tree = ast.parse(source)
    except SyntaxError as e:
        V.append(("ast_syntax", f"syntax error at line {e.lineno}"))
        return out

    bound = set()
    classes = []
    for node in tree.body:
        if isinstance(node, ast.Expr) and isinstance(node.value, ast.Constant) and isinstance(node.value.value, str):
            continue                                                     # docstring
        if isinstance(node, ast.Import):
            for a in node.names:
                if (a.name, a.asname) not in ALLOWED_IMPORTS:
                    bad("ast_import", node, f"import {a.name}{' as ' + a.asname if a.asname else ''} not allowed "
                        "(allowed: import numpy as np, import pandas as pd, import math)")
                bound.add(a.asname or a.name)
        elif isinstance(node, ast.ImportFrom):
            allowed = ALLOWED_FROM.get(node.module or "")
            if node.level != 0 or allowed is None:
                bad("ast_import", node, f"from {node.module} import ... not allowed")
                continue
            for a in node.names:
                if a.asname is not None or a.name not in allowed:
                    bad("ast_import", node, f"from {node.module} import {a.name} not allowed")
                bound.add(a.name)
        elif isinstance(node, ast.Assign):
            if len(node.targets) == 1 and isinstance(node.targets[0], ast.Name) and _num(node.value) is not None:
                bound.add(node.targets[0].id)
            else:
                bad("ast_structure", node, "module level may hold only imports, numeric constants and one class")
        elif isinstance(node, ast.ClassDef):
            classes.append(node)
            bound.add(node.name)
        else:
            bad("ast_structure", node, f"{type(node).__name__} not allowed at module level")
    if len(classes) != 1:
        V.append(("ast_structure", f"expected exactly one class, found {len(classes)}"))
        return out
    cls = classes[0]
    if cls.decorator_list or cls.keywords or len(cls.bases) != 1 or not (
            isinstance(cls.bases[0], ast.Name) and cls.bases[0].id == "Strategy"):
        bad("ast_structure", cls, "the class must be 'class X(Strategy):' with no decorators or keywords")

    meta = {"class_name": cls.name, "datasets": (), "params": {}}
    methods = []
    for node in cls.body:
        if isinstance(node, ast.Expr) and isinstance(node.value, ast.Constant) and isinstance(node.value.value, str):
            continue
        if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name) \
                and node.targets[0].id in CLASS_ATTRS:
            key = node.targets[0].id
            v = node.value
            if key in ("name", "family", "hypothesis", "kind"):
                if isinstance(v, ast.Constant) and isinstance(v.value, str):
                    meta[key] = v.value
                else:
                    bad("ast_meta", node, f"{key} must be a string literal")
            elif key == "datasets":
                if isinstance(v, (ast.Tuple, ast.List)) and all(isinstance(e, ast.Constant) and isinstance(e.value, str)
                                                                for e in v.elts):
                    meta["datasets"] = tuple(e.value for e in v.elts)
                else:
                    bad("ast_meta", node, "datasets must be a tuple of string literals")
            elif key == "params":
                meta["params"] = _parse_params(v, bad, node)
        elif isinstance(node, ast.FunctionDef):
            methods.append(node)
            if _is_dunder(node.name):
                bad("ast_dunder", node, f"dunder method {node.name} not allowed")
        else:
            bad("ast_structure", node, "class body may hold only name/family/hypothesis/kind/datasets/params and methods")
    out.meta = meta

    # bound names (one namespace: a name bound anywhere may not shadow a builtin)
    for node in ast.walk(cls):
        if isinstance(node, ast.FunctionDef):
            bound.add(node.name)
            a = node.args
            for arg in a.posonlyargs + a.args + a.kwonlyargs + ([a.vararg] if a.vararg else []) + ([a.kwarg] if a.kwarg else []):
                bound.add(arg.arg)
            for d in a.defaults + [x for x in a.kw_defaults if x is not None]:
                if not (isinstance(d, ast.Constant) and not isinstance(d.value, (list, dict, set))):
                    bad("ast_mutable_default", d, "default arguments must be constants")
            if node.decorator_list:
                bad("ast_decorator", node, "decorators not allowed")
        elif isinstance(node, ast.Lambda):
            for arg in node.args.args:
                bound.add(arg.arg)
        elif isinstance(node, ast.Name) and isinstance(node.ctx, (ast.Store, ast.Del)):
            bound.add(node.id)
        elif isinstance(node, ast.arg):
            bound.add(node.arg)
    for n in sorted(bound):
        if n in BUILTIN_NAMES and n not in ("True", "False", "None"):
            V.append(("ast_shadow_builtin", f"name {n!r} shadows a Python builtin; rename it"))
        if _is_dunder(n):
            V.append(("ast_dunder", f"dunder name {n!r} not allowed"))

    for fn in methods:
        for node in ast.walk(fn):
            if node is fn:
                continue
            if isinstance(node, FORBIDDEN_NODES):
                bad("ast_statement", node, f"{type(node).__name__} not allowed inside methods")
            elif isinstance(node, ast.FunctionDef) and node.decorator_list:
                bad("ast_decorator", node, "decorators not allowed")
    for node in ast.walk(tree):
        if isinstance(node, ast.Attribute):
            if not isinstance(node.ctx, ast.Load):
                bad("ast_attribute_assignment", node, f"assignment to attribute .{node.attr} not allowed")
            if node.attr.startswith("_"):
                bad("ast_dunder" if _is_dunder(node.attr) else "forbidden_attribute", node,
                    f"attribute .{node.attr} not allowed (underscore)")
            elif node.attr not in ATTR_ALLOW:
                bad("forbidden_attribute", node, f"attribute .{node.attr} is not on the allowlist")
        elif isinstance(node, ast.AugAssign) and isinstance(node.target, ast.Attribute):
            bad("ast_attribute_assignment", node, "augmented assignment to an attribute not allowed")
        elif isinstance(node, ast.Name) and isinstance(node.ctx, ast.Load):
            if _is_dunder(node.id):
                bad("ast_dunder", node, f"name {node.id} not allowed")
            elif node.id not in bound and node.id not in BUILTIN_ALLOW:
                bad("ast_name", node, f"name {node.id} is not defined in the file and not an allowed builtin")
        elif isinstance(node, ast.Constant) and isinstance(node.value, str):
            if any(r.search(node.value) for r in DATE_RES):
                bad("ast_date_literal", node, "string literal looks like a calendar date")
        elif isinstance(node, (ast.Global, ast.Nonlocal)):
            bad("ast_statement", node, "global/nonlocal not allowed")

    for key in ("name", "family", "hypothesis", "kind"):
        if key not in meta:
            V.append(("ast_meta", f"class attribute {key} missing"))
    if "name" in meta and not NAME_RE.match(meta["name"]):
        V.append(("ast_meta", "name must match [A-Za-z0-9_]{1,80}"))
    if "hypothesis" in meta and len(meta["hypothesis"].strip()) < 10:
        V.append(("ast_meta", "hypothesis must be a pre-registered rationale"))
    if meta.get("kind") not in ("single", "portfolio"):
        V.append(("ast_meta", "kind must be 'single' or 'portfolio'"))
    names = {m.name for m in methods}
    need = "signal" if meta.get("kind") == "single" else "weights"
    if need not in names:
        V.append(("ast_meta", f"kind {meta.get('kind')} must define {need}(self, ...)"))
    return out


def _parse_params(v, bad, node) -> dict:
    out = {}
    if not isinstance(v, ast.Dict):
        bad("ast_meta", node, "params must be a dict literal of Param(...) calls")
        return out
    for k, val in zip(v.keys, v.values):
        if not (isinstance(k, ast.Constant) and isinstance(k.value, str) and NAME_RE.match(k.value)):
            bad("ast_meta", node, "param names must be identifier string literals")
            continue
        if not (isinstance(val, ast.Call) and isinstance(val.func, ast.Name) and val.func.id == "Param"):
            bad("ast_meta", node, f"param {k.value} must be Param(default, low, high, kind)")
            continue
        fields = ["default", "low", "high", "kind"]
        got = {}
        for i, a in enumerate(val.args):
            if i < 4:
                got[fields[i]] = a
        for kw in val.keywords:
            got[kw.arg] = kw.value
        nums = {f: _num(got.get(f)) for f in ("default", "low", "high")}
        kind_node = got.get("kind")
        kind = "float" if kind_node is None else (kind_node.value if isinstance(kind_node, ast.Constant) else None)
        if any(x is None for x in nums.values()) or kind not in ("int", "float"):
            bad("ast_meta", node, f"param {k.value}: default/low/high must be numeric literals and kind 'int' or 'float'")
            continue
        out[k.value] = {**nums, "kind": kind}
    return out


def param_rule_violations(params: dict) -> list:
    """[(code, message)] for the H6 rules. params: {name: {default, low, high, kind}}."""
    v = []
    if len(params) > C.MAX_PARAMS:
        v.append(("too_many_params", f"{len(params)} params declared (max {C.MAX_PARAMS})"))
    for k, p in params.items():
        d, lo, hi = p["default"], p["low"], p["high"]
        if not all(math.isfinite(x) for x in (d, lo, hi)) or not (lo < hi and lo <= d <= hi):
            v.append(("param_rules", f"{k}: need finite low < high and low <= default <= high"))
            continue
        if p["kind"] == "int" and not all(float(x).is_integer() for x in (d, lo, hi)):
            v.append(("param_rules", f"{k}: int param needs integral default/low/high"))
            continue
        if d == 0:
            v.append(("param_rules", f"{k}: a zero default is not allowed (it cannot be jittered)"))
            continue
        j_lo, j_hi = sorted((C.JITTER_LO * d, C.JITTER_HI * d))
        if lo > j_lo + 1e-12 * abs(d) or hi < j_hi - 1e-12 * abs(d):
            v.append(("param_rules", f"{k}: declared range must contain the jitter range [{j_lo:.6g}, {j_hi:.6g}]"))
        if p["kind"] == "int" and (lo > d - 1 or hi < d + 1):
            v.append(("param_rules", f"{k}: int range must contain default +/- 1"))
    return v


def default_params(params: dict) -> dict:
    return {k: (int(p["default"]) if p["kind"] == "int" else float(p["default"])) for k, p in params.items()}


# ---------------------------------------------------------------- identity

def normalise_source(source: str) -> str:
    """Token stream without comments or blank-line/whitespace differences (version-stable)."""
    toks = []
    for tok in tokenize.generate_tokens(io.StringIO(source.replace("\r\n", "\n")).readline):
        if tok.type in (tokenize.COMMENT, tokenize.NL, tokenize.ENCODING, tokenize.ENDMARKER):
            continue
        if tok.type == tokenize.NEWLINE:
            toks.append("<NL>")
        elif tok.type == tokenize.INDENT:
            toks.append("<IN>")
        elif tok.type == tokenize.DEDENT:
            toks.append("<DE>")
        else:
            toks.append(tok.string)
    return " ".join(toks)


# ---------------------------------------------------------------- weights

def check_weights(W: np.ndarray) -> list:
    """[(reason, detail)] for violations. NaN means flat and is allowed."""
    W = np.asarray(W, dtype=np.float64)
    fin = np.where(np.isnan(W), 0.0, W)
    if not np.all(np.isfinite(fin)):
        return [("non_finite", "weights contain inf")]
    out = []
    if np.any(np.abs(fin) > 1.0):
        out.append(("weights_out_of_range", "a weight outside [-1, 1]"))
    gross = np.abs(fin).sum(axis=1)
    if np.any(gross > C.MAX_GROSS + C.GROSS_TOL):
        out.append(("gross_exceeds_1", "gross sum(|w|) above 1"))
    return out


# ---------------------------------------------------------------- trusted in-process loading (calibration only)

@dataclass
class Loaded:
    path: Path
    source: str
    cls: type
    obj: object
    meta: dict


_counter = [0]


def load_trusted(path) -> Loaded:
    """Load a TRUSTED built-in strategy file in-process (calibration families only).
    Never used by the evaluator, the sandbox or the census."""
    from omr.strategy_api import Strategy
    src = Path(path).read_text(encoding="ascii")
    parsed = parse_source(src)
    if not parsed.ok:
        raise ValueError(f"trusted family {path} fails the allowlist: {parsed.violations[:3]}")
    _counter[0] += 1
    mod = types.ModuleType(f"omr_trusted_{_counter[0]}")
    exec(compile(src, str(path), "exec"), mod.__dict__)
    cls = [v for v in mod.__dict__.values() if isinstance(v, type) and issubclass(v, Strategy)
           and v is not Strategy and v.__module__ == mod.__name__][0]
    return Loaded(Path(path), src, cls, cls(), parsed.meta)
