import numpy as np
import pandas as pd

from omr.strategy_api import Strategy, Param
from omr.indicators import resample_ohlcv, sma, realised_vol, align_to_base


class VolTargetTrendLS(Strategy):
    name = "gen000_voltarget_trend_ls"
    family = "trend"
    hypothesis = (
        "Trend direction from the daily close versus its 50-day SMA (+1 above, -1 below), sized to a "
        "40% annualised volatility target: size = min(1, 0.40 / realised vol of the last 30 daily log "
        "returns x sqrt(365)). Mechanism: trend persistence plus volatility clustering - cutting size in "
        "high-vol regimes should improve risk-adjusted return. Falsified if VAL PSR(0) < 0.90 or the "
        "timing permutation p > 0.025."
    )
    kind = "single"
    params = {"sma": Param(50, 20, 150, "int"), "vol_lookback": Param(30, 10, 90, "int"),
              "target_vol": Param(0.40, 0.2, 0.8, "float")}

    def signal(self, bars, p):
        d = resample_ohlcv(bars, "1D")
        c = d["close"]
        ma = sma(c, p["sma"])
        vol = realised_vol(c, p["vol_lookback"], 365.0)
        direction = np.where(c > ma, 1.0, -1.0)
        v = vol.to_numpy()
        safe = np.where(v > 0.0, v, 1.0)
        size = np.where(v > 0.0, np.minimum(1.0, p["target_vol"] / safe), np.where(v == 0.0, 1.0, np.nan))
        s = pd.Series(direction * size, index=d.index)
        s[ma.isna() | vol.isna()] = np.nan
        return align_to_base(s, bars.index, "1D")
