import numpy as np
import pandas as pd

from omr.strategy_api import Strategy, Param
from omr.indicators import resample_ohlcv, sma, align_to_base


class SmaCrossLS(Strategy):
    name = "gen000_sma_cross_ls"
    family = "trend"
    hypothesis = (
        "Crypto perps trend over weeks to months: when the 20-day SMA of the daily close is above "
        "the 100-day SMA, being long (+1) earns more than being short, and vice versa (-1). "
        "Mechanism: slow diffusion of information and herding/leverage cycles; the other side is "
        "early mean-reversion traders and hedgers. Falsified if VAL PSR(0) < 0.90 or the timing "
        "permutation shows no timing skill."
    )
    kind = "single"
    params = {"fast": Param(20, 5, 60, "int"), "slow": Param(100, 50, 250, "int")}

    def signal(self, bars, p):
        d = resample_ohlcv(bars, "1D")
        fast = sma(d["close"], p["fast"])
        slow = sma(d["close"], p["slow"])
        s = pd.Series(np.where(fast > slow, 1.0, -1.0), index=d.index)
        s[fast.isna() | slow.isna()] = np.nan
        return align_to_base(s, bars.index, "1D")
