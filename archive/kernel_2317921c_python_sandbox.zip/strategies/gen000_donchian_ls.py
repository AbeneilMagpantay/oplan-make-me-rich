import numpy as np
import pandas as pd

from omr.strategy_api import Strategy, Param
from omr.indicators import resample_ohlcv, align_to_base


class DonchianLS(Strategy):
    name = "gen000_donchian_ls"
    family = "trend"
    hypothesis = (
        "Breakouts persist: a daily close above the highest high of the prior 20 completed days starts "
        "an up-move worth holding long; a close below the lowest low of the prior 20 starts a down-move "
        "worth holding short. Longs exit to flat below the prior-10-day low, shorts above the prior-10-day "
        "high. Mechanism: stop cascades and delayed participation after range breaks. Falsified if VAL "
        "PSR(0) < 0.90 or timing permutation p > 0.025."
    )
    kind = "single"
    params = {"entry": Param(20, 10, 60, "int"), "exit": Param(10, 5, 30, "int")}

    def signal(self, bars, p):
        d = resample_ohlcv(bars, "1D")
        hh_e = d["high"].rolling(p["entry"], min_periods=p["entry"]).max().shift(1).to_numpy()
        ll_e = d["low"].rolling(p["entry"], min_periods=p["entry"]).min().shift(1).to_numpy()
        hh_x = d["high"].rolling(p["exit"], min_periods=p["exit"]).max().shift(1).to_numpy()
        ll_x = d["low"].rolling(p["exit"], min_periods=p["exit"]).min().shift(1).to_numpy()
        c = d["close"].to_numpy()
        out = np.full(len(c), np.nan)
        pos = 0.0
        for i in range(len(c)):
            if np.isnan(hh_e[i]) or np.isnan(ll_e[i]):
                continue
            if c[i] > hh_e[i]:
                pos = 1.0
            elif c[i] < ll_e[i]:
                pos = -1.0
            elif pos == 1.0 and c[i] < ll_x[i]:
                pos = 0.0
            elif pos == -1.0 and c[i] > hh_x[i]:
                pos = 0.0
            out[i] = pos
        return align_to_base(pd.Series(out, index=d.index), bars.index, "1D")
