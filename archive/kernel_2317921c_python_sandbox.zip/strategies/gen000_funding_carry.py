import numpy as np
import pandas as pd

from omr.strategy_api import Strategy, Param


class FundingCarry(Strategy):
    name = "gen000_funding_carry"
    family = "carry"
    hypothesis = (
        "Persistent funding is a carry premium: when the mean of the last 21 funding settlements "
        "(normalised to an 8h rate) is above 0.0003, shorting collects funding from crowded leveraged "
        "longs (-1); when it is below -0.0001, going long collects from crowded shorts (+1); otherwise "
        "flat. Re-decided at each settlement. The other side pays to hold leveraged directional exposure. "
        "Falsified if VAL PSR(0) < 0.90 or the funding stress (paid x1.5, received x0.5) turns it negative."
    )
    kind = "single"
    datasets = ("funding",)
    params = {"lookback": Param(21, 6, 90, "int"), "hi": Param(0.0003, 0.00015, 0.001, "float"),
              "lo": Param(-0.0001, -0.0005, 0.0, "float")}

    def signal(self, bars, p):
        new = bars["funding.new"].to_numpy(dtype=bool)
        rate8 = (bars["funding.rate"] * 8.0 / bars["funding.interval_hours"])[new]
        f = rate8.rolling(p["lookback"], min_periods=p["lookback"]).mean()
        fv = f.to_numpy()
        sig = np.where(fv > p["hi"], -1.0, np.where(fv < p["lo"], 1.0, 0.0))
        sig = np.where(np.isnan(fv), np.nan, sig)
        ev = pd.Series(sig, index=rate8.index)
        return ev.reindex(bars.index).ffill()
