import numpy as np
import pandas as pd

from omr.strategy_api import Strategy, Param
from omr.indicators import resample_ohlcv, rsi_wilder, align_to_base


class RsiMeanrevLS(Strategy):
    name = "gen000_rsi_meanrev_ls"
    family = "meanrev"
    hypothesis = (
        "Short-horizon overreaction reverts: on 4h bars, Wilder RSI(14) below 50-band marks an oversold "
        "move worth buying and holding until RSI recovers above 50; RSI above 50+band marks an overbought "
        "move worth shorting until RSI falls below 50. Mechanism: liquidity provision against forced and "
        "impatient flow. Falsified if VAL PSR(0) < 0.90, costs (2x) kill it, or timing permutation p > 0.025."
    )
    kind = "single"
    params = {"period": Param(14, 7, 28, "int"), "band": Param(20, 10, 30, "float")}

    def signal(self, bars, p):
        b4 = resample_ohlcv(bars, "4h")
        rsi = rsi_wilder(b4["close"], p["period"]).to_numpy()
        lo = 50.0 - p["band"]
        hi = 50.0 + p["band"]
        out = np.full(len(rsi), np.nan)
        pos = 0.0
        for i in range(len(rsi)):
            r = rsi[i]
            if np.isnan(r):
                continue
            if r < lo:
                pos = 1.0
            elif r > hi:
                pos = -1.0
            elif pos == 1.0 and r > 50.0:
                pos = 0.0
            elif pos == -1.0 and r < 50.0:
                pos = 0.0
            out[i] = pos
        return align_to_base(pd.Series(out, index=b4.index), bars.index, "4h")
