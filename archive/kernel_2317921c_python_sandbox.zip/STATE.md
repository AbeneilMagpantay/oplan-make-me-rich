# STATE (2026-11-18, end of the build session, after the review hardening)

## Where things stand

- Kernel v1 (perps, hardened) is locked:
  `2317921c99e9361e7457e93037b88ff7af58d763ff10a044d3636667569617cd` (38 files).
  Approval label: "coordinator (Claude), pre-genesis construction, zero trials
  evaluated; human confirmation pending". History: `ledger/kernel_history.jsonl`
  (row 1 = first genesis lock, row 2 = this re-key).
- Data: Binance USD-M perps, 10 symbols, klines + funding + mark_klines. Snapshot
  end 2026-11-18 10:00 UTC; VAULT end fixed at 09:00. research_hash
  `cf26f534cf1c9f4a0bff334c77a041ed66862484a7dc167581cd50562783b4d8`.
- Tests: 131 pass (about 2 minutes; child processes included).
- Ledger: 0 trials. **Generation 0 has NOT been run** (stopped before gen 0 on
  the coordinator's order). `generations/gen000/PLAN.md` and the five strategy
  files exist; the strategy files were edited only to satisfy the allowlist
  (outputs bit-identical on real DEV data) and all five pass stage 1 on real DEV
  data.
- Final calibration (`ledger/calibration_43099ad9550d2be7.json`, run on the
  hardened pipeline before the docs/constant comment edits): G6 threshold 0.025
  chosen mechanically; stop rule v2 passed (oracle power at true Sharpe 1.5:
  null A fast 0.80 / slow 0.62, null B fast 0.84 / slow 0.79).
- `ledger/val_access_log.jsonl` holds 3 calibration-purpose VAL handles (two
  aborted runs that crashed on calibration-code bugs, one complete run).

## Open decisions for the human

1. Confirm the kernel (the lock's approval is pending human confirmation).
2. KP-003: the null pass rate is read per counted pair (stricter, chosen 0.025);
   per all pairs, 0.10 would qualify.
3. KP-006: positions still encode calendar dates (residual hole).
4. Note before generation 0: the SMA-cross baseline makes only 16 decisions in
   DEV and needs at least 24 in VAL to pass the activity check; if it fails there
   it is a counted `integrity_fail_val`.

## Next session

Read this file and the latest build report. Do not run generation 0 until the
human says so. Any kernel change -> tests, re-run `python -m omr.calibrate`, one
re-key with the human's approval.
