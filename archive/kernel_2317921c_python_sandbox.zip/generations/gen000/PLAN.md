# Generation 0 - PLAN (pre-registered 2026-11-18, before any real VAL result)

Five fixed baselines, all kind "single" (the kernel trades each core perp,
BTCUSDT and ETHUSDT, at weight = signal / 2). Params are fixed as written; no
tuning. Each is evaluated exactly once on the locked kernel:

    python -m omr.evaluate strategies/<file>.py --generation 0

Regions: DEV 2020-01-01 .. 2022-06-30 (uncounted), VAL 2022-07-01 .. 2025-06-30
(counted). Costs 7.5 bps per side, funding charged on the drifted position at
each settlement, gross <= 1. Tier 1 needs all of G1-G9 (CONSTITUTION section 7).

Common falsifier for every baseline: it fails at least one Tier-1 gate. A
baseline that passes Tier 1 goes to the paper pool; that is "worth
paper-trading", not "profitable".

Known before evaluation (from DEV data, no strategy result involved): the
ETHUSDT perp printed a last-trade high of 323 against a ~96 open on 2020-03-13
02:00 UTC. Under the v1 liquidation rule any baseline holding an ETH short of
about 0.42 x equity or more through that hour fails integrity with
`liquidation` (KERNEL_PROPOSALS KP-001). That is accepted as part of the v1
instrument, not worked around.

## 1. gen000_sma_cross_ls (trend)

- Rule: +1 when SMA(20) > SMA(100) of the daily close, else -1. Daily bars are
  completed bars, visible from the 23:00 bar of their day. fast=20 [5,60],
  slow=100 [50,250].
- Hypothesis: crypto perps trend over weeks to months; being on the side of the
  medium-term trend earns more than the opposite side, net of costs and funding.
- Mechanism: slow diffusion of information, herding and leverage cycles that
  push prices further in the direction already taken. Other side: early
  mean-reversion traders, hedgers, and - when long in a bull market - the
  funding the long side pays.
- Falsified by: VAL PSR(0) < 0.90 (G1), no timing skill against circular shifts
  (G6 p > 0.025), or a loss under funding stress (G2) because longs in bull
  markets pay most of the funding.
- Relation: baseline; the reference trend rule.

## 2. gen000_donchian_ls (trend)

- Rule: long (+1) when the daily close > highest high of the prior 20 completed
  days; short (-1) when the daily close < lowest low of the prior 20. A long
  exits to flat when the close < lowest low of the prior 10; a short exits to
  flat when the close > highest high of the prior 10. Entries take priority over
  exits, so a long can reverse straight to short on a 20-day breakdown (and vice
  versa). entry=20 [10,60], exit=10 [5,30].
- Hypothesis: range breakouts start moves that persist long enough to pay for
  false breakouts.
- Mechanism: stop-loss cascades and delayed participation after a range breaks.
  Other side: range traders fading the breakout.
- Falsified by: G1, G6, or G7 (profits concentrated in one bucket, e.g. 2020-21).
- Relation: baseline; a second trend rule with a different entry trigger and a
  flat state.

## 3. gen000_rsi_meanrev_ls (meanrev)

- Rule: on 4h bars, Wilder RSI(14). Long when RSI < 50 - band, held until
  RSI > 50; short when RSI > 50 + band, held until RSI < 50. Entries take priority
  over exits. period=14 [7,28], band=20 [10,30] (band treated as a float param).
- Hypothesis: short-horizon overreactions revert within days.
- Mechanism: liquidity provision against forced and impatient flow
  (liquidations, stop runs). Other side: traders who must trade now.
- Falsified by: G1, G4 (it should trade more often, so 2x costs may kill it), G6.
- Relation: baseline; the only mean-reversion family in gen 0. Expected to have
  low power under the planted-trend calibration (by design of that test).

## 4. gen000_voltarget_trend_ls (trend)

- Rule: direction +1 if the daily close > SMA(50) else -1; size =
  min(1, 0.40 / realised vol), realised vol = std of the last 30 daily log
  returns x sqrt(365). sma=50 [20,150], vol_lookback=30 [10,90],
  target_vol=0.40 [0.2,0.8].
- Hypothesis: trend persistence plus volatility clustering; cutting size in
  high-volatility regimes improves risk-adjusted returns.
- Mechanism: as for the other trend rules; volatility targeting also reduces
  exposure in crash regimes where trend signals are least reliable.
- Falsified by: G1 or G6; or G5 if the result depends on the exact vol target.
- Relation: baseline; trend with continuous position sizing (more rebalances).

## 5. gen000_funding_carry (carry)

- Rule: f = mean of the last 21 funding settlements, each normalised to an
  8h-equivalent rate (rate x 8 / interval_hours). -1 when f > 0.0003, +1 when
  f < -0.0001, else flat; re-decided at each settlement. lookback=21 [6,90],
  hi=0.0003 [0.00015,0.001], lo=-0.0001 [-0.0005,0.0]. Declares the funding
  dataset.
- Hypothesis: persistently high funding is a carry premium paid by crowded
  leveraged longs; shorting collects it (and negative funding pays longs).
- Mechanism: demand for leveraged long exposure exceeds supply; the short side
  is paid to provide it. Other side: leveraged directional longs.
- Falsified by: G1, G2 (funding stress halves what it receives and raises what
  it pays), or the activity check (it may be flat most of the time when funding
  sits at the 0.0001 base rate).
- Relation: baseline; the only family that uses the funding dataset.
