# Oplan Make me Rich - perpetual-futures research kernel v1

A research system that tests trading-strategy ideas on Binance USDT-margined
perpetual futures (BTCUSDT and ETHUSDT, with eight other perps used only to veto)
and reports, as honestly as it can, whether an idea has an edge. It is built to
make "no edge" the easy answer.

It does not trade. There are no exchange keys and no order code in this build.

## Layout

| path | what | who may change it |
|---|---|---|
| `omr/` | kernel: data, engine, statistics, integrity, evaluator, ledger, pool, census | human re-key only |
| `tests/` | kernel tests | human re-key only |
| `CONSTITUTION.md` | the rules, constants and live requirements | human re-key only |
| `requirements.txt` | pinned dependencies | human re-key only |
| `strategies/` | strategy files | research loop |
| `generations/` | per-generation PLAN.md and REPORT.md | research loop |
| `LESSONS.md`, `STATE.md`, `RESEARCH_PLAYBOOK.md`, `KERNEL_PROPOSALS.md` | research notes and protocol | research loop |
| `ledger/` | trials, returns, pool, census, calibration, kernel history | written by kernel commands only |
| `data/` | stored market data and manifest | written by `omr.data` only |
| `kernel.lock` | kernel file hashes | `omr.kernel_lock rekey` only |

## Commands

Run from the project root with the venv interpreter, e.g.
`.venv\Scripts\python.exe -m omr.status`.

    python -m omr.status                         kernel, data, trial counts (M, N, rho), pool, last census
    python -m omr.sandbox <file> [--set k=v]     DEV-only exploration with the stage-1 checks, not a trial
    python -m omr.evaluate <file> --generation N stage 1 (DEV, uncounted) then a counted trial (VAL, gates G1-G9, DSR)
    python -m omr.ledger verify | summary        hash chains and file hashes / trial list
    python -m omr.pool list | admit | remove     paper pool (max 5, Tier 1 only)
    python -m omr.census                         update data, forward results of pool members
    python -m omr.calibrate [--reread FILE]      measure the pipeline on synthetic worlds (or re-read a stored run)
    python -m omr.kernel_lock verify | rekey     kernel lock (rekey needs --reason and --approved-by)
    python -m omr.data download | update [--admit NAME] | verify | summary
    python -m pytest tests -q -p no:cacheprovider

Setup on a new machine: create a venv, `pip install -r requirements.txt`, then
`python -m omr.data download`. A fresh download produces a different snapshot
end; the research_hash only covers data up to VAL end and should match the
original if Binance has not revised its history.

## How strategy code is run

Strategy files are parsed statically (an allowlist of imports, builtins and
attribute names; params read from literals) and then run only in short-lived
child processes that see a private copy of `omr/strategy_api.py` and
`omr/indicators.py` and nothing else of the kernel. The evaluator first runs a
DEV-only stage (uncounted), writes a counted `pending` ledger row, and only then
gives VAL bars to the strategy. This is a set of tripwires for honest mistakes
and casual gaming, not a security sandbox; see CONSTITUTION section 2.

## Honest expectations

- Most strategies will fail. The gates are set so that a strategy with no real
  edge passes rarely; that also means many weak real edges fail.
- Every backtest here, the vault included, is optimistic: the language model
  that writes strategies has read about this market history. Only forward
  results, measured after a strategy is frozen, are clean.
- A Tier-1 pass means "worth paper-trading", nothing more. Nothing here implies
  profit.
- Nothing here trades real money. The live requirements in `CONSTITUTION.md`
  section 11 are written down, not implemented.
