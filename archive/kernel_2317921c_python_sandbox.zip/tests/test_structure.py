"""Structural tests over the kernel source."""
import ast
from pathlib import Path

from omr import data

OMR = Path(__file__).resolve().parent.parent / "omr"
LATEST_ALLOWED = {"data.py", "census.py"}
LOADERS = {"load_raw", "load_frame", "load_frames", "load_liq", "load_liqs"}


def test_latest_ceiling_only_in_data_and_census():
    offenders = []
    for f in sorted(OMR.glob("*.py")):
        tree = ast.parse(f.read_text(encoding="ascii"))
        for node in ast.walk(tree):
            if isinstance(node, ast.Constant) and node.value == "latest" and f.name not in LATEST_ALLOWED:
                offenders.append(f"{f.name}:{node.lineno}")
    assert offenders == [], offenders


def test_every_loader_call_passes_a_literal_ceiling():
    bad, seen = [], 0
    for f in sorted(OMR.glob("*.py")):
        tree = ast.parse(f.read_text(encoding="ascii"))
        for node in ast.walk(tree):
            if isinstance(node, ast.Call):
                fn = node.func
                name = fn.attr if isinstance(fn, ast.Attribute) else getattr(fn, "id", None)
                if name in LOADERS:
                    seen += 1
                    kw = {k.arg: k.value for k in node.keywords}
                    v = kw.get("upto")
                    if f.name == "datasets.py" and isinstance(v, ast.Name) and v.id == "upto":
                        continue        # the registry passes its own argument through
                    if not (isinstance(v, ast.Constant) and v.value in data.CEILINGS):
                        bad.append(f"{f.name}:{node.lineno}")
                    elif v.value == "latest" and f.name not in LATEST_ALLOWED:
                        bad.append(f"{f.name}:{node.lineno} uses latest")
    assert seen >= 4
    assert bad == [], bad


def test_ceilings_cap_at_region_ends():
    assert str(data.ceiling_ts("dev_end")) == "2022-06-30 23:00:00+00:00"
    assert str(data.ceiling_ts("val_end")) == "2025-06-30 23:00:00+00:00"
    assert data.ceiling_ts("latest") is None


def test_kernel_source_is_ascii():
    root = OMR.parent
    for f in list(OMR.glob("*.py")) + list((root / "tests").glob("*.py")):
        f.read_bytes().decode("ascii")
