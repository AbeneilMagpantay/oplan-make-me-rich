"""Calibration constructions: null-B mirror (OHLC consistency, r' = 2m - r) and oracle alignment."""
import math

import numpy as np
import pandas as pd

from omr import calibrate as K
from omr import pipeline
from conftest import synth_frames


def _fake_source(nd=3, seed=0):
    rng = np.random.default_rng(seed)
    o_rel = np.exp(0.001 * rng.standard_normal((nd, 24)))
    c_rel = np.exp(0.01 * rng.standard_normal((nd, 24)))
    hr = np.maximum(1.0, c_rel) * np.exp(np.abs(0.005 * rng.standard_normal((nd, 24))))
    lr = np.minimum(1.0, c_rel) * np.exp(-np.abs(0.005 * rng.standard_normal((nd, 24))))
    has = np.ones((nd, 24), dtype=bool)
    has[1, 5] = False
    v = {"days": pd.date_range("2021-01-01", periods=nd, freq="D", tz="UTC").as_unit("ns"), "nd": nd,
         "g": o_rel, "hr": hr, "lr": lr, "cr": c_rel,
         "gm": o_rel.copy(), "hm": hr * 0.999 + 0.001, "lm": lr, "cm": c_rel, "has": has,
         "other": np.ones((nd, 24, len(K.OTHER))), "gap": np.zeros((nd, 24), dtype=bool),
         "fhour": np.zeros(0, dtype=np.int64), "frate": np.zeros(0), "fint": np.zeros(0),
         "offs": np.zeros(nd + 1, dtype=np.int64), "p0": 100.0, "mp0": 100.0, "m": 0.0002, "m_mark": 0.0002}
    return v


def test_null_b_mirror_is_consistent_and_negates_the_demeaned_path():
    v = _fake_source()
    days = np.arange(3)
    f0, _ = K._synth_symbol(v, days, np.zeros(3, dtype=bool), ())
    f1, liq1 = K._synth_symbol(v, days, np.array([False, True, False]), ())
    o, h, l, c = (f1[k].to_numpy() for k in ("open", "high", "low", "close"))
    assert np.all(h >= np.maximum(o, c) - 1e-12) and np.all(l <= np.minimum(o, c) + 1e-12)
    # day 0 identical to the unflipped world
    assert np.allclose(f1.iloc[:24][["open", "high", "low", "close"]].to_numpy(),
                       f0.iloc[:24][["open", "high", "low", "close"]].to_numpy(), rtol=0, atol=1e-12)
    # day 1 close-to-close log returns: r' = 2m - r
    c0 = f0["close"].to_numpy()
    r = np.diff(np.log(c0))[23:47]
    r1 = np.diff(np.log(c))[23:47]
    assert np.allclose(r1, 2 * v["m"] - r, atol=1e-12)
    # a mirrored bar swaps high and low excursions: high'/open' = open/low
    b = 24 + 7
    assert abs(h[b] / o[b] - 1.0 / v["lr"][1, 7]) < 1e-12 and abs(l[b] / o[b] - 1.0 / v["hr"][1, 7]) < 1e-12
    # the bar without mark data falls back to last-price ratios
    assert not liq1["has_mark"].iloc[24 + 5] and liq1["has_mark"].iloc[24 + 6]


def test_oracle_uses_the_future_block_return():
    w = pipeline.World(core=synth_frames(start="2019-11-28 00:00", end="2025-06-30 23:00", seed=9))
    ws = K.oracle_weights(w, 20, [1.0, 0.0], eps_seed=1)
    W1 = ws[1.0].to_numpy()
    grid = ws[1.0].index
    mk = pipeline.Market(w, grid)
    starts = np.arange(mk.dev_s, mk.val_e, 480)
    ends = np.minimum(starts + 480, mk.val_e)
    R = np.log(mk.op[ends, 0] / mk.op[starts, 0])
    sgn = np.where(R - R.mean() >= 0, 0.5, -0.5)
    assert np.allclose(W1[starts - 1, 0], sgn)                   # decided at the 23:00 bar before the block
    assert np.allclose(W1[ends - 2, 0], sgn)                     # held to the end of the block
    assert np.all(W1[: mk.dev_s - 1] == 0.0)                     # flat before DEV
    assert K.oracle_val_sharpe(w, ws[1.0]) > 3.0
    assert abs(K.oracle_val_sharpe(w, ws[0.0])) < K.oracle_val_sharpe(w, ws[1.0]) / 2
