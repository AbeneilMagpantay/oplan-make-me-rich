"""H9: VAL access needs a ledger-issued handle."""
import numpy as np
import pytest

from omr import access
from omr import datasets as D
from omr import ledger
from omr import paths as P
from omr import pipeline
from omr.runner import InProcessRunner
from conftest import synth_world, obj_from_source, spec_from_source

SRC = """
import pandas as pd
from omr.strategy_api import Strategy, Param

class L(Strategy):
    name = "t_long"
    family = "test"
    hypothesis = "test: constant long for access checks"
    kind = "single"
    params = {}

    def signal(self, bars, p):
        return pd.Series(1.0, index=bars.index)
"""


@pytest.mark.parametrize("fn,args", [
    (D.load_raw, ("klines", "BTCUSDT")), (D.load_frame, ("BTCUSDT", ())), (D.load_frames, (("BTCUSDT",), ())),
    (D.load_liq, ("BTCUSDT",)), (D.load_liqs, (("BTCUSDT",),)),
])
@pytest.mark.parametrize("upto", ["val_end", "latest"])
def test_val_loaders_raise_without_handle(fn, args, upto):
    with pytest.raises(PermissionError):
        fn(*args, upto=upto)


def test_pipeline_val_entry_points_raise_without_handle():
    w = synth_world(seed=2)
    spec, params = spec_from_source(SRC)
    runner = InProcessRunner(obj_from_source(SRC), "single")
    with pytest.raises(PermissionError):
        pipeline.stage2(runner, spec, params, w, None, pipeline.Opts(full_integrity=False), np.random.default_rng(1), None, 1)
    with pytest.raises(PermissionError):
        pipeline.evaluate_world(runner, spec, params, w, 1, pipeline.Opts(full_integrity=False), None)
    grid = pipeline.core_grid(w.core, w.symbols)
    import pandas as pd
    with pytest.raises(PermissionError):
        pipeline.evaluate_weights(pd.DataFrame(np.zeros((len(grid), 2)), index=grid), w, 1, pipeline.Opts(), None)


def test_handles_cannot_be_constructed_directly_and_calibration_handles_are_logged(tmp_path, monkeypatch):
    with pytest.raises(PermissionError):
        access.ValHandle("forged", None, "x")
    monkeypatch.setattr(P, "VAL_ACCESS_LOG", tmp_path / "val_access_log.jsonl")
    h = access.for_calibration("unit test purpose")
    assert isinstance(h, access.ValHandle)
    rows = ledger.read_rows(tmp_path / "val_access_log.jsonl")
    assert len(rows) == 1 and rows[0]["purpose"] == "unit test purpose" and ledger.verify_chain(tmp_path / "val_access_log.jsonl") == []
    with pytest.raises(ValueError):
        access.for_calibration("   ")


def test_pending_row_issues_the_trial_handle(tmp_ledger):
    row, h = ledger.append_pending({"trial_id": "abcdabcdabcdabcd", "generation": 0})
    assert isinstance(h, access.ValHandle) and h.trial_id == "abcdabcdabcdabcd" and h.token == row["row_hash"]
    assert ledger.trial_states()["abcdabcdabcdabcd"]["status"] == "incomplete"
