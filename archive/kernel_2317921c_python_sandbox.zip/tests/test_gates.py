"""H12: gate logic (G5-G8) with pass and fail cases, dsr_for, and evaluate_file flows (dedupe, write
order, M counting, pending/incomplete)."""
import json

import numpy as np
import pandas as pd
import pytest

from omr import access
from omr import calibrate as K
from omr import evaluate
from omr import ledger
from omr import paths as P
from omr import pipeline
from omr import stats as S
from conftest import synth_world

FAST = pipeline.Opts(n_transition=40, n_uniform=40, batch=40, jitter_n=3, perm_n=30)


def test_g5_rule():
    assert pipeline.g5_rule(1.0, [0.8, 0.9, 0.7, 0.6, 1.1, 0.95, 0.85, 0.75])["pass"]
    assert not pipeline.g5_rule(1.0, [0.8, -0.1, -0.2, 0.3, 0.2, -0.3, 0.1, 0.2])["pass"]       # < 75% positive
    assert not pipeline.g5_rule(2.0, [0.5, 0.6, 0.7, 0.8, 0.9, 0.5, 0.6, 0.7])["pass"]          # median < 0.5 x base


def test_g6_rule_and_oracle_integration(val_handle):
    assert pipeline.g6_rule(2.0, np.linspace(-1, 1, 200))["pass"]
    assert not pipeline.g6_rule(0.0, np.linspace(-1, 1, 200))["pass"]
    w = synth_world(seed=21)
    ws = K.oracle_weights(w, 1, [1.0, 0.0], eps_seed=4)
    opts = pipeline.Opts(perm_n=60, keep_detail=False)
    good = pipeline.evaluate_weights(ws[1.0], w, 3, opts, val_handle)
    noise = pipeline.evaluate_weights(ws[0.0], w, 3, opts, val_handle)
    assert good["gates"]["G6"]["pass"] and good["gates"]["G6"]["value"] <= 0.02
    assert not noise["gates"]["G6"]["pass"]


def test_g7_rule():
    assert pipeline.g7_rule([0.1, 0.12, 0.08, -0.05, 0.09, 0.07])["pass"]
    assert not pipeline.g7_rule([0.1, -0.1, -0.1, -0.1, 0.1, 0.2])["pass"]                     # 3 of 6 positive
    assert not pipeline.g7_rule([2.0, 0.01, 0.01, 0.01, 0.01, -0.1])["pass"]                    # one bucket dominates


def test_g8_rule_and_portfolio_tuples():
    assert pipeline.g8_rule([0.3, 0.1, -0.2, 0.4, 0.2, -0.1, 0.5, 0.05])["pass"]
    assert not pipeline.g8_rule([0.3, -0.1, -0.2, -0.4, 0.2, -0.1, -0.5, 0.05])["pass"]
    from omr import constants as C
    assert pipeline.g8_tuples(C.EXTENDED, 2) == [("SOLUSDT", "BNBUSDT"), ("XRPUSDT", "ADAUSDT"),
                                                 ("DOGEUSDT", "LTCUSDT"), ("LINKUSDT", "AVAXUSDT")]


def test_dsr_for_counts_trials_without_returns_in_M_only(tmp_ledger):
    rng = np.random.default_rng(0)
    days = pd.date_range("2022-07-01", "2025-06-30", freq="D", tz="UTC")
    r1 = pd.Series(0.001 + 0.02 * rng.standard_normal(len(days)), index=days)
    sha = ledger.save_returns("aaaaaaaaaaaaaaaa", r1)
    ledger.append_pending({"trial_id": "aaaaaaaaaaaaaaaa"})
    ledger.append(P.TRIALS_JSONL, {"trial_id": "aaaaaaaaaaaaaaaa", "status": "evaluated", "returns_sha256": sha})
    ledger.append_pending({"trial_id": "bbbbbbbbbbbbbbbb"})                       # counted, never finished
    ledger.append_pending({"trial_id": "cccccccccccccccc"})                       # the current trial
    cur = pd.Series(0.002 + 0.02 * rng.standard_normal(len(days)), index=days)
    d = evaluate.dsr_for("cccccccccccccccc", cur)
    assert d["M"] == 3                                    # all three pending rows count
    mat = ledger.counted_val_matrix(extra={"cccccccccccccccc": cur})
    assert mat.shape[1] == 2                              # V and rho only from trials with returns
    assert abs(d["rho"] - S.mean_pairwise_corr(mat)) < 1e-15
    assert abs(d["N"] - S.effective_n(3, d["rho"])) < 1e-12


CLEAN = """
import numpy as np
import pandas as pd
from omr.strategy_api import Strategy, Param
from omr.indicators import resample_ohlcv, sma, align_to_base

class Clean(Strategy):
    name = "t_clean_eval"
    family = "test"
    hypothesis = "test: clean daily sma through the evaluator"
    kind = "single"
    params = {"n": Param(20, 5, 50, "int")}

    def signal(self, bars, p):
        d = resample_ohlcv(bars, "1D")
        ma = sma(d["close"], p["n"])
        s = pd.Series(np.where(d["close"] > ma, 1.0, -1.0), index=d.index)
        s[ma.isna()] = np.nan
        return align_to_base(s, bars.index, "1D")
"""


class SynthProvider:
    def __init__(self, world, on_val=None, fail_val=False):
        self.world, self.on_val, self.fail_val, self.val_calls = world, on_val, fail_val, 0

    def check(self):
        return "synthetic-research-hash"

    def dev_frames(self, extra):
        return pipeline.dev_frames(self.world)

    def val_world(self, extra, handle):
        access.require(handle, "SynthProvider.val_world")
        self.val_calls += 1
        if self.on_val:
            self.on_val()
        if self.fail_val:
            raise KeyboardInterrupt("simulated crash after the pending row")
        return self.world


def _write(tmp_path, src, name="s.py"):
    f = tmp_path / name
    f.write_text(src, encoding="ascii")
    return f


def test_evaluate_file_write_order_dedupe_and_counting(tmp_path, tmp_ledger):
    w = synth_world(seed=31)
    seen = {}

    def at_val():   # the moment VAL frames are requested
        st = ledger.trial_states()
        seen["rows"] = [r["status"] for t in st.values() for r in t["rows"]]
        seen["returns_files"] = list(P.RETURNS_DIR.glob("*")) if P.RETURNS_DIR.exists() else []
        seen["detail_files"] = list(P.TRIAL_DETAIL_DIR.glob("*")) if P.TRIAL_DETAIL_DIR.exists() else []

    f = _write(tmp_path, CLEAN)
    row = evaluate.evaluate_file(str(f), 0, provider=SynthProvider(w, at_val), opts=FAST, quiet=True, require_lock=False)
    assert seen["rows"] == ["pending"] and seen["returns_files"] == [] and seen["detail_files"] == []
    rows = ledger.trials()
    assert [r["status"] for r in rows] == ["pending", "evaluated"]
    assert rows[1]["pending_hash"] == rows[0]["row_hash"] and row["status"] == "evaluated"
    assert ledger.counted_ids() == [row["trial_id"]] and row["M"] == 1
    detail = json.loads((P.TRIAL_DETAIL_DIR / f"{row['trial_id']}.json").read_text())
    assert set(detail["jitter"]) == {"n", "median", "frac_positive"}            # no neighbour values or params
    assert "seed" in detail["lookahead"]
    # dedupe: the identical file returns the existing row and appends nothing
    again = evaluate.evaluate_file(str(f), 0, provider=SynthProvider(w), opts=FAST, quiet=True, require_lock=False)
    assert again["trial_id"] == row["trial_id"] and len(ledger.trials()) == 2
    assert ledger.verify_all(log=lambda s: None)


def test_stage1_failure_is_one_uncounted_row_and_a_crash_after_pending_is_incomplete(tmp_path, tmp_ledger):
    w = synth_world(seed=32)
    cheat = CLEAN.replace('d = resample_ohlcv(bars, "1D")', 'd = resample_ohlcv(bars, "1D")\n        d = d.shift(-1)')
    prov = SynthProvider(w)
    r1 = evaluate.evaluate_file(str(_write(tmp_path, cheat, "c.py")), 0, provider=prov, opts=FAST, quiet=True,
                                require_lock=False)
    assert r1["status"] == "integrity_fail" and r1["reason"] == "lookahead" and prov.val_calls == 0
    assert set(r1) >= {"reason"} and "detail" not in r1 and "integrity_detail" not in r1
    assert ledger.counted_ids() == []
    crash = CLEAN.replace("t_clean_eval", "t_crash_eval")
    with pytest.raises(KeyboardInterrupt):
        evaluate.evaluate_file(str(_write(tmp_path, crash, "k.py")), 0, provider=SynthProvider(w, fail_val=True),
                               opts=FAST, quiet=True, require_lock=False)
    st = ledger.trial_states()
    inc = [tid for tid, t in st.items() if t["status"] == "incomplete"]
    assert len(inc) == 1 and ledger.counted_ids() == inc
    msgs = []
    ledger.verify_all(log=msgs.append)
    assert any(m.startswith("INCOMPLETE trial") for m in msgs)
