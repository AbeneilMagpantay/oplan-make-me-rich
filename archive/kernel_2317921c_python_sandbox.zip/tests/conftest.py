"""Shared synthetic-data helpers for the kernel tests (no network, no real data unless a test says so)."""
import sys
import types
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from omr import datasets as D  # noqa: E402


def synth_raw(start="2021-01-01 00:00", end="2022-06-30 23:00", seed=0, drift=0.0, vol=0.01,
              funding_every=8, funding_rate=0.0001):
    """Random-walk 1h klines on a complete grid plus 8-hourly funding settlements."""
    rng = np.random.default_rng(seed)
    idx = pd.date_range(pd.Timestamp(start, tz="UTC"), pd.Timestamp(end, tz="UTC"), freq="h").as_unit("ns")
    n = len(idx)
    lr = drift + vol * rng.standard_normal(n)
    close = 100.0 * np.exp(np.cumsum(lr))
    opn = np.r_[100.0, close[:-1]]
    spread = np.abs(vol * rng.standard_normal(n)) * close
    high = np.maximum(opn, close) + spread
    low = np.minimum(opn, close) - spread
    kl = pd.DataFrame({"open": opn, "high": high, "low": low, "close": close,
                       "volume": rng.uniform(1, 10, n), "quote_volume": rng.uniform(100, 1000, n),
                       "trades": rng.integers(10, 100, n).astype(float),
                       "taker_buy_volume": rng.uniform(0, 1, n), "taker_buy_quote_volume": rng.uniform(0, 100, n),
                       "is_gap": np.zeros(n, dtype=bool)}, index=idx)
    kl.index.name = "open_time"
    ft = idx[idx.hour % funding_every == 0]
    fu = pd.DataFrame({"rate": funding_rate + 0.0001 * rng.standard_normal(len(ft)),
                       "interval_hours": float(funding_every), "offset_ms": 0.0}, index=ft)
    fu.index.name = "settle_time"
    return {"klines": kl, "funding": fu}


def synth_frame(extra=(), **kw):
    return D.assemble_frame(synth_raw(**kw), tuple(extra))


def synth_frames(symbols=("BTCUSDT", "ETHUSDT"), extra=(), **kw):
    seed = kw.pop("seed", 0)
    return {s: synth_frame(extra=extra, seed=seed + i, **kw) for i, s in enumerate(symbols)}


def synth_world(seed=11, extended=0, **kw):
    """Core symbols start at different times, as in the real data (BTC 2019-09, ETH 2019-11)."""
    from omr import constants as C
    from omr import pipeline
    core = {"BTCUSDT": synth_frame(start="2019-09-09 00:00", end="2025-06-30 23:00", seed=seed, **kw),
            "ETHUSDT": synth_frame(start="2019-11-28 00:00", end="2025-06-30 23:00", seed=seed + 1, **kw)}
    ext = {}
    if extended:
        ext = synth_frames(symbols=C.EXTENDED[:extended], start="2020-01-01 00:00", end="2025-06-30 23:00",
                           seed=seed + 100, **kw)
    return pipeline.World(core=core, extended=ext)


def obj_from_source(src: str):
    """TEST ONLY: exec a strategy source in-process and return an instance (for InProcessRunner)."""
    from omr.strategy_api import Strategy
    mod = types.ModuleType("test_strategy")
    exec(compile(src, "test_strategy.py", "exec"), mod.__dict__)
    cls = [v for v in mod.__dict__.values() if isinstance(v, type) and issubclass(v, Strategy) and v is not Strategy][0]
    return cls()


def spec_from_source(src: str):
    from omr import integrity as I
    from omr import pipeline
    p = I.parse_source(src)
    assert p.ok, p.violations
    return pipeline.Spec(kind=p.meta["kind"], datasets=tuple(p.meta.get("datasets", ())), params=p.meta["params"]), \
        I.default_params(p.meta["params"])


@pytest.fixture
def val_handle(tmp_path, monkeypatch):
    """A calibration-purpose ValHandle whose access-log row goes to a temp file."""
    from omr import access
    from omr import paths as P
    monkeypatch.setattr(P, "VAL_ACCESS_LOG", tmp_path / "val_access_log.jsonl")
    return access.for_calibration("pytest")


@pytest.fixture
def tmp_ledger(tmp_path, monkeypatch):
    """Point every ledger path at a temp directory."""
    from omr import evaluate
    from omr import paths as P
    led = tmp_path / "ledger"
    for name, rel in (("LEDGER_DIR", ""), ("TRIALS_JSONL", "trials.jsonl"), ("TRIAL_DETAIL_DIR", "trials"),
                      ("TRIAL_SOURCE_DIR", "sources"), ("RETURNS_DIR", "returns"), ("FORWARD_DIR", "forward"),
                      ("VAL_ACCESS_LOG", "val_access_log.jsonl"), ("POOL_LOG", "pool_log.jsonl"),
                      ("CENSUS_LOG", "census_log.jsonl"), ("SANDBOX_LOG", "sandbox_log.jsonl"),
                      ("KERNEL_HISTORY", "kernel_history.jsonl")):
        monkeypatch.setattr(P, name, led / rel if rel else led)
    monkeypatch.setattr(evaluate, "LOCK", led / ".evaluate.lock")
    led.mkdir(parents=True, exist_ok=True)
    return led
