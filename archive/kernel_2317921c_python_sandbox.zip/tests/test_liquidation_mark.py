"""Liquidation on MARK price (KP-001): ratios, fallback, engine, Market, and a real-data regression."""
import numpy as np
import pandas as pd
import pytest

from omr import datasets as D
from omr import engine as E
from omr import paths as P
from omr import pipeline
from conftest import synth_raw


def _ts(s):
    return pd.Timestamp(s, tz="UTC").as_unit("ns")


def test_liquidation_ratios_use_mark_and_fall_back_to_last_price():
    raw = synth_raw(start="2022-03-01 00:00", end="2022-03-01 05:00", seed=1)
    kl = raw["klines"].copy()
    kl.iloc[2, kl.columns.get_loc("high")] = kl["open"].iloc[2] * 3.0          # last-price wick in bar 2
    idx = kl.index
    o = kl["open"]
    mark = pd.DataFrame({"open": o, "high": o * 1.01, "low": o * 0.99, "close": o, "samples": 3600.0},
                        index=idx).drop(idx[4])                                 # bar 4 has no mark row
    lq = D.liquidation_ratios(kl, mark)
    assert lq["has_mark"].tolist() == [True, True, True, True, False, True]
    assert abs(lq["up"].iloc[2] - 1.01) < 1e-12                                 # mark, not the 3x wick
    assert abs(lq["dn"].iloc[2] - 0.99) < 1e-12
    assert abs(lq["up"].iloc[4] - kl["high"].iloc[4] / kl["open"].iloc[4]) < 1e-12   # fallback
    lq0 = D.liquidation_ratios(kl, None)
    assert abs(lq0["up"].iloc[2] - 3.0) < 1e-12 and not lq0["has_mark"].any()


def test_engine_liquidates_on_the_ratios_it_is_given():
    op = np.full(3, 100.0)
    dn = np.ones(3)
    tgt = np.full(3, -0.5)
    zero = np.zeros(3)
    assert E.run_arrays(op, dn, np.array([1.0, 1.05, 1.0]), zero, tgt)[7] == -1     # benign mark
    assert E.run_arrays(op, dn, np.array([1.0, 3.0, 1.0]), zero, tgt)[7] == 1       # last-price wick
    # 2.5% maintenance rule: short 1.0 needs up >= 1.975 to trip; 1.97 does not, 1.98 does
    t1 = np.full(3, -1.0)
    assert E.run_arrays(op, dn, np.array([1.0, 1.97, 1.0]), zero, t1)[7] == -1
    assert E.run_arrays(op, dn, np.array([1.0, 1.98, 1.0]), zero, t1)[7] == 1


def test_market_takes_mark_ratios_from_world_liq():
    raws = {s: synth_raw(start="2019-12-30 00:00", end="2020-01-03 23:00", seed=i)
            for i, s in enumerate(("BTCUSDT", "ETHUSDT"))}
    frames = {s: D.assemble_frame(r) for s, r in raws.items()}
    liq = {}
    for s, r in raws.items():
        o = r["klines"]["open"]
        mark = pd.DataFrame({"open": o, "high": o * 1.02, "low": o * 0.97, "close": o, "samples": 3600.0}, index=o.index)
        liq[s] = D.liquidation_ratios(r["klines"], mark)
    grid = frames["BTCUSDT"].index
    mk = pipeline.Market(pipeline.World(core=frames, liq=liq), grid)
    assert np.allclose(mk.up, 1.02) and np.allclose(mk.dn, 0.97)
    mk0 = pipeline.Market(pipeline.World(core=frames), grid)                   # no liq -> last price
    k = raws["BTCUSDT"]["klines"]
    assert np.allclose(mk0.up[:, 0], (k["high"] / k["open"]).to_numpy())


REAL = (P.DATA_DIR / "mark_klines" / "ETHUSDT.parquet").exists() and (P.DATA_DIR / "klines" / "ETHUSDT.parquet").exists()


@pytest.mark.skipif(not REAL, reason="real data not downloaded (python -m omr.data download)")
def test_real_eth_wick_half_equity_short_is_not_liquidated():
    kl = D.load_raw("klines", "ETHUSDT", upto="dev_end")
    lq = D.load_liq("ETHUSDT", upto="dev_end")
    a, b = _ts("2020-03-12 20:00"), _ts("2020-03-13 06:00")
    seg, l = kl.loc[a:b], lq.loc[a:b]
    t02 = _ts("2020-03-13 02:00")
    assert kl.loc[t02, "high"] == 323.0 and kl.loc[t02, "open"] == 95.73      # the real last-price wick
    assert bool(l.loc[t02, "has_mark"]) and l.loc[t02, "up"] < 1.3              # mark high 119.47 / open 96.66
    op = seg["open"].to_numpy()
    tgt = np.full(len(seg), -0.5)
    zero = np.zeros(len(seg))
    assert E.run_arrays(op, l["dn"].to_numpy(), l["up"].to_numpy(), zero, tgt)[7] == -1
    # control: the v1 last-price rule liquidates exactly at the 02:00 bar
    liq_last = E.run_arrays(op, (seg["low"] / seg["open"]).to_numpy(), (seg["high"] / seg["open"]).to_numpy(), zero, tgt)[7]
    assert seg.index[liq_last] == t02
    # the same through the kernel's Market path (frame + liq as the evaluator builds them)
    frame = D.load_frame("ETHUSDT", (), upto="dev_end")
    world = pipeline.World(core={"ETHUSDT": frame}, symbols=("ETHUSDT",), liq={"ETHUSDT": lq})
    mk = pipeline.Market(world, frame.index)
    s = int(frame.index.get_loc(a))
    e = int(frame.index.get_loc(b))
    r = mk.run(np.full((len(frame), 1), -0.5), s, e)
    assert not r.liquidated
