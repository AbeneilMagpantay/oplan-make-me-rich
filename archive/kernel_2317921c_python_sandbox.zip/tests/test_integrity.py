"""Static allowlist, params, and stage-1 integrity through child processes (synthetic frames)."""
import secrets

import numpy as np
import pytest

from omr import constants as C
from omr import integrity as I
from omr import pipeline
from omr.runner import ChildRunner
from conftest import synth_frames, synth_world, spec_from_source

HEAD = """
import numpy as np
import pandas as pd
from omr.strategy_api import Strategy, Param
from omr.indicators import resample_ohlcv, sma, align_to_base

class S(Strategy):
    name = "t_strategy"
    family = "test"
    hypothesis = "test strategy for the integrity checks"
    kind = "single"
    params = {"n": Param(20, 5, 50, "int")}
"""

CLEAN = HEAD + """
    def signal(self, bars, p):
        d = resample_ohlcv(bars, "1D")
        ma = sma(d["close"], p["n"])
        s = pd.Series(np.where(d["close"] > ma, 1.0, -1.0), index=d.index)
        s[ma.isna()] = np.nan
        return align_to_base(s, bars.index, "1D")
"""

CHEAT_SHIFT = HEAD + """
    def signal(self, bars, p):
        c = bars["close"]
        return pd.Series(np.where(c.shift(-1) > c, 1.0, -1.0), index=bars.index)
"""

# daily close used from 00:00 of the same day (before the day has closed)
CHEAT_DAILY = HEAD + """
    def signal(self, bars, p):
        d = bars["close"].resample("1D").last()
        ma = d.rolling(p["n"]).mean()
        s = pd.Series(np.where(d > ma, 1.0, -1.0), index=d.index)
        s[ma.isna()] = np.nan
        return s.reindex(bars.index).ffill()
"""

FAST = pipeline.Opts(n_transition=60, n_uniform=60, batch=60)


def dev_only(world):
    return pipeline.dev_frames(world)


@pytest.fixture(scope="module")
def world():
    return synth_world(seed=7)


def run_stage1(src, world, opts=FAST):
    spec, params = spec_from_source(src)
    return pipeline.stage1(ChildRunner(src, spec.kind), spec, params, dev_only(world), C.CORE, opts,
                           np.random.default_rng(secrets.randbits(63)))


def test_clean_daily_sma_passes_stage1(world):
    s1 = run_stage1(CLEAN, world)
    assert s1["ok"], s1["code"]
    assert s1["cuts"] >= 100
    assert s1["W"].index[-1] == pipeline.T(C.DEV_END)
    # the symbols start at different times (as in the real data); weights live on the common grid
    assert world.core["BTCUSDT"].index[0] < world.core["ETHUSDT"].index[0] == s1["W"].index[0]


def test_shift_minus_one_cheat_is_caught(world):
    s1 = run_stage1(CHEAT_SHIFT, world)
    assert not s1["ok"] and s1["code"] == "lookahead"


def test_daily_bar_before_close_cheat_is_caught(world):
    s1 = run_stage1(CHEAT_DAILY, world)
    assert not s1["ok"] and s1["code"] == "lookahead"


def test_allowlist_accepts_clean_and_gen0_style_sources():
    assert I.parse_source(CLEAN).ok
    for f in (C.__file__,):
        assert f
    from omr.paths import STRATEGIES_DIR
    for f in STRATEGIES_DIR.glob("gen000_*.py"):
        p = I.parse_source(f.read_text(encoding="ascii"))
        assert p.ok, (f.name, p.violations)
        assert I.param_rule_violations(p.meta["params"]) == []


@pytest.mark.parametrize("snippet,code", [
    ("import os", "ast_import"),
    ("import omr.strategy_api", "ast_import"),
    ("from omr import indicators as ind", "ast_import"),
    ("from omr.data import load_manifest", "ast_import"),
    ("from pandas import read_parquet", "ast_import"),
    ("from numpy import load", "ast_import"),
    ("X = {}", "ast_structure"),
    ("print('x')", "ast_structure"),
])
def test_module_level_constructs_are_rejected(snippet, code):
    src = CLEAN.replace("from omr.indicators import resample_ohlcv, sma, align_to_base",
                        "from omr.indicators import resample_ohlcv, sma, align_to_base\n" + snippet)
    p = I.parse_source(src)
    assert not p.ok and code in [c for c, _ in p.violations]


@pytest.mark.parametrize("body,code", [
    ("x = np.fromregex", "forbidden_attribute"),
    ("x = np._pytesttester", "forbidden_attribute"),
    ("x = pd.read_csv", "forbidden_attribute"),
    ("x = bars.to_pickle", "forbidden_attribute"),
    ("x = bars.__class__", "ast_dunder"),
    ("x = getattr(pd, 'x')", "ast_name"),
    ("x = open('f')", "ast_name"),
    ("print(1)", "ast_name"),
    ("x = eval('1')", "ast_name"),
    ("x = type(bars)", "ast_name"),
    ("self.params = {}", "ast_attribute_assignment"),
    ("raise SystemExit('x')", "ast_statement"),
    ("x = '2022-11-08'", "ast_date_literal"),
    ("x = 'Nov 8 2022'", "ast_date_literal"),
    ("x = bars.index.strftime('%Y')", "forbidden_attribute"),
    ("x = bars.index.year", "forbidden_attribute"),
    ("x = bars.bfill()", "forbidden_attribute"),
    ("sum = 1", "ast_shadow_builtin"),
])
def test_method_level_constructs_are_rejected(body, code):
    src = CLEAN.replace('        d = resample_ohlcv(bars, "1D")', "        " + body + '\n        d = resample_ohlcv(bars, "1D")')
    p = I.parse_source(src)
    assert not p.ok and code in [c for c, _ in p.violations], p.violations


def test_dunder_method_decorator_and_mutable_default_are_rejected():
    src = CLEAN + "\n    def __len__(self):\n        return 1\n"
    assert "ast_dunder" in [c for c, _ in I.parse_source(src).violations]
    src = CLEAN + "\n    def helper(self, memo={}):\n        return 1\n"
    assert "ast_mutable_default" in [c for c, _ in I.parse_source(src).violations]


def test_static_params_and_rules():
    p = I.parse_source(CLEAN)
    assert p.meta["params"] == {"n": {"default": 20.0, "low": 5.0, "high": 50.0, "kind": "int"}}
    bad = {"n": {"default": 20.0, "low": 19.999, "high": 20.001, "kind": "float"},
           "z": {"default": 0.0, "low": -0.01, "high": 0.01, "kind": "float"},
           "k": {"default": 2.0, "low": 2.0, "high": 5.0, "kind": "int"},
           "neg": {"default": -0.0001, "low": -0.0005, "high": 0.0, "kind": "float"}}
    v = I.param_rule_violations(bad)
    names = " ".join(m for _, m in v)
    assert "n:" in names and "z:" in names and "k:" in names and "neg:" not in names
    many = {f"p{i}": {"default": 1.0, "low": 0.5, "high": 2.0, "kind": "float"} for i in range(7)}
    assert "too_many_params" in [c for c, _ in I.param_rule_violations(many)]


def test_source_normalisation_ignores_comments_and_blank_lines():
    a = CLEAN
    b = CLEAN.replace("    def signal", "    # a comment\n\n    def signal")
    c = CLEAN.replace('"1D")\n        ma', '"1D")\n        ma2 = 0\n        ma')
    assert I.normalise_source(a) == I.normalise_source(b)
    assert I.normalise_source(a) != I.normalise_source(c)
