"""Census forward-run test on synthetic frames that extend past VAULT_END (no real data)."""
import numpy as np
import pandas as pd

from omr import census
from omr import constants as C
from omr import engine as E
from omr import ledger
from omr import paths as P
from conftest import synth_frames

SRC = """
import numpy as np
import pandas as pd
from omr.strategy_api import Strategy, Param

class AlwaysLong(Strategy):
    name = "t_always_long"
    family = "test"
    hypothesis = "test: constant long, forward accounting check"
    kind = "single"
    params = {"x": Param(1.0, 0.5, 1.0, "float")}

    def signal(self, bars, p):
        return pd.Series(p["x"], index=bars.index)
"""


def test_census_runs_flat_from_birth_on_post_birth_bars_only(tmp_path, monkeypatch, val_handle):
    frames = synth_frames(start="2026-10-01 00:00", end="2026-11-25 23:00", seed=5)
    monkeypatch.setattr(census.D, "load_frames", lambda syms, extra, upto, handle=None: {s: frames[s] for s in syms})
    monkeypatch.setattr(census.D, "load_liqs", lambda syms, upto, handle=None: {})   # last-price fallback
    monkeypatch.setattr(P, "TRIAL_SOURCE_DIR", tmp_path / "sources")
    monkeypatch.setattr(P, "FORWARD_DIR", tmp_path / "forward")
    (tmp_path / "sources").mkdir()
    src = tmp_path / "sources" / "t0t0t0t0t0t0t0t0.py"
    src.write_text(SRC)
    trow = {"trial_id": "t0t0t0t0t0t0t0t0", "source_sha256": ledger.sha256_file(src), "params": {"x": 1.0},
            "born_at": "2026-11-20T05:20:00Z", "deploy_scale": 0.25}
    prow = {"at": "2026-11-20T06:40:00Z"}
    out = census.run_member(trow, prow, handle=val_handle)
    assert out["forward_start"] == "2026-11-20 07:00:00+00:00"          # later of birth/admission, next bar open
    assert out["days_forward"] == 5                                       # intervals ending at 00:00: 20 (from 07:00) .. 24
    fwd = pd.read_parquet(tmp_path / "forward" / "t0t0t0t0t0t0t0t0.parquet")
    assert str(fwd.index[0].date()) == "2026-11-20"
    g = frames["BTCUSDT"].index
    s = g.get_loc(pd.Timestamp("2026-11-20 07:00", tz="UTC"))
    e = g.get_loc(pd.Timestamp("2026-11-21 00:00", tz="UTC"))
    cols = lambda c: np.column_stack([frames[x][c].to_numpy()[s:e + 1] for x in C.CORE])
    op, lo, hi, fr = cols("open"), cols("low"), cols("high"), cols("funding_rate")
    out_e = E.run_arrays(op, lo / op, hi / op, fr, np.full(op.shape, 0.5))
    assert abs(fwd["ret_raw"].iloc[0] - (out_e[8][-1] - 1.0)) < 1e-12        # pre-trade equity at 00:00
    assert np.all(np.abs(fwd["ret_scaled"]) < np.abs(fwd["ret_raw"]) + 1e-15)
    early = census.forward_start({"born_at": "2024-01-01T00:00:00Z"}, {"at": "2024-01-02T00:00:00Z"})
    assert early == pd.Timestamp(C.VAULT_END, tz="UTC") + pd.Timedelta(hours=1)


def test_census_rejects_tampered_frozen_source(tmp_path, monkeypatch, val_handle):
    monkeypatch.setattr(P, "TRIAL_SOURCE_DIR", tmp_path)
    src = tmp_path / "t1t1t1t1t1t1t1t1.py"
    src.write_text(SRC)
    trow = {"trial_id": "t1t1t1t1t1t1t1t1", "source_sha256": "0" * 64, "params": {"x": 1.0},
            "born_at": "2026-11-20T05:20:00Z"}
    try:
        census.run_member(trow, {"at": "2026-11-20T06:00:00Z"}, handle=val_handle)
        raised = False
    except RuntimeError:
        raised = True
    assert raised
