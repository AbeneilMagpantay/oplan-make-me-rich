"""Activity counts DECISIONS (target changes > 0.01), not drift-triggered rebalances."""
import numpy as np

from omr import pipeline
from omr.runner import InProcessRunner
from conftest import synth_world, obj_from_source, spec_from_source

CONST = """
import pandas as pd
from omr.strategy_api import Strategy, Param

class Const(Strategy):
    name = "t_const"
    family = "test"
    hypothesis = "test: constant long, never re-decides"
    kind = "single"
    params = {}

    def signal(self, bars, p):
        return pd.Series(1.0, index=bars.index)
"""

TWICE_WEEKLY = """
import numpy as np
import pandas as pd
from omr.strategy_api import Strategy, Param

class Flip(Strategy):
    name = "t_flip"
    family = "test"
    hypothesis = "test: sign by day of week, decides twice a week"
    kind = "single"
    params = {}

    def signal(self, bars, p):
        dow = np.asarray(bars.index.day_of_week)
        return pd.Series(np.where(dow < 3, 1.0, -1.0), index=bars.index)
"""

QUICK = pipeline.Opts(full_integrity=False, include_g8=False, perm_n=10, keep_detail=False)


def test_decision_changes_ignore_small_and_drift_changes():
    Wn = np.zeros((100, 2))
    Wn[10:] = 0.5
    assert pipeline.decision_changes(Wn).sum() == 1 and pipeline.decision_changes(Wn)[10]
    Wn2 = Wn.copy()
    Wn2[50:, 0] = 0.505
    assert pipeline.decision_changes(Wn2).sum() == 1
    Wn3 = Wn.copy()
    Wn3[50:, 1] = 0.52
    assert pipeline.decision_changes(Wn3).sum() == 2


def test_count_decisions_uses_execution_regions():
    w = synth_world(seed=3)
    grid = pipeline.core_grid(w.core, w.symbols)
    mk = pipeline.Market(w, grid)

    def counts(rows):
        Wn = np.zeros((len(grid), 2))
        for i, r in enumerate(rows):
            Wn[r:, 0] = 0.25 * (1 + i % 2)
        return pipeline.count_decisions(Wn, mk)
    rows = [mk.dev_s - 2, mk.dev_s - 1, mk.dev_s + 100, mk.val_s - 1, mk.val_s + 500]
    assert counts(rows) == (4, 2)
    assert counts(rows + [mk.val_e]) == (4, 2)
    assert counts(rows + [mk.val_e - 1]) == (5, 3)


def _eval(src, w, handle):
    spec, params = spec_from_source(src)
    return pipeline.evaluate_world(InProcessRunner(obj_from_source(src), spec.kind), spec, params, w, 1, QUICK, handle)


def test_constant_strategy_fails_activity_although_it_rebalances_often(val_handle):
    w = synth_world(seed=3)
    res = _eval(CONST, w, val_handle)
    assert res["status"] == "integrity_fail_val" and res["integrity"]["reason"] == "activity"
    assert set(res["integrity"].keys()) == {"checks", "ok", "reason"}
    # the v1 definition (engine rebalance events) would have passed: drift rebalances are many
    grid = pipeline.core_grid(w.core, w.symbols)
    mk = pipeline.Market(w, grid)
    run = mk.run(np.full((len(grid), 2), 0.5), mk.dev_s, mk.val_e)
    assert run.n_rebalances >= 40


def test_frequent_decider_passes_activity(val_handle):
    res = _eval(TWICE_WEEKLY, synth_world(seed=3), val_handle)
    assert res["status"] == "evaluated"
    assert res["metrics"]["decisions"] >= 500 and res["metrics"]["decisions_val"] >= 300
