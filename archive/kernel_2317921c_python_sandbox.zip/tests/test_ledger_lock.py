"""Ledger hash chain and kernel lock tests (temporary directories only)."""
import json

import pytest

from omr import kernel_lock as KL
from omr import ledger as L


def test_chain_detects_tampered_row(tmp_path):
    p = tmp_path / "t.jsonl"
    for i in range(4):
        L.append(p, {"i": i, "val_sharpe": 0.1 * i})
    assert L.verify_chain(p) == []
    lines = p.read_text().splitlines()
    row = json.loads(lines[2])
    row["val_sharpe"] = 9.9                        # edit content, keep the stored hashes
    lines[2] = L.canonical(row)
    p.write_text("\n".join(lines) + "\n")
    probs = L.verify_chain(p)
    assert any("row 2" in x for x in probs)


def test_chain_detects_deleted_row(tmp_path):
    p = tmp_path / "t.jsonl"
    for i in range(4):
        L.append(p, {"i": i})
    lines = p.read_text().splitlines()
    del lines[1]
    p.write_text("\n".join(lines) + "\n")
    assert L.verify_chain(p)


def make_kernel(root):
    (root / "omr").mkdir()
    (root / "tests").mkdir()
    (root / "omr" / "a.py").write_text("X = 1\n")
    (root / "tests" / "test_a.py").write_text("def test(): pass\n")
    (root / "CONSTITUTION.md").write_text("rules\n")
    (root / "requirements.txt").write_text("numpy==1\n")


def test_kernel_lock_detects_edits(tmp_path):
    make_kernel(tmp_path)
    lock, hist = tmp_path / "kernel.lock", tmp_path / "hist.jsonl"
    KL.rekey("initial", "tester", root=tmp_path, lock_path=lock, history_path=hist)
    assert KL.verify(tmp_path, lock, hist) == []
    (tmp_path / "omr" / "a.py").write_text("X = 2\n")
    assert any("changed: omr/a.py" in x for x in KL.verify(tmp_path, lock, hist))
    (tmp_path / "omr" / "a.py").write_text("X = 1\n")
    assert KL.verify(tmp_path, lock, hist) == []
    (tmp_path / "omr" / "b.py").write_text("Y = 1\n")
    assert any("new file" in x for x in KL.verify(tmp_path, lock, hist))
    (tmp_path / "omr" / "b.py").unlink()
    (tmp_path / "CONSTITUTION.md").write_text("weaker rules\n")
    assert KL.verify(tmp_path, lock, hist)


def test_kernel_lock_detects_lock_rewrite_without_history(tmp_path):
    make_kernel(tmp_path)
    lock, hist = tmp_path / "kernel.lock", tmp_path / "hist.jsonl"
    KL.rekey("initial", "tester", root=tmp_path, lock_path=lock, history_path=hist)
    (tmp_path / "omr" / "a.py").write_text("X = 3\n")
    cur = KL.compute(tmp_path)
    lock.write_text(json.dumps({"files": cur["files"], "combined": cur["combined"]}))   # forged lock
    assert any("kernel_history" in x for x in KL.verify(tmp_path, lock, hist))


def test_rekey_requires_reason_and_approver(tmp_path):
    make_kernel(tmp_path)
    with pytest.raises(ValueError):
        KL.rekey("", "tester", root=tmp_path, lock_path=tmp_path / "l", history_path=tmp_path / "h")
    with pytest.raises(ValueError):
        KL.rekey("why", "", root=tmp_path, lock_path=tmp_path / "l", history_path=tmp_path / "h")
