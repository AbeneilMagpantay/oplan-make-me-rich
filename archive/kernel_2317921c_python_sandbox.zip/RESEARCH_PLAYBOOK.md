# RESEARCH PLAYBOOK

The protocol a researcher session follows. This file is GENOME: the meta-review
(step 8) may edit it. The kernel (`omr/`, `tests/`, `CONSTITUTION.md`,
`requirements.txt`) is never edited by a researcher session.

All commands run from the project root with the venv Python
(`.venv\Scripts\python.exe`).

## 1. Status

    python -m omr.status
    python -m omr.ledger verify

If the kernel lock or a ledger chain fails, stop and report to the human. Do not
"fix" it.

## 2. Read

- `LESSONS.md` (what the evidence supports so far)
- the last two `generations/genNNN/REPORT.md`
- `python -m omr.ledger summary` (every trial, counted or not)
- `STATE.md`

## 3. Pre-register: write `generations/genNNN/PLAN.md` BEFORE any evaluation

3 to 5 hypotheses. For each:
- the rule, with its params and declared ranges (at most 6 params);
- mechanism: why would this edge exist and persist, and who is on the other side
  of the trade;
- falsifier: which result would make you drop it;
- relation to earlier trials (new idea, variation of trial X, answer to a lesson).

A hypothesis written after looking at VAL numbers is not a hypothesis.

## 4. Implement and explore on DEV only

- One file per hypothesis in `strategies/`, named `genNNN_<idea>.py`, one
  Strategy subclass (see `omr/strategy_api.py`). Allowed imports, exactly:
  `import numpy as np`, `import pandas as pd`, `import math`,
  `from omr.strategy_api import Strategy, Param`,
  `from omr.indicators import <names>`. The parser is an ALLOWLIST (builtins,
  attribute names, statements); a rejected file names the rule it broke. Copy
  the shape of the gen-0 files.
- Params: at most 6; no zero default; the declared range must contain 0.8 to 1.2
  times the default; int params need default +/- 1 inside the range.
- No calendar information except hour-of-day and day-of-week (the evaluator
  shifts timestamps by whole weeks and requires identical output). No date
  strings. Prices are rescaled too, so use ratios, not price levels.
- kind "portfolio" receives an ORDERED LIST of frames (core symbols in order),
  not a dict; return a DataFrame with one column per frame, in order.
- Use completed coarse bars only: `resample_ohlcv` then `align_to_base`.
- Datasets available by declaration: `funding`, `mark_klines` (klines are always
  there, and every frame carries `funding_rate`).
- Activity: a strategy must make at least 40 decisions executed in DEV+VAL and 10
  in VAL (a decision = the target weights change by more than 0.01 in any asset).
  Very slow rules can fail this; the sandbox prints the DEV decision count.
- Explore freely with the sandbox (DEV only, uncounted):

      python -m omr.sandbox strategies/genNNN_idea.py --set fast=30

- Do not try to see VAL any other way. Do not write scripts that read `data/`.

## 5. Submit: at most 5 counted submissions per generation

    python -m omr.evaluate strategies/genNNN_idea.py --generation NNN

- A submission that passes stage 1 (DEV) becomes one counted trial forever the
  moment its pending row is written, whatever happens in stage 2, and raises M for
  every later DSR. Submit only what PLAN.md pre-registered.
- A stage-1 failure is logged but not counted: fix the bug (run the sandbox, it
  runs the same stage-1 checks). A stage-2 failure (`integrity_fail_val`) IS
  counted and reveals no metric. Do not retry variations of a strategy that failed
  on its merits.
- Re-submitting identical code returns the existing row. Changing comments does
  not change the trial identity; changing code or params does.

## 6. Report: write `generations/genNNN/REPORT.md`, update `LESSONS.md` and `STATE.md`

- Results table straight from the ledger rows (gates P/F, PSR(0), DSR, M, N).
- A verdict per hypothesis against its pre-registered falsifier.
- LESSONS.md takes only what the evidence supports, with trial ids. Mark
  anything suggestive but unproven as such.

## 7. Pool decisions

    python -m omr.pool list
    python -m omr.pool admit <trial_id> --reason "..." [--replace <member>]
    python -m omr.census

Only Tier-1 trials. At most 5 members; replacing one must be explicit and
justified. Run the census after pool changes.

## 8. Every 5th generation: meta-review

Review the whole ledger: which families and ideas pass or fail at which gates,
how forward results compare with backtests, and what the integrity failures
say. Then:
- edit this playbook (level-2 improvement), with a dated note of what changed
  and why;
- file kernel change requests in `KERNEL_PROPOSALS.md` for the human (problem,
  evidence, proposed change, expected effect on pass rates).

## 9. New data sources

Propose them in `KERNEL_PROPOSALS.md` with the data-admission evidence
(CONSTITUTION section 3.2): DEV+VAL coverage, point-in-time timestamps with a
conservative lag, live availability at decision time, cost, revision check.
Never wire a source in yourself.

## Never

- Never edit the kernel or anything under `ledger/` or `data/`.
- Never compute vault performance or any post-VAL performance outside the census.
- Never tune a strategy on VAL results and resubmit it as if it were new.
