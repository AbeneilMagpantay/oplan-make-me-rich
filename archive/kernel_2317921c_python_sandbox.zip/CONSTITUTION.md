# CONSTITUTION v1 (perpetual futures, hardened)

This file is part of the KERNEL. It changes only through a human-approved re-key
(section 10). Every number below is mirrored in `omr/constants.py`; if they ever
disagree, the code is what ran and the disagreement is a kernel bug.

## 1. Purpose

A research system that looks for trading strategies on USDT-margined perpetual
futures and says "no edge" honestly when there is none. Later sessions run
generations: an LLM researcher reads the ledger and lessons, pre-registers
hypotheses, writes strategy files, submits them to the evaluator, records the
results, and promotes passers to a forward-tested paper pool.

The loop improves strategies (level 1) and its own research playbook (level 2).
It must never be able to raise its score by weakening the measuring instrument.
Enemies, in order: (1) backtest overfitting and multiple testing, (2) lookahead,
(3) unrealistic costs. Small, correct and auditable beats feature-rich.

Nothing in this system trades real money. Kernel v1 contains no exchange
credentials and no order-placement code.

## 2. Kernel, genome and threat model

KERNEL (immutable to the loop): the package `omr/`, `tests/`, `CONSTITUTION.md`,
`requirements.txt`. Their sha256 hashes are recorded in `kernel.lock`; every
re-key appends a hash-chained row to `ledger/kernel_history.jsonl`. The
evaluator, sandbox, pool and census refuse to run when the kernel does not
match its lock or the lock does not match the latest history row.

GENOME (the loop may write): `strategies/`, `generations/`, `LESSONS.md`,
`RESEARCH_PLAYBOOK.md`, `STATE.md`, `KERNEL_PROPOSALS.md`.

The loop never edits the kernel, never edits `ledger/` or `data/` by hand, never
adds a data source itself, and never computes vault performance.

Threat model. The strategy author is the system's own LLM researcher, not an
outside attacker. The kernel must:
(a) catch honest mistakes (lookahead, calendar dependence, bad outputs);
(b) make gaming require deliberate, visible effort;
(c) guarantee that ANY run of strategy code on VAL bars is a counted trial;
(d) and it says plainly: it is NOT a security sandbox against someone with
    write access to the folder. A determined author can still bypass it.
    Forward results, measured after a strategy is frozen, are the last line of
    defence.

## 3. Data and regions

Instruments: Binance USD-M linear perpetuals.
- Core universe (traded in research): BTCUSDT, ETHUSDT.
- Extended universe (veto only, survivorship-biased): SOLUSDT, BNBUSDT, XRPUSDT,
  ADAUSDT, DOGEUSDT, LTCUSDT, LINKUSDT, AVAXUSDT.

Bars: 1h OHLCV, UTC, indexed by bar OPEN time. Stored on a complete hourly grid;
a missing bar becomes the previous close for open/high/low/close, volume-type
columns 0, `is_gap = True`. Gap counts are in `data/manifest.json`.

Regions (bar open time, UTC, inclusive):

| region | from | to | rule |
|---|---|---|---|
| warm-up | first bar (BTC 2019-09-08, ETH 2019-11-27) | 2019-12-31 23:00 | indicator input only, no positions |
| DEV | 2020-01-01 00:00 | 2022-06-30 23:00 | free sandbox, uncounted |
| VAL | 2022-07-01 00:00 | 2025-06-30 23:00 | counted: any run of strategy code on VAL bars is one trial forever |
| VAULT | 2025-07-01 00:00 | 2026-11-18 09:00 (build snapshot end) | never computed in kernel v1 |
| FORWARD | bars after a strategy's birth (and after VAULT end) | - | measured only by the census |

Loaders take an explicit ceiling: `dev_end`, `val_end`, or `latest`. Any ceiling
beyond DEV end needs a ledger-issued ValHandle (section 9). Only `omr/data.py`
and `omr/census.py` may name `latest`; `tests/test_structure.py` enforces this.

`data/manifest.json` records, per dataset and symbol: source, first/last row,
rows, gaps, duplicates, timestamp-unit checks, the REST-vs-bulk cross-check,
mark-price coverage, and the parquet sha256; plus `research_hash` (sha256 over
every stored row visible at or before VAL end) and a per-dataset hash. Trials
reference the research_hash, so appending new data does not change trial
identity. An update first checks the stored files against the manifest and
refuses on any mismatch; an update that would change any stored row writes
nothing and stops (the source is quarantined until the human decides). A
dataset not yet in the manifest is written only when named explicitly
(`python -m omr.data update --admit <name>`), as part of a kernel re-key.

### 3.1 Dataset registry and point-in-time alignment

The data layer is a registry of dataset adapters (`omr/datasets.py`). Each
declares its name, frequency, history start, source, fields, and the rule for
WHEN a row becomes knowable, as `visible_from(row)` = the open time of the 1h
bar from whose CLOSE the row may be used. One kernel function,
`align_to_grid`, puts rows on the 1h grid and never shows a row before its
`visible_from` bar. No dataset and no universe size is hardcoded in the engine
or the evaluator.

v1 datasets:
- `klines` (1h): Binance USD-M bulk klines (data.binance.vision), with the
  public REST API used for the warm-up months before the first bulk month
  (2019) and the hours after the last bulk file. Visible from its own bar.
- `funding` (event): Binance USD-M bulk fundingRate files, with REST for the
  2019 backfill and the current month. Settlement times are rounded to the hour.
  A rate settled at time t is visible from the bar that opens at t. A missing
  interval is taken from the gap to the PREVIOUS settlement; the very first row
  uses the declared default of 8 hours.
- `mark_klines` (1h, admitted 2026-11-18, KP-001): Binance USD-M bulk
  markPriceKlines (checksums verified), REST for the backfill (mark history
  starts 2019-12-23 11:00) and the hours after the last bulk file. Stored as
  actual rows only; a missing mark bar stays missing. Used by the liquidation
  check; a strategy may also declare it.

Every frame given to a strategy carries `funding_rate` (the rate settled at that
bar's open, else 0). Declaring `datasets = ("funding",)` adds `funding.rate`,
`funding.interval_hours` (as-of) and `funding.new`; declaring `"mark_klines"`
adds `mark_klines.open/high/low/close` (as-of) and `mark_klines.new`.

### 3.2 Data admission

A new dataset enters only by a kernel re-key, after it shows:
(a) history covering DEV and VAL;
(b) timestamps as of when each value was knowable, with a conservative lag;
(c) the same source is available live at decision time;
(d) it is free, or its cost was approved by the human;
(e) a revision check: re-fetched history matches the stored snapshot, otherwise
    the source is quarantined.
The researcher proposes sources in `KERNEL_PROPOSALS.md` with this evidence. It
never wires one in itself. Calendar information other than hour-of-day and
day-of-week must also arrive as an admitted dataset (section 6, invariance).

## 4. Engine and costs

Linear perpetuals, signed weights, no leverage above 1x gross anywhere in research.

- Weight = signed notional / equity. Each weight in [-1, 1]; gross sum(|w|) <= 1.
  A violation is an integrity failure, never clipped. NaN means flat.
  (Sharpe-type gates are scale-invariant, so leverage is a deployment sizing
  decision for the human, never a research variable.)
- The output at bar t may use information up to and including the close of
  bar t. It is executed at the open of bar t+1. Returns are open-to-open.
  Cash earns 0.
- Holdings drift with prices. Order at every bar open:
  1. mark to the open;
  2. funding: equity changes by -sum(w_i x rate_i) x equity, using the drifted
     position held coming into that open (rates must be finite);
  3. rebalance: if ANY |target - drifted weight| > 0.01, trade ALL assets to
     target, otherwise do nothing. Cost = traded notional x (5.5 bps taker fee +
     2 bps slippage) per side, deducted from equity (traded notional is measured
     at the pre-cost equity; positions are then set on the post-cost equity).
- Liquidation check, per bar, on MARK price: worst-case intrabar equity assuming
  every long hits the bar's mark low and every short its mark high at the same
  moment, each relative to the mark open of the same bar; where a bar has no
  mark data, last-price low/high relative to the last-price open (DEV+VAL mark
  coverage 99.54% to 99.90% per symbol). If worst-case equity falls to or below
  2.5% of gross notional (a drop to exactly 2.5% is flagged), the trial fails
  integrity with reason `liquidation`. Equity at or below 0 ends the run (0
  afterwards). In jitter, stress, permutation and extended-universe runs a
  liquidation scores that run as Sharpe = -infinity.
- Cost stress = 2x costs. Funding stress = funding paid x1.5, received x0.5.
- Daily returns: equity is sampled at the 00:00 UTC opens BEFORE any trade
  there; a run's first day starts exactly at its first bar (starting capital
  1.0) and its last day ends at the post-trade equity of its last bar, so a run
  ending at 23:00 has a 23-hour last day. A region's first day therefore starts
  exactly at its first bar.
- Outputs: hourly equity, daily returns, rebalance events, decisions, turnover,
  average gross and net exposure, funding paid.
- `deploy_scale = min(1, 0.20 / max drawdown over DEV+VAL)` is recorded on every
  evaluated trial (risk budget: 20% historical drawdown).
- A numba-compiled inner loop (no on-disk cache) is used; an independent
  pure-Python reference must agree to 1e-10, including on liquidating paths and
  on paths where equity reaches 0 (tested).

## 5. Statistics

On DAILY net returns, 365-day annualisation, risk-free 0.
- Sharpe = mean / std(ddof=1) x sqrt(365); 0 when std < 1e-12 (no evidence).
- Max drawdown on the daily equity path (starting at 1.0), Calmar, turnover,
  exposure, per-calendar-year table.
- PSR(SR*) = Phi((SR - SR*) x sqrt(n-1) / sqrt(1 - g3 x SR + ((g4-1)/4) x SR^2)),
  SR per day, n daily observations, g3 skewness, g4 Pearson kurtosis (normal 3),
  both from biased central moments; 0 when std < 1e-12.
- DSR = PSR(SR0), SR0 = max(0, sqrt(V) x [(1-g) x PhiInv(1-1/N) + g x PhiInv(1-1/(N e))]),
  g = 0.5772156649, N = rho + (1-rho) x M. M = every counted trial including the
  current one (pending, incomplete and integrity_fail_val trials count). V
  (variance of per-day VAL Sharpes, floored at 1/(n-1)) and rho (mean pairwise
  correlation of VAL daily returns, clipped to [0,1]) use only counted trials
  with stored returns. N <= 1 gives SR0 = 0. Returns are stored in
  `ledger/returns/<trial_id>.parquet`.

## 6. Integrity (two stages: count before exposure)

Strategy code never runs in the evaluator process. Each run happens in a fresh
child process (`python -I -B`, cwd = a fresh temp dir holding a private copy of
only `strategy_api.py` and `indicators.py`, scrubbed environment, stdout and
stderr discarded, timeout). The child receives the exact source text the parent
hashed and checked, explicit params and only the frames for that job, and
returns numeric arrays plus a status from a fixed enumeration (ok, load_error,
no_strategy_class, exception, bad_output; the parent adds timeout and crash).
Any exception, including SystemExit, becomes a fixed code. All comparisons,
metrics and gates are computed in the parent. Separate children run: the
DEV-only run, the determinism re-run, each truncation batch (given no data
beyond its largest cut; cuts run in increasing order), the full DEV+VAL run,
each invariance run, each jitter variant, and the G8 runs.

Static checks (no strategy code runs):
1. AST ALLOWLIST. Imports exactly `import numpy as np`, `import pandas as pd`,
   `import math`, `from omr.strategy_api import Strategy, Param`,
   `from omr.indicators import <names in its __all__>`; nothing binds `omr`.
   Builtins: abs, min, max, len, range, float, int, bool, round, sum, zip,
   enumerate, sorted, list, dict, tuple, set (and the constants). Attribute
   names from an explicit allowlist of numeric numpy/pandas vocabulary (no
   read_*/to_*/load/save/eval/query/bfill, nothing starting with an underscore;
   an unknown attribute is `forbidden_attribute`). No dunder anywhere, no
   attribute assignment, no global/nonlocal, no try/raise/with/async/yield/
   assert, no decorators, no mutable default arguments, no imports inside
   functions, no name that shadows a Python builtin. Module level holds only the
   imports, numeric constants and the one class; the class body only name,
   family, hypothesis, kind, datasets, params (literals) and methods. String
   literals that look like calendar dates are rejected. ASCII only.
2. Params are read from the literals by the parent: at most 6; no zero default;
   the declared range must contain the whole jitter range (0.8 to 1.2 times the
   default, mirrored for negative defaults); int params need default +/- 1
   inside the range. Every later run passes explicit param values.

Stage 1, on DEV-only frames (warm-up + DEV), uncounted:
3. Base run; weight validity (section 4; signal range [-1, 1] for kind single).
4. Determinism: a second child run is identical.
5. Lookahead: for each cut, the strategy is re-run on data up to and including
   the cut and ALL rows from the bar before DEV start up to the cut must equal
   the reference run within 1e-9 (NaN = 0). Cuts: every decision-change row if
   there are at most 300, else a random 300; plus 200 uniform random rows; always
   the first executed row and DEV end. Seed from fresh OS entropy, stored in the
   trial detail afterwards. (Floor if ever reduced for time: 100 + 100.)
6. Invariance: relabelling the index by +52 and -104 weeks must give identical
   outputs (fail = `calendar_dependent`: a strategy may depend on hour-of-day and
   day-of-week only); multiplying prices (OHLC, mark, quote volumes) by 0.25 and
   by 8, and volumes by 4, must give outputs within 1e-9 on all but at most 0.02%
   of rows (fail = `scale_dependent`).
A failure here writes one `integrity_fail` row (fixed reason code) and is not
counted. No VAL bar has reached strategy code.

Then a COUNTED `pending` row is appended and flushed; it issues the trial's
ValHandle. Stage 2, on DEV+VAL frames, counted whatever happens:
7. Full run in a fresh process; its DEV rows must equal stage 1
   (`dev_rows_changed`).
8. Lookahead on VAL cuts (same rule; always the first and last VAL decision
   rows), invariance on the full frame, weight validity.
9. Liquidation (mark price) and activity: at least 40 DECISIONS executed in
   DEV+VAL and 10 in VAL (a decision = the target weight vector changes by more
   than 0.01 in any asset; drift rebalances are not decisions).
10. Each jitter variant gets a light lookahead check (20 cuts) in its own child
    (`lookahead_jitter`).
A failure here writes the final row `integrity_fail_val` (fixed code, no metric
computed, printed or stored, no timestamp); it counts in M.

## 7. Gates and tiers

All on the one continuous DEV+VAL run unless stated. Tier 1 ("paper-eligible")
needs ALL of G1-G9.

| gate | rule |
|---|---|
| G1 | VAL PSR(0) >= 0.90 |
| G2 | funding stress (paid x1.5, received x0.5): VAL Sharpe > 0 |
| G3 | DEV Sharpe > 0 |
| G4 | VAL Sharpe at 2x costs > 0 |
| G5 | jitter: 12 variants, every param x U(0.8, 1.2) (ints rounded; an int left unchanged by rounding moves by 1 with a random sign; clipped to bounds), each in its own child with a light lookahead check; median VAL Sharpe >= 0.5 x base VAL Sharpe AND >= 75% with VAL Sharpe > 0. No params = pass. Only the median and the fraction positive are stored. |
| G6 | timing permutation on VAL: 200 circular shifts of the VAL weight matrix against VAL prices (offsets uniform in [30 days, length - 30 days], all assets shifted together, funding stays on the price timeline, engine restarted flat at VAL start for actual and shifted alike); p = (1 + #(shifted Sharpe >= actual)) / 201 <= 0.025 (set by calibration, section 8) |
| G7 | sub-periods 2020, 2021, 2022, 2023, 2024, 2025H1: net return > 0 in at least 4, AND the largest bucket log return <= 50% of the sum of positive bucket log returns |
| G8 | extended-universe veto. Kind single: the signal on each extended perp alone at full weight over its DEV+VAL history. Kind portfolio (which receives a positional panel: an ordered list of frames, no symbol names): the same strategy on disjoint substitute tuples of the extended list in listed order, (SOL,BNB), (XRP,ADA), (DOGE,LTC), (LINK,AVAX) for two core symbols. Skip units with < 2 years; median Sharpe > 0 AND at least half > 0. |
| G9 | at most 6 numeric params (enforced statically at load) |

Information only (not gates): the benchmark (constant long 1/K per core symbol
through the same engine including funding) VAL Sharpe and max drawdown, beta,
annualised alpha and PSR(0) of the beta-hedged residual.

Trial identity = sha256(normalised source token stream + params + kernel hash +
research_hash), first 16 hex. Re-submitting an identical trial returns the
existing row and is not counted again. The evaluator always evaluates the
declared default params.

## 8. Calibration (protocol v2)

Before any real VAL result is read, `python -m omr.calibrate` measures the
pipeline on synthetic worlds built from the real core data on the real calendar,
carrying klines, mark bars and funding together (its built-in families run
in-process as trusted code):

- Null A: whole UTC days drawn iid with replacement from DEV+VAL, the same day
  for both core symbols. Destroys multi-day predictability.
- Null B: the real day order; for each UTC day one fair coin (shared by both core
  symbols) mirrors that day's demeaned hourly log-return path,
  r' = -(r - m) + m, m = the symbol's mean hourly log return over DEV+VAL (a
  mirrored bar's high and low excursions swap). Mark bars get the same
  construction; funding is unchanged. Keeps real volatility dynamics, destroys
  directional predictability across days.
- DEV-overfit protocol on each null: for each (family, world) draw 20 parameter
  sets from the declared ranges, keep the best DEV Sharpe, send only that one
  through the Tier-1 pipeline (G8 not run, so rates are upper bounds). Per-pair
  results are stored so thresholds can be re-read without re-running.
- Noisy-oracle power: synthetic strategies with a known edge, per asset
  sign(rho z_future + sqrt(1 - rho^2) eps) re-decided every k days (fast k = 1,
  slow k = 20), rho set on 60 separate worlds so the mean net VAL Sharpe is ~1.0
  or ~1.5, power measured on 100 fresh worlds. Calibration code only; never
  reachable from the evaluator.
- G6 threshold rule (the only constant set by calibration): the largest value in
  the pre-declared grid 0.025 / 0.05 / 0.10 whose null pass rate per COUNTED
  pair (pairs that pass integrity; integrity failures are not trials) is <= 3.0%
  under BOTH nulls. None qualifies -> stop.
- Stop rule v2: at the chosen threshold, oracle power at true Sharpe 1.5 >= 50%
  for both speeds (applied under both nulls). Otherwise generation 0 is not run
  and the human decides.
- Calibration loads DEV+VAL bars with a ValHandle of explicit, logged purpose
  (`ledger/val_access_log.jsonl`).

Evidence for the current G6 threshold: `ledger/calibration_43099ad9550d2be7.json`
(final hardened pipeline; 500 DEV-overfit pairs per null, of which 373 (A) and
355 (B) passed integrity, the rest failed activity; 100 fresh oracle worlds per
null and speed):

| G6 threshold | null A passes / counted | null B passes / counted | oracle power at Sharpe 1.5 (A fast, A slow, B fast, B slow) | at Sharpe 1.0 |
|---|---|---|---|---|
| 0.025 | 4/373 = 1.07% | 1/355 = 0.28% | 0.80, 0.62, 0.84, 0.79 | 0.53, 0.25, 0.56, 0.37 |
| 0.05 | 12/373 = 3.22% | 5/355 = 1.41% | 0.81, 0.73, 0.84, 0.81 | 0.53, 0.32, 0.56, 0.48 |
| 0.10 | 14/373 = 3.75% | 11/355 = 3.10% | 0.81, 0.76, 0.84, 0.84 | 0.53, 0.36, 0.56, 0.52 |

Chosen: 0.025 (the only grid value at or below 3.0% per counted pair under both
nulls). Stop rule v2 passed. Per all 500 pairs the rates would be 0.8%, 2.4%,
2.8% (A) and 0.2%, 1.0%, 2.2% (B) and 0.10 would qualify; the counted-trial
reading is the stricter one and was applied (KERNEL_PROPOSALS KP-003 asks the
human to confirm). Null passers at 0.025: null A 2 RSI mean-reversion + 2 funding
carry; null B 1 Donchian. Calibration never tunes any other gate or constant.
Results: `ledger/calibration_<kernel_hash16>.json` (earlier runs on earlier
kernels are kept for the record).

## 9. Ledger, VAL access, pool and census

- `ledger/trials.jsonl`: append-only, hash-chained (prev_hash, row_hash);
  `ledger/HEAD.json` anchors each chain's row count and head hash, is rewritten
  on every append, and is checked by `ledger verify` and by the evaluator. Order
  for a counted trial: `pending` row (flushed) before any VAL exposure; result
  files (`ledger/trials/<id>.json`, `ledger/returns/<id>.parquet`) after it; the
  final row last. The frozen source copy `ledger/sources/<id>.py` is written
  before the pending row. `python -m omr.ledger verify` reports a pending row
  without a final row, and any file no row references, as `incomplete` (still
  counted).
- VAL access: every loader and pipeline entry point that touches bars after DEV
  end requires a ValHandle. The ledger issues one when it appends a pending row;
  calibration and census get one only with an explicit purpose that is logged in
  `ledger/val_access_log.jsonl`. A call without a handle raises.
- Failure rows hold fixed reason codes only. The evaluator prints status and
  reason code, and metrics only for `evaluated` trials.
- Paper pool: at most 5 members, Tier-1 trials evaluated under the CURRENT
  kernel hash only, replacement must be explicit, every change is a hash-chained
  row in `ledger/pool_log.jsonl`.
- Census: updates the data, then for each pool member runs the frozen source (in
  a child process) flat from birth on post-birth bars only. Birth = the later of
  the trial's born_at and its pool admission, rounded up to the next bar open,
  and never before the bar after VAULT end. Forward daily returns (intervals that
  end at a 00:00 open) are stored raw and at deploy_scale. Idempotent.

## 10. Kernel change procedure

1. The researcher files a request in `KERNEL_PROPOSALS.md` (problem, evidence,
   proposed change, expected effect on pass rates). It never edits the kernel.
2. The human reviews and, if approved, makes or accepts the change.
3. Tests pass; if a gate, constant, data source, the engine or the integrity
   pipeline changed, the calibration is re-run on the new kernel.
4. `python -m omr.kernel_lock rekey --reason "..." --approved-by "<who approved>"`.
   The new kernel hash changes every later trial id; earlier trials stay counted.
5. If a kernel bug is found after real VAL results were seen, it is fixed,
   re-keyed with the reason, and the before/after results are reported openly.

## 11. LIVE requirements (defined now, implemented in later kernels)

A strategy may trade real money only when ALL hold:
1. At least 60 days forward in the paper pool.
2. Its forward result is not below the 5th percentile of block-bootstrapped
   same-length windows of its own VAL returns.
3. A one-time VAULT check that returns pass/fail only, with every query logged
   (kernel v2).
4. DSR >= 0.95 on VAL + forward at the then-current trial count.
5. Explicit human approval.

Live risk limits the loop can never change:
- Perpetual futures on the approved venue only. Live gross exposure =
  deploy_scale by default; any increase is the human's decision, with a hard
  ceiling of 2.0 gross.
- A dedicated sub-account (or isolated margin) holding only the bot's capital.
- API key trade-only, withdrawals disabled, IP-restricted.
- Per-strategy capital cap set by the human.
- An exchange-side reduce-only protective stop on every position. It must be
  modelled in the engine before any live use (kernel v2 item).
- Halts, as defaults the human confirms before live: per-strategy halt (and
  demotion from the pool) at 20% drawdown from peak; account daily-loss halt at
  4%. (These replace the spot-era defaults of -3% in a day and -15% from peak.)
- A `HALT` kill-switch file checked before every order.
- The bot runs on an always-on host, not a personal PC.

## 12. Known limitations

- Not a sandbox (section 2): the AST allowlist, child processes and handles are
  tripwires against mistakes and casual gaming, not against a determined author.
- The LLM researcher's training data covers market history to about mid-2026, so
  every pre-birth backtest, the vault included, is optimistic. Only FORWARD is
  clean. A strategy can still encode remembered history through bar POSITIONS
  (the data start is fixed, so a bar's index is a date); invariance relabels
  timestamps but not positions.
- A text- or news-reading signal cannot be honestly backtested, because the LLM
  already knows the history; it can only be judged forward.
- The extended universe is survivorship-biased (today's surviving perps), so it
  may only veto.
- Two highly correlated core assets give a small effective sample.
- Funding and prices are Binance's; another live venue will differ slightly.
- Leverage and liquidation are structurally excluded at gross <= 1. The
  liquidation check uses Binance's 1h mark-price bars; real liquidation happens
  on the live mark price tick by tick and with tiered maintenance margins, so the
  2.5% rule is an approximation. Where mark bars are missing (0.10% to 0.46% of
  DEV+VAL bars per symbol, plus all bars before 2019-12-23) the check falls back
  to last-trade highs/lows, which can contain wicks such as the ETHUSDT 323 print
  of 2020-03-13 02:00 (mark high that hour 119.5).
- Fills are bar-based at the next open with fixed costs; there is no order book,
  no partial fills, no funding-time execution effects.
- Pre-2020 warm-up bars and the bars after the last bulk file come from the
  REST API (same exchange); the REST-vs-bulk cross-check for 2020-01 matched
  exactly.
